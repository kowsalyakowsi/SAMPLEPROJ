package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.PendingInvoice;
import com.foucsr.supplierportal.mysql.database.repository.PendingInvoiceRepository;
import com.foucsr.supplierportal.payload.ReportFilterRequest;

@Service
public class PendingInvoiceService {

	@Autowired
	private PendingInvoiceRepository pendingInvoiceRepository;

	public List<PendingInvoice> getPendingInvoiceByDate(ReportFilterRequest byDateRequest) {

		List<PendingInvoice> list = null;

		try {			
			
			if ( !"".equals(byDateRequest.getPo_num()) && !"".equals(byDateRequest.getOrg_name()) && !"".equals(byDateRequest.getFromDate())
					&& !"".equals(byDateRequest.getToDate()) && byDateRequest.getVendorId() != null) {
				
				list = pendingInvoiceRepository.getPendingInvoicesByAllParam(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId() , byDateRequest.getPo_num() , byDateRequest.getOrg_name());
				
			} else  if ( !"".equals(byDateRequest.getPo_num()) && !"".equals(byDateRequest.getOrg_name()) &&  byDateRequest.getVendorId() != null) {
				
				list = pendingInvoiceRepository.getPendingInvoicesByPOOrg(byDateRequest.getVendorId() , byDateRequest.getPo_num() , byDateRequest.getOrg_name());
				
			} else  if ( !"".equals(byDateRequest.getPo_num()) && byDateRequest.getVendorId() != null) {
				
				list = pendingInvoiceRepository.getPendingInvoicesByPO(byDateRequest.getVendorId() , byDateRequest.getPo_num());
				
			} else  if ( !"".equals(byDateRequest.getOrg_name()) && byDateRequest.getVendorId() != null) {
				
				list = pendingInvoiceRepository.getPendingInvoicesByOrg(byDateRequest.getVendorId() , byDateRequest.getOrg_name());
				
			} else if (!"".equals(byDateRequest.getFromDate()) && !"".equals(byDateRequest.getToDate())
					&& byDateRequest.getVendorId() != null) {
				 
				list = pendingInvoiceRepository.getPendingInvoicesByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
				
			} else if (byDateRequest.getVendorId() != null) {
				
				list = pendingInvoiceRepository.getPendingInvoicesByVendorId(byDateRequest.getVendorId());
				
			}
			
			
			if(list == null || list.size() == 0) {
				
				list = new ArrayList<PendingInvoice>();
			}
			
			
		} catch (Exception e) {
			throw new AppException("Unable to get Debit Note details");
		}

		return list;

	}

	
	public List<String> getDistinctShipToOrg(String vendorID) {
		
		List<String> list = null;
		
		try {
			
			list = pendingInvoiceRepository.findDistinctShipToOrg(vendorID);
			
		} catch (Exception e) {
			throw new AppException("Unable to get Debit Note details");
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<String>();
		}
		
		return list; 
	}
	
	
}
