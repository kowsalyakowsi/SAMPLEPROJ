package com.foucsr.supplierportal.oracle.database.repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.foucsr.supplierportal.oracle.database.model.VendorAgingOracle;
import com.foucsr.supplierportal.util.AppConstants;

@Component
public class VendorAgingOracleRepository  {
	   
	Logger log = LoggerFactory.getLogger(VendorAgingOracleRepository.class);
//	
   
	public List<VendorAgingOracle> findLatestAging(String fromDate , String vendor_code, String plant , String toDate) {

		RestTemplate restTemplate = new RestTemplate();

		String paymentURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_fi_records?sap-client=800";
		
		
		UriComponentsBuilder builder = UriComponentsBuilder
			    .fromUriString(paymentURL)
			    // Add query parameter
			    .queryParam("FIRST", fromDate)
			    .queryParam("LAST", toDate)
			    .queryParam("VENDOR_ID", vendor_code)
			    .queryParam("PLANT", plant);

		ResponseEntity<VendorAgingOracle[]> response = restTemplate.getForEntity(builder.toUriString(), VendorAgingOracle[].class);


		VendorAgingOracle[] payments = response.getBody();

		List<VendorAgingOracle> paymentList = Arrays.asList(payments);
		
		if(paymentList == null) {
			
			paymentList = new ArrayList<VendorAgingOracle>();
		}
		
		return paymentList;
	}
	
}