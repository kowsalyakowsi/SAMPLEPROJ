package com.foucsr.supplierportal.payload;

public class VendorInvDOStatusRequest {

	private String fromDate;

	private String toDate;
	
	private String is_inv_uploaded;
	
	private String is_do_uploaded;

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getIs_inv_uploaded() {
		return is_inv_uploaded;
	}

	public void setIs_inv_uploaded(String is_inv_uploaded) {
		this.is_inv_uploaded = is_inv_uploaded;
	}

	public String getIs_do_uploaded() {
		return is_do_uploaded;
	}

	public void setIs_do_uploaded(String is_do_uploaded) {
		this.is_do_uploaded = is_do_uploaded;
	}

	}
