package com.foucsr.supplierportal.mysql.database.service;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.exception.ResourceNotFoundException;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.RFQHeader;
import com.foucsr.supplierportal.mysql.database.model.RegisteredListAndOUObjects;
import com.foucsr.supplierportal.mysql.database.model.SupplierBankDetailsRegister;
import com.foucsr.supplierportal.mysql.database.model.SuppliersRegister;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.EmailDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OperatingUnitsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierBankDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierRegisterRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.payload.SupplierCreationRequest;
import com.foucsr.supplierportal.payload.SupplierRegistrationRequest;
import com.foucsr.supplierportal.security.JwtTokenProvider;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.EmailHtmlLoader;
import com.foucsr.supplierportal.util.EmailSubject;
import com.foucsr.supplierportal.util.SendMail;

@Service
public class RegistrationService {

	Logger logger = LoggerFactory.getLogger(RegistrationService.class);

	@Autowired
	private SupplierRegisterRepository supplierRegistrationRepository;

	@Autowired
	JwtTokenProvider tokenProvider;

	@Autowired
	EmailHtmlLoader emailHtmlLoader;

	@Autowired
	UserRepository userRepository;

	@Autowired
	EmailDetailsRepository emailDetailsRepository;
	
	@Autowired
	private PoAgentsRepository poAgentsRepository;
	
	@Autowired
	SupplierBankDetailsRepository supplierBankDetailsRepository;
	
	@Autowired
	private OperatingUnitsRepository operatingUnitsRepository;

	public String sendRegistrationRequest(List<SupplierRegistrationRequest> requests) {

		try {

			for (SupplierRegistrationRequest req : requests) {

				SuppliersRegister supplierReg = new SuppliersRegister();

				supplierReg.setEmail(req.getEmail());
				supplierReg.setUser_name(req.getUser_name());								
				
				User user =  userRepository.findByUsername(req.getUser_name())
						.orElseThrow(() -> new ResourceNotFoundException("User", "username", req.getUser_name()));
			
				Long buyer_id = (long) 0;								
				buyer_id = Long.parseLong(user.getAgentId());
				
				supplierReg.setBuyer_id(buyer_id);	
				
				PoAgents buyer=	poAgentsRepository.findByAgentId(buyer_id.toString());
				
				supplierReg.setBuyer_name(buyer.getAgentName());
				
				try {

				   supplierReg = supplierRegistrationRepository.save(supplierReg);
				   
				} catch(Exception e) {
					logger.info("***************** Unable to send registration request *********************\n" + e);
					
					if(e.getCause() != null && e.getCause().getCause() != null && e.getCause().getCause().getMessage() != null 
							      && !"".equals(e.getCause().getCause().getMessage()) && e.getCause().getCause().getMessage().contains("Duplicate")) {

						return "Duplicate";
					}
					
					return "Bad";
				}

				String jwt = tokenProvider.generateTokenForSupplierRegistration(req.getEmail(), supplierReg.getId());
				
				supplierReg.setToken(jwt);
				
				supplierReg = supplierRegistrationRepository.save(supplierReg);

				sendRegistrationRequestMail(req, jwt);
			}

		} catch (Exception ex) {
			logger.info("***************** Unable to send registration request *********************\n" + ex);
			throw new AppException("Unable to send registration request");
		}
		
		return "Success";
	}

	private void sendRegistrationRequestMail(SupplierRegistrationRequest regRequest, String jwt) {

		/*User admin = userRepository.findAdmin()
				.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));*/

		String appUrl = regRequest.getSupplierRegistrationUrl() + "/register/" + jwt;

		String emailFrom = new String();
		List<String> emailTo = new ArrayList<String>();
		List<String> emailCC = new ArrayList<String>();
		String subject = AppConstants.supplierRegistrationSubject;
		String text = emailHtmlLoader.getSupplierRegistrationText(appUrl);


		emailTo.add(regRequest.getEmail());

		EmailSubject emailSubject = null;
		try {
			emailSubject = EmailSubject.getInstance(emailDetailsRepository);
		} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
				| InvalidKeySpecException e) {

			throw new AppException("Unable to get Email details");
		}
		
		String fromEmail = emailSubject.getUsername();
		emailFrom = fromEmail;

		emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
		emailSubject.setHTML(true);

		SendMail sm = new SendMail();

		sm.sendMail(emailSubject);
	}
	
	
	public RegisteredListAndOUObjects getAllRegisterList(Long buyerId) {

		List<SuppliersRegister> list = null;

		RegisteredListAndOUObjects  obj = new RegisteredListAndOUObjects() ;
		
		try {
			
			
			PoAgents buyer =	poAgentsRepository.findByAgentId(buyerId.toString());
		
			List<OperatingUnits> operatingUnits = operatingUnitsRepository.findAllByBusinessGroup(buyer.getBusiness_group_id());

			list = supplierRegistrationRepository.getAllRegisteredSupplierList(buyerId);
			
			obj.setSuppliers(list);
			obj.setOperatingUnits(operatingUnits);

		} catch (Exception e) {
			throw new AppException("Unable to get registered supplier list");
		}		

		return obj;

	}
	
	
	public String submitToCreateSupplier(List<SupplierCreationRequest> requests) {

		for (SupplierCreationRequest req : requests) {

			try {
				SuppliersRegister supplier = supplierRegistrationRepository
						.getSupplierById(req.getId());

				if (supplier != null) {
					
					if(supplier.getOrg_id() == null || supplier.getOrg_name() == null) {
						
						throw new AppException("Please choose the operating unit");
					}

					supplier.setIs_send_to_supplier_creation("Y");

					List<SupplierBankDetailsRegister> banks = supplierBankDetailsRepository
							.getSupplierBankDetails(req.getId());

					for (SupplierBankDetailsRegister bank : banks) {

						bank.setIs_send_to_supplier_creation("Y");
					}

					supplierRegistrationRepository.save(supplier);

					supplierBankDetailsRepository.saveAll(banks);

				}

			} catch (Exception e) {
				throw new AppException("Unable to submit for Supplier creation" + req.getId());
			}
		}


		return AppConstants.Success_Message;

	}
	
	
	public SuppliersRegister saveSiteOperatingUnit(SuppliersRegister request) {

		SuppliersRegister existingSupplier = null;

		try {

			existingSupplier = supplierRegistrationRepository.getSupplierById(request.getId());

			if (existingSupplier != null) {

				if (request.getOrg_name() != null && request.getOrg_id() != null) {

					existingSupplier.setOrg_id(request.getOrg_id());
					existingSupplier.setOrg_name(request.getOrg_name());
				}
				
				if(request.getPurchasing_site_flag() != null) {
					
					existingSupplier.setPurchasing_site_flag(request.getPurchasing_site_flag());
				}
				
				if (request.getPay_site_flag() != null) {

					existingSupplier.setPay_site_flag(request.getPay_site_flag());
				}

				if (request.getRfq_only_site_flag() != null) {

					existingSupplier.setRfq_only_site_flag(request.getRfq_only_site_flag());
				}

				existingSupplier = supplierRegistrationRepository.save(existingSupplier);
			}

		} catch (Exception ex) {
			logger.info("***************** Unable to site OU *********************\n" + ex);
			throw new AppException("Unable to save site OU");
		}

		return existingSupplier;
	}



}
