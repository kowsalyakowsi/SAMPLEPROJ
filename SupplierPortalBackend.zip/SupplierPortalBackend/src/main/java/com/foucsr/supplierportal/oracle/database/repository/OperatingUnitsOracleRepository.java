package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class OperatingUnitsOracleRepository  {
	   

//    @Query(value = "select * from XX_OPERATING_UNITS where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<OperatingUnitsOracle> findAllOperatingUnits();
   
}