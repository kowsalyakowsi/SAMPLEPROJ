package com.foucsr.supplierportal.oracle.database.repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.foucsr.supplierportal.mysql.database.model.OpenCreditMysql;
import com.foucsr.supplierportal.oracle.database.model.PaymentAdviceOracle;
import com.foucsr.supplierportal.util.AppConstants;

@Component
public class PaymentAdviceOracleRepository  {
	   
	Logger log = LoggerFactory.getLogger(PaymentAdviceOracleRepository.class);
//	
   
	public List<PaymentAdviceOracle> findLatestPaymentAdvice(String fromDate , String toDate , String vendor_code) {

		RestTemplate restTemplate = new RestTemplate();

		String paymentURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_manpay?sap-client=800";
		
//		ResponseEntity<PaymentAdviceOracle[]> response = restTemplate.getForEntity(
//				paymentURL , PaymentAdviceOracle[].class);
		
		UriComponentsBuilder builder = UriComponentsBuilder
			    .fromUriString(paymentURL)
			    // Add query parameter
			    .queryParam("FIRST", fromDate)
			    .queryParam("LAST", toDate)
			    .queryParam("VENDOR_ID", vendor_code);

		ResponseEntity<PaymentAdviceOracle[]> response = restTemplate.getForEntity(builder.toUriString(), PaymentAdviceOracle[].class);


		PaymentAdviceOracle[] payments = response.getBody();

		List<PaymentAdviceOracle> paymentList = Arrays.asList(payments);
		
		if(paymentList == null) {
			
			paymentList = new ArrayList<PaymentAdviceOracle>();
		}
		
		return paymentList;
	}


}