package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.DebitNote;
import com.foucsr.supplierportal.mysql.database.service.DebitNoteService;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@RestController
@RequestMapping("/DebitNote/Service")
@CrossOrigin
public class DebitNoteController {

	@Autowired
	private DebitNoteService debitNoteService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	
	@PostMapping("/getDebitNoteByDate")
	public List<DebitNote> getPrePaymentsByDate(@Valid @RequestBody ReportFilterRequest byDateRequest,
			Principal principal) {
		return debitNoteService.getDebitNoteByDate(byDateRequest);

	}
	
	
}
