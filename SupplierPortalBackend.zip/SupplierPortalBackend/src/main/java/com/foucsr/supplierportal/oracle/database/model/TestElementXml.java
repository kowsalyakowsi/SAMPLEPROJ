package com.foucsr.supplierportal.oracle.database.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "item")
public class TestElementXml {

	private Long MANDT;

	private String EMAIL;

	private String FIRSTNAME;

	private String LASTNAME;

	@XmlElement(name = "MANDT")
	public Long getMANDT() {
		return MANDT;
	}

	public void setMANDT(Long mANDT) {
		MANDT = mANDT;
	}

	@XmlElement(name = "EMAIL")
	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	@XmlElement(name = "FIRSTNAME")
	public String getFIRSTNAME() {
		return FIRSTNAME;
	}

	public void setFIRSTNAME(String fIRSTNAME) {
		FIRSTNAME = fIRSTNAME;
	}

	@XmlElement(name = "LASTNAME")
	public String getLASTNAME() {
		return LASTNAME;
	}

	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}

}