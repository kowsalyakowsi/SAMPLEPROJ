package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foucsr.supplierportal.mysql.database.model.SupplierProductsRegister;

@Repository
public interface SupplierProductsRepository extends CrudRepository<SupplierProductsRegister, Long> {
	  
    
    @Query(value = "select * from SUPPLIER_PRODUCTS_REGISTER where SUPPLIER_REGISTER_ID = :supplier_register_id", nativeQuery = true)
    List<SupplierProductsRegister> getSupplierProducts(@Param("supplier_register_id") Long supplier_register_id );
    
    
    @Modifying
    @Transactional
    @Query(value = "DELETE from SUPPLIER_PRODUCTS_REGISTER where SUPPLIER_REGISTER_ID IN (:regIdList)", nativeQuery = true)
    void deleteAllProducts(@Param("regIdList") List<Long> regIdList);
    
  
    @Query(value = "select * from SUPPLIER_PRODUCTS_REGISTER where SUPPLIER_REGISTER_ID = :supplier_register_id AND ID = :id", nativeQuery = true)
    SupplierProductsRegister findSupplierProduct(@Param("supplier_register_id") Long supplier_register_id , @Param("id") Long id );
    
}