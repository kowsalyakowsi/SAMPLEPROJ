package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.oracle.database.model.SupplierSitesRegisterOracle;

@Repository
public interface SupplierSitesRegisterOracleRepository extends CrudRepository<SupplierSitesRegisterOracle, Long> {
	
   
}