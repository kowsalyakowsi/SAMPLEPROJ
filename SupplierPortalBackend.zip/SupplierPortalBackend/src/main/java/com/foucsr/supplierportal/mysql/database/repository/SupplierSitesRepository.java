package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.SupplierSites;

@Repository
public interface SupplierSitesRepository extends CrudRepository<SupplierSites, Long> {
	
    @Override
    Iterable<SupplierSites> findAll();    
    
    @Query(value = "SELECT * FROM SUPPLIER_SITES  WHERE VENDOR_SITE_ID = :siteId and VENDOR_ID = :vendorId", nativeQuery = true)
    SupplierSites findSite(@Param("vendorId") Long vendorId , @Param("siteId") Long siteId );
    
    @Query(value = "SELECT * FROM SUPPLIER_SITES  WHERE VENDOR_ID = :vendorId", nativeQuery = true)
    List<SupplierSites> findSites(@Param("vendorId") Long vendorId );       


}