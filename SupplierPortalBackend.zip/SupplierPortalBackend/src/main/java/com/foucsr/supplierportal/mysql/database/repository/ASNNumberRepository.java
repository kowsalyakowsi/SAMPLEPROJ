package com.foucsr.supplierportal.mysql.database.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ASNNumber;

@Repository
public interface ASNNumberRepository extends CrudRepository<ASNNumber, Long> {

	@Query(value = "SELECT * FROM ASN_NUMBER  WHERE ID = :id", nativeQuery = true)
	ASNNumber findAsnNextNumber(@Param("id") Long id);

}