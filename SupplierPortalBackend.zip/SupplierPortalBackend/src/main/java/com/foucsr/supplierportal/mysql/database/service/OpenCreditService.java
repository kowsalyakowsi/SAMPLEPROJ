package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.oracle.database.model.OpenCreditOracle;
import com.foucsr.supplierportal.oracle.database.repository.OpenCreditOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.util.SCAUtil;

@Service
public class OpenCreditService {

	Logger logger = LoggerFactory.getLogger(OpenCreditService.class);
	
	
	@Autowired
	private ApSuppliersRepository apSuppliersMysqlRepository;
	
	@Autowired
	private OpenCreditOracleRepository openCreditOracleRepository;

	public ResponseEntity<?> getOpenCreditList(ReportFilterRequest byDateRequest) {

		List<OpenCreditOracle> list = null;
		SCAUtil scaUtil = new SCAUtil() ;
		
        if(byDateRequest.getVendorId() == null) {
			
			return new ResponseEntity(new ApiResponse(false, "Vendor Id is mandatory!" ),
					HttpStatus.BAD_REQUEST);
		}

		String vendor_id = byDateRequest.getVendorId().toString();
		
		try {
			
		ApSuppliers supplier = apSuppliersMysqlRepository.findByVendorIDId(vendor_id);
		
		String vendor_code = supplier.getVendor_code();
		
		String fromDate = byDateRequest.getFromDate() != null ? byDateRequest.getFromDate().replaceAll("-", "") : "";
		String toDate = byDateRequest.getToDate() != null ? byDateRequest.getToDate().replaceAll("-", "") : "";
		
			list = openCreditOracleRepository.findLatestOpenCredit(fromDate, toDate, vendor_code);

		} catch (Exception e) {
			
			logger.info("***************** Unable to get open credit details *********************\n" + e);
			
			String msg = scaUtil.getErrorMessage(e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable get open credit details!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<OpenCreditOracle>();
			
		}

		return new ResponseEntity(list, HttpStatus.OK);

	}

}
