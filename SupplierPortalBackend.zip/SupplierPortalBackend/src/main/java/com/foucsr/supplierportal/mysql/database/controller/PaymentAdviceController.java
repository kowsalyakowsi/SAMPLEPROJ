package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.PaymentAdviceMysql;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PaymentAdviceService;
import com.foucsr.supplierportal.oracle.database.model.PaymentAdviceOracle;
import com.foucsr.supplierportal.payload.ReportFilterRequest;

@RestController
@RequestMapping("/PaymentAdvice/Service")
@CrossOrigin
public class PaymentAdviceController {

	@Autowired
	private PaymentAdviceService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	@PostMapping("/getPaymentAdviceList")
	public ResponseEntity<?> getPaymentAdviceList(@Valid @RequestBody ReportFilterRequest byDateRequest,
			Principal principal) {
		
		ResponseEntity<?> message = projectService.getPaymentAdviceList(byDateRequest);
		
		return message;

	}
}
