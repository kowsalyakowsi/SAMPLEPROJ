package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


public class PORequisitionOracle{
	
	// id from open po 
	private Long id;
	
	private String interface_source_code;
	
	private String destination_type_code;	
	
	private Double qty_ordered;
	
	private Double amount;
	
	private String authorization_status;		
	
	private String buyer;
		
	private Long code_combination_id;
	
	private Long line_type_id;
	
	private Long category_id;	
	
	private String organization_name;
	
	private String ship_to_location_code;
	
	private String deliver_to_requestor;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date need_by_date;
	
	private String ou_name;
	
	private String vendor_name;
	
	private String vendor_site_code;
	
	private String buyer_id;
	
	private Long po_line_num;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date createdAt;
	
	private String error_flag;

	private String scn;
	
	private String item_description;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInterface_source_code() {
		return interface_source_code;
	}

	public void setInterface_source_code(String interface_source_code) {
		this.interface_source_code = interface_source_code;
	}

	public String getDestination_type_code() {
		return destination_type_code;
	}

	public void setDestination_type_code(String destination_type_code) {
		this.destination_type_code = destination_type_code;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getAuthorization_status() {
		return authorization_status;
	}

	public void setAuthorization_status(String authorization_status) {
		this.authorization_status = authorization_status;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public Long getCode_combination_id() {
		return code_combination_id;
	}

	public void setCode_combination_id(Long code_combination_id) {
		this.code_combination_id = code_combination_id;
	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public Long getCategory_id() {
		return category_id;
	}

	public void setCategory_id(Long category_id) {
		this.category_id = category_id;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public String getShip_to_location_code() {
		return ship_to_location_code;
	}

	public void setShip_to_location_code(String ship_to_location_code) {
		this.ship_to_location_code = ship_to_location_code;
	}

	public String getDeliver_to_requestor() {
		return deliver_to_requestor;
	}

	public void setDeliver_to_requestor(String deliver_to_requestor) {
		this.deliver_to_requestor = deliver_to_requestor;
	}

	public Date getNeed_by_date() {
		return need_by_date;
	}

	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getError_flag() {
		return error_flag;
	}

	public void setError_flag(String error_flag) {
		this.error_flag = error_flag;
	}

	public String getScn() {
		return scn;
	}

	public void setScn(String scn) {
		this.scn = scn;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}
	
			
}