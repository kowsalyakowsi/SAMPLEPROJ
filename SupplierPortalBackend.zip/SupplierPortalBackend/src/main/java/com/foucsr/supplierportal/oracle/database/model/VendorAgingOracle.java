package com.foucsr.supplierportal.oracle.database.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VendorAgingOracle {

	@JsonProperty("BUKRS")
	private String bukrs; // plant

	@JsonProperty("LIFNR")
	private String lifnr; // vendor id

	@JsonProperty("NAME1")
	private String vendor_name;

	@JsonProperty("AGE1")
	private Double age1;

	@JsonProperty("AGE2")
	private Double age2;

	@JsonProperty("AGE3")
	private Double age3;

	@JsonProperty("AGE4")
	private Double age4;

	@JsonProperty("AGE5")
	private Double age5;

	@JsonProperty("WEEK1")
	private Double week1;

	@JsonProperty("WEEK2")
	private Double week2;

	@JsonProperty("WEEK3")
	private Double week3;

	@JsonProperty("WEEK4")
	private Double week4;

	@JsonProperty("TOTAL_AGE")
	private Double total_age;

	@JsonProperty("TOTAL_WEEK")
	private Double total_week;

	public String getBukrs() {
		return bukrs;
	}

	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}

	public String getLifnr() {
		return lifnr;
	}

	public void setLifnr(String lifnr) {
		this.lifnr = lifnr;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public Double getAge1() {
		return age1;
	}

	public void setAge1(Double age1) {
		this.age1 = age1;
	}

	public Double getAge2() {
		return age2;
	}

	public void setAge2(Double age2) {
		this.age2 = age2;
	}

	public Double getAge3() {
		return age3;
	}

	public void setAge3(Double age3) {
		this.age3 = age3;
	}

	public Double getAge4() {
		return age4;
	}

	public void setAge4(Double age4) {
		this.age4 = age4;
	}

	public Double getAge5() {
		return age5;
	}

	public void setAge5(Double age5) {
		this.age5 = age5;
	}

	public Double getWeek1() {
		return week1;
	}

	public void setWeek1(Double week1) {
		this.week1 = week1;
	}

	public Double getWeek2() {
		return week2;
	}

	public void setWeek2(Double week2) {
		this.week2 = week2;
	}

	public Double getWeek3() {
		return week3;
	}

	public void setWeek3(Double week3) {
		this.week3 = week3;
	}

	public Double getWeek4() {
		return week4;
	}

	public void setWeek4(Double week4) {
		this.week4 = week4;
	}

	public Double getTotal_age() {
		return total_age;
	}

	public void setTotal_age(Double total_age) {
		this.total_age = total_age;
	}

	public Double getTotal_week() {
		return total_week;
	}

	public void setTotal_week(Double total_week) {
		this.total_week = total_week;
	}

}