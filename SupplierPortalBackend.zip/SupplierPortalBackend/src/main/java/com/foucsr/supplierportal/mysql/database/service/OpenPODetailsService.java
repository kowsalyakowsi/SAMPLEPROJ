package com.foucsr.supplierportal.mysql.database.service;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.exception.ResourceNotFoundException;
import com.foucsr.supplierportal.mysql.database.model.ASNDetails;
import com.foucsr.supplierportal.mysql.database.model.ASNNumber;
import com.foucsr.supplierportal.mysql.database.model.AgentListProjection;
import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.Currencies;
import com.foucsr.supplierportal.mysql.database.model.Locations;
import com.foucsr.supplierportal.mysql.database.model.MasterOrganizations;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;
import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;
import com.foucsr.supplierportal.mysql.database.model.POCountDetails;
import com.foucsr.supplierportal.mysql.database.model.POLineTypes;
import com.foucsr.supplierportal.mysql.database.model.PurchasingCategory;
import com.foucsr.supplierportal.mysql.database.model.ServiceRelatedObjects;
import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.model.ShipMentTbl;
import com.foucsr.supplierportal.mysql.database.model.SupplierSites;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.ASNDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.ASNNumberRepository;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.CurrenciesRepository;
import com.foucsr.supplierportal.mysql.database.repository.EmailDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.LocationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterOrganizationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPODetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPoChangeDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OperatingUnitsRepository;
import com.foucsr.supplierportal.mysql.database.repository.POLineTypesRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PurchasingCategoryRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentStatusRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierSitesRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.oracle.database.model.PORequisitionOracle;
import com.foucsr.supplierportal.oracle.database.model.ShipMentTblOracle;
import com.foucsr.supplierportal.oracle.database.repository.POAgentsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PORequisitionOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ShipMentTblOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.AsnRequest;
import com.foucsr.supplierportal.payload.AsnResponse;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;
import com.foucsr.supplierportal.security.JwtTokenProvider;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.EmailHtmlLoader;
import com.foucsr.supplierportal.util.EmailSubject;
import com.foucsr.supplierportal.util.SCAUtil;
import com.foucsr.supplierportal.util.SendMail;

@Service
public class OpenPODetailsService {
	
	Logger logger = LoggerFactory.getLogger(OpenPODetailsService.class);

	@Autowired
	private OpenPODetailsRepository openPODetailsRepository;
	
	@Autowired
	private ShipMentTblRepository shipmentRepository;
	
	@Autowired
	private ShipMentTblOracleRepository shipmentOracleRepository;
	

	@Autowired
	private OpenPoChangeDetailsRepository openPoChangeDetailsRepository;
	
	@Autowired
	private ASNDetailsRepository asnDetailsRepository;
	
	@Autowired
	EmailHtmlLoader emailHtmlLoader;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ASNNumberRepository aSNNumberRepository;	
	
	 @Autowired
	 EmailDetailsRepository emailDetailsRepository;
	 
	@Autowired
	private PoAgentsRepository poAgentsRepository;
	 
	@Autowired
    private MasterOrganizationsRepository masterOrganizationsRepository;
	
	@Autowired
	private OperatingUnitsRepository operatingUnitsRepository;
	
	@Autowired
	private LocationsRepository locationsRepository;
	
	@Autowired
	POLineTypesRepository pOLineTypesRepository;
	
	@Autowired
	SupplierSitesRepository supplierSitesRepository;
	
	@Autowired
	private ApSuppliersRepository apsuppliersrepository;
	
	@Autowired
	CurrenciesRepository currenciesRepository;
	
//	@Autowired
//    PORequisitionOracleRepository pORequisitionOracleRepository;
	
	
	@Autowired
	PurchasingCategoryRepository purchasingCategoryRepository;
	
	@Autowired
	private POAgentsOracleRepository poAgentsOracleRepositoryOracle;
	
	@Autowired
    private JwtTokenProvider tokenProvider;
	
	@Autowired
	private ShipMentTblRepository shipMentTblRepository;
	

	public OpenPODetails saveServiceLine(OpenPODetails service, String username) {				
		
		Long serviceLinesCount = openPODetailsRepository.findServiceLinesCount(service.getService_header_id());
		
		OpenPODetails headerService = openPODetailsRepository.findByServiceHeaderId(service.getService_header_id());
		
		// if only header is there
		if(serviceLinesCount == 1) {																	
			
			if (headerService != null && headerService.getItem_description() != null && ( (service.getAmount() != null && service.getAmount() > 0)
					|| (service.getQty_ordered() != null && service.getQty_ordered() > 0)) ) {				
				
				long line_no = 2;
				
				setServiceLineDetails(service , line_no , headerService.getVendor_name() , headerService);					
				
			} else {
				
				
				headerService.setAmount(service.getAmount());
				headerService.setPending_amount(service.getAmount());
				headerService.setShipment_amount(service.getAmount());
				headerService.setScn_reserve_amount(0.0);

				headerService.setQty_ordered(service.getQty_ordered());
				headerService.setPending_qty(service.getQty_ordered());
				headerService.setShipment_qty(service.getQty_ordered());
				headerService.setAsn_reserve_qty(0.0);
				
				headerService.setCurrency_code(service.getCurrency_code());
				headerService.setItem_description(service.getItem_description());
				headerService.setNeed_by_date(service.getNeed_by_date());
				//headerService.setOrganization_name(service.getOrganization_name());
				headerService.setTax(service.getTax());
				headerService.setLine_type_id(service.getLine_type_id());
				headerService.setLine_type(service.getLine_type());
				
				
				return openPODetailsRepository.save(headerService);
				
			}

		} else if(serviceLinesCount > 1) {
						
			long line_no = serviceLinesCount + 1;						
			
			ApSuppliers supplier = apsuppliersrepository.findByVendorIDId(service.getVendor_id().toString());
				
			setServiceLineDetails(service , line_no , supplier.getVendor_name() , headerService);			
		}
		
		
		try {
			
			return openPODetailsRepository.save(service);
			
		} catch (Exception e) {
			throw new AppException("Unable to save service line details");
		}

	}				



	public OpenPODetails saveServiceHeader(OpenPODetails service) {
		
		Long maxId = openPODetailsRepository.findMaxId();
		
		Long maxServiceHeaderId = openPODetailsRepository.findMaxServiceHeaderId();
						
		maxId = maxId == null ? 0 : maxId ;
		
		maxServiceHeaderId = maxServiceHeaderId == null ? 1 : maxServiceHeaderId + 1;		
			
			maxId = maxId + 1;		
			
			ApSuppliers supplier = apsuppliersrepository.findByVendorIDId(service.getVendor_id().toString());			


			setServiceCommonLineDetails(service);
			
			service.setVendor_name(supplier.getVendor_name());
			service.setPoLineLocationId(maxId);
			service.setService_header_id(maxServiceHeaderId);
			service.setPo_line_num(1L);
			service.setShipment_num(1L);
			

			// if supplier's shipped date is null then get it from oracle server
			if(service.getSupp_shipped_date() == null) {
				
				java.util.Date date = new Date();
				
//				java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();				
				
				service.setSupp_shipped_date(date);
				
			}							
		
		try {
			return openPODetailsRepository.save(service);			
			
		} catch (Exception e) {
			throw new AppException("Unable to save service header details");
		}	

	}


	public Optional<OpenPODetails> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<OpenPODetails> openPODetails = openPODetailsRepository.findById(id);

		return openPODetails;
	}

	public List<OpenPODetails> findAllProjects(String username) {
		return openPODetailsRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		openPODetailsRepository.deleteById(id);
	}

	public List<OpenPODetails> getOpenPoByDate(GetOpenPoByDateRequest byDateRequest) {
		
		List<OpenPODetails> list = null;
		final char ch= Character.UNASSIGNED;
		
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
					&& byDateRequest.getVendorId() != null && byDateRequest.getOrg_name() != null) {
				
				list = openPODetailsRepository.getOpenPoDetailsByorgName(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId(), byDateRequest.getOrg_name(), byDateRequest.getLine_type());
				
				for(OpenPODetails openPO : list) {
					openPO.setShipment_qty(null);
					openPO.setShipment_amount(null);
				}
				
			} else if (byDateRequest.getVendorId() != null && byDateRequest.getOrg_name() != null) {
				
				list = openPODetailsRepository.getOpenPoDetailsByorgNameForAsn( byDateRequest.getVendorId(), byDateRequest.getOrg_name());
				
				for(OpenPODetails openPO : list) {
					openPO.setShipment_qty(null);
					openPO.setShipment_amount(null);
				}
				
			} else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
					&& byDateRequest.getVendorId() != null) {
				list = openPODetailsRepository.getOpenPoDetailsByAllParm(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
			} else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null) {
				list = openPODetailsRepository.getOpenPoDetailsByFromToDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate());
			} else if (byDateRequest.getVendorId() != null && ch != byDateRequest.getAck() && 'Y' == byDateRequest.getAck()) {
				
				list = openPODetailsRepository.getOpenPoDetailsByVendorForAsn(byDateRequest.getVendorId(), byDateRequest.getLine_type());
				
				for(OpenPODetails openPO : list) {
					openPO.setShipment_qty(null);
					openPO.setShipment_amount(null);
				}
				
			} else if (byDateRequest.getVendorId() != null) {
				list = openPODetailsRepository.getOpenPoDetailsByVendorId(byDateRequest.getVendorId());
			}			

			System.out.println("Result" + list);
		} catch (Exception e) {
			throw new AppException("Unable to get Open PO details");
		}

		if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}
		return list;

	}
	
	public List<OpenPODetails> getOpenPoByDateBuyer(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPODetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getBuyerId() != null) {
				list = openPODetailsRepository.getOpenPoDetailsByFromToDateBuyer(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getBuyerId());
			} 
			 else if (byDateRequest.getBuyerId() != null && byDateRequest.getItem_code() != null) {
					list = openPODetailsRepository.getOpenPoDetailsByBuyerWithItem(byDateRequest.getBuyerId(),
							byDateRequest.getItem_code());
			} 
			 else if (byDateRequest.getBuyerId() != null) {
				list = openPODetailsRepository.getOpenPoDetailsByBuyer(byDateRequest.getBuyerId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
       if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}

		return list;

	}
	
	public List<OpenPoChangeDetails> getOpenPoByDateBuyerAck(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPoChangeDetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getBuyerId() != null) {
				list = openPoChangeDetailsRepository.getOpenPoDetailsByFromToDateBuyer(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getBuyerId());
			} else if (byDateRequest.getBuyerId() != null) {
				list = openPoChangeDetailsRepository.getOpenPoDetailsByBuyer(byDateRequest.getBuyerId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
        if(list == null) {
			
			list = new ArrayList<OpenPoChangeDetails>();
		}

		return list;

	}

	public List<OpenPODetails> updateAcknowledge(List<GetOpenPoByDateRequest> list, HttpServletRequest request) {
		
		List<OpenPODetails> openPOs = new ArrayList<OpenPODetails>();
		
		char ackOrReject = 0;
		
		for(GetOpenPoByDateRequest dateRequest : list ) {
		OpenPODetails openPODetails = null;
		try {

			final char ch= Character.UNASSIGNED;

			if(ch != dateRequest.getAck()) {
				
				ackOrReject = dateRequest.getAck();
				
				openPODetails = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				String s = Character.toString(dateRequest.getAck());
				openPODetails.setAck(s);
				
				String reason = dateRequest.getUnAcknowledgeReason();
				
				if(reason != null) {
					openPODetails.setReaasonForRejected(reason);
				}
			}
			
			openPODetailsRepository.save(openPODetails);
			openPOs.add(openPODetails);

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
			throw new AppException("Unable to acknowledge po_line_location_id : " + dateRequest.getPoLineLocation_id());
		}
		
		}
		
		try {
		  sendMail(openPOs , ackOrReject , request);
		}catch(Exception ex) {
			logger.info("***************** Unable to send mail *********************\n" + ex);
		}
		
		return openPOs;

	}

	public OpenPODetails updateChangeRequestPo(GetOpenPoByDateRequest dateRequest , HttpServletRequest request) {
		
		OpenPODetails openPODetails = null;
		OpenPoChangeDetails openPoChangeDetails = new OpenPoChangeDetails();
		
		try {

			openPODetails = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
					dateRequest.getPoLineLocation_id());
			openPODetails.setIsChanged("Y");
			
			int changeRequestCount = openPODetails.getChangeRequestCount() + 1;
			
			openPODetails.setChangeRequestCount(changeRequestCount);
			
			BeanUtils.copyProperties(openPODetails, openPoChangeDetails);
			openPoChangeDetails.setChanged_qty(dateRequest.getChanged_qty());
			openPoChangeDetails.setSupplierChangePrice(dateRequest.getRevised_price());
			openPoChangeDetails.setReschedule_date(dateRequest.getReschedule_date());
			openPoChangeDetails.setReaasonForRejected(dateRequest.getReason());
			openPoChangeDetailsRepository.save(openPoChangeDetails);


		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
			throw new AppException("Unable to update change request po_line_location_id : " + dateRequest.getPoLineLocation_id());
		}
		
		openPODetails = openPODetailsRepository.save(openPODetails);
		
		try {
			
			sendChangeRequestMail(openPoChangeDetails ,  request);
			
		} catch (Exception ex) {
			logger.info("***************** Unable to send mail *********************\n" + ex);
		}
		
		return openPODetails;

	}

	public List<OpenPoChangeDetails> rejectPo(List<GetOpenPoByDateRequest> list , HttpServletRequest request) {
		
        List<OpenPoChangeDetails> changePOs = new ArrayList<OpenPoChangeDetails>();
        
        char ack = 0;
		
		for(GetOpenPoByDateRequest dateRequest : list ) {
			
		OpenPODetails openPODetails = null;
		OpenPoChangeDetails changeRequestDetails = null;
		OpenPoChangeDetails deletedChangeRequestDetails = new OpenPoChangeDetails();
		try {

			final char ch = Character.UNASSIGNED;

		    ack = dateRequest.getAck();

			if (ch != ack && 'N' == ack) {

				openPODetails = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				// rejected by buyer goes to open PO
//				openPODetails.setBuyer_approval("N");
				openPODetails.setReaasonForRejected(dateRequest.getReason());
				openPODetails.setIsChanged(null);
				
				// rejected by buyer goes to open PO
				changeRequestDetails = openPoChangeDetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				deletedChangeRequestDetails = changeRequestDetails;
				
				openPoChangeDetailsRepository.delete(deletedChangeRequestDetails);
				
//				changeRequestDetails.setBuyer_approval("N");
//				changeRequestDetails.setReaasonForRejected(dateRequest.getReason());


			} else if (ch != ack && 'Y' == ack) {

				openPODetails = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				openPODetails.setBuyer_approval("Y");
				
				changeRequestDetails = openPoChangeDetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				changeRequestDetails.setBuyer_approval("Y");


			}
			
			openPODetailsRepository.save(openPODetails);
						
			
			changePOs.add(changeRequestDetails);
			

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
			throw new AppException("Unable to acknowledge po_line_location_id : " + dateRequest.getPoLineLocation_id());
		}
		
	}
		try {
			
		    sendMailByBuyer(changePOs , ack ,  request);
		 
		}catch(Exception ex) {
			logger.info("***************** Unable to send mail *********************\n" + ex);
		}
		
		return changePOs;

	}

	public List<String> getDistinctOuName(String vendorID) {
		return openPODetailsRepository.findDistinctStates(vendorID);
	}

	public List<OpenPODetails> searchByPoNumber(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPODetails> list = null;
		try {			

			list = openPODetailsRepository.searchByPoNumber(byDateRequest.getPo_num(), byDateRequest.getVendorId());
			
			for(OpenPODetails openPO : list) {
				openPO.setShipment_qty(null);
				openPO.setShipment_amount(null);
			}

			System.out.println("Result" + list);
		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}

		return list;

	}

	public ResponseEntity<?> generateAsnNumber(List<AsnRequest> list) {
		OpenPODetails openPODetails = null;
		String asnNUmber = null;

		SCAUtil scaUtil = new SCAUtil() ;
		
		for (AsnRequest asnRequest : list) {
			try {

				openPODetails = openPODetailsRepository.findByHeaderIdAndforASNcreations(asnRequest.getUnique_id(),
						asnRequest.getPo_line_location_id(), asnRequest.getVendor_id(),asnRequest.getBuyer_id());

				if (asnNUmber == null) {
					asnNUmber = getAsnNumber(asnRequest.getVendor_id());
				}
				
				if(asnRequest.getShipment_qty() == null) {
					asnRequest.setShipment_qty(openPODetails.getAsn_reserve_qty());
				}
				
				double asnReserveQty = openPODetails.getAsn_reserve_qty() - asnRequest.getShipment_qty();
				openPODetails.setAsn_reserve_qty(asnReserveQty);
				openPODetails.setAsn(asnNUmber);
				
				if(asnRequest.getSupp_invoice_num() != null) {
					
					openPODetails.setSupp_invoice_num(asnRequest.getSupp_invoice_num());
					
				}
				
				if(asnRequest.getDo_num() != null)
				   openPODetails.setDo_num(asnRequest.getDo_num());
				
				if(asnRequest.getSupp_shipped_date() == null) {
					
					java.util.Date date = new Date();
					
//					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					asnRequest.setSupp_shipped_date(date);
					
					openPODetails.setSupp_shipped_date(date);
					
				}else {
					
					openPODetails.setSupp_shipped_date(asnRequest.getSupp_shipped_date());
				}
								
				openPODetails.setSupp_shipped_date(asnRequest.getSupp_shipped_date());
				
				// latest shipment qty set to po to show it on ASN upload mail
				openPODetails.setShipment_qty(asnRequest.getShipment_qty());
				
				createASN(asnRequest , openPODetails , asnNUmber);

				createShipment(openPODetails , asnRequest,  asnNUmber);

				openPODetailsRepository.save(openPODetails);
				
			} catch (Exception e) {
				
				logger.info("***************** Error while generate ASN  *********************\n" + e);
//				throw new AppException("Unable to generate ASN ");
				
				String msg = scaUtil.getErrorMessage(e);

				return new ResponseEntity(new ApiResponse(false, "Unable generate ASN!" + msg),
						HttpStatus.BAD_REQUEST);
				
			}
		}
		
		AsnResponse asnResponse = new AsnResponse(asnNUmber);
//		return asnResponse;
		return new ResponseEntity<AsnResponse>(asnResponse, HttpStatus.CREATED);

	}

	private void createASN(AsnRequest asnRequest , OpenPODetails openPODetails ,String asnNUmber ) {
		
		ASNDetails asn = new ASNDetails();
		asn.setAsn_qty(asnRequest.getShipment_qty());
		asn.setPo_header_id(openPODetails.getPo_header_id());
		asn.setPoLineLocationId(openPODetails.getPoLineLocationId());
		asn.setAsn(asnNUmber);
		asn.setOpen_po_id(openPODetails.getId());
		
		asnDetailsRepository.save(asn);
		
	}

	private void  createShipment(OpenPODetails openPODetails ,AsnRequest asnRequest ,  String asnNUmber) {
	
		ShipMentTbl shipment = new ShipMentTbl();
		shipment.setOu_name(openPODetails.getOu_name());
		shipment.setPo_header_id(openPODetails.getPo_header_id());
		shipment.setPO_DATE(openPODetails.getPo_date());
		shipment.setPo_number(openPODetails.getPo_num());
		shipment.setVendor_name(openPODetails.getVendor_name());
		shipment.setVendor_site_code(openPODetails.getVendor_site_code());
		shipment.setBuyer(openPODetails.getBuyer());
		shipment.setBuyer_id(openPODetails.getBuyer_id());
		shipment.setPo_line_num(openPODetails.getPo_line_num());
		shipment.setItem(openPODetails.getItem());
		shipment.setItem_description(openPODetails.getItem_description());
		shipment.setPo_uom(openPODetails.getPo_uom());
		shipment.setUnit_price(openPODetails.getUnit_price());
		shipment.setLine_type_id(openPODetails.getLine_type_id());
		shipment.setLine_type(openPODetails.getLine_type());
		
		boolean isFixedPrice = isFixedPriceService(openPODetails);
		
		if(!isFixedPrice) {
			
			shipment.setQty_ordered(openPODetails.getQty_ordered());
			shipment.setSHIPMENT_QTY(asnRequest.getShipment_qty());
			shipment.setReceiving_quantity(asnRequest.getShipment_qty());
			shipment.setPending_qty(openPODetails.getPending_qty());
			
		} 
		
//		else if(openPODetails.getAmount() != null && openPODetails.getAmount() > 0) {
		else {	
			shipment.setQty_ordered(openPODetails.getAmount());
			shipment.setSHIPMENT_QTY(asnRequest.getShipment_amount());
			shipment.setReceiving_quantity(asnRequest.getShipment_amount());
			shipment.setPending_qty(openPODetails.getPending_amount());
			shipment.setAmount(openPODetails.getAmount());
		}
		
		shipment.setOrganization_name(openPODetails.getOrganization_name());
		shipment.setNeed_by_date(openPODetails.getNeed_by_date());
		shipment.setAck(openPODetails.getAck());
		//shipment.setReschedule(openPODetails.getResc);
		shipment.setReschedule_date(openPODetails.getReschedule_date());
		shipment.setProcess_flag(openPODetails.getProcess_flag());
		shipment.setAsn(asnNUmber);
		shipment.setShipment_num(openPODetails.getShipment_num());
		//shipment.setReceipt_created_flag(openPODetails);
		shipment.setPo_line_id(openPODetails.getPo_line_id());
		shipment.setPo_line_location_id(openPODetails.getPoLineLocationId());
		//shipment.setReceipt_number(receipt_number);
		shipment.setVendor_id(openPODetails.getVendor_id());
		shipment.setHeader_id(openPODetails.getHeaderId());
		shipment.setBuyer_approval(openPODetails.getBuyer_approval());
		shipment.setProcessStatus(openPODetails.getProcessStatus());
		shipment.setCurrency_code(openPODetails.getCurrency_code());
		
		if(asnRequest.getSupp_invoice_num() != null) {
			
			shipment.setSupp_invoice_num(asnRequest.getSupp_invoice_num());
			
		}
		
		if(asnRequest.getDo_num() != null)
		  shipment.setDo_num(asnRequest.getDo_num());
		
		shipment.setSupp_shipped_date(asnRequest.getSupp_shipped_date());
		
		shipment.setRevisionNo(openPODetails.getRevisionNo());
		
		ShipMentTblOracle shipmentOracle = new ShipMentTblOracle();
				
		
		BeanUtils.copyProperties(shipment, shipmentOracle);
		
		shipmentOracle.setBuyer_id(Long.parseLong(shipment.getBuyer_id()));
		shipmentOracle.setPartial_shipped_qty(0.0);
		shipmentOracle.setLine_type(openPODetails.getLine_type());
		
//		shipmentOracleRepository.save(shipmentOracle);
		
		ResponseEntity<?> resp = shipmentOracleRepository.SendShipmentbySOAPService(shipmentOracle);
		
		HttpStatus statusCode = resp.getStatusCode();

			if (statusCode != HttpStatus.OK) {
				
				throw new AppException("Unable to Send shipment to SAP ");

			}
			
			shipmentRepository.save(shipment);
			
		
	}

	public String getAsnNumber(String vendorID) {
//		 Calendar usTime = Calendar.getInstance();
//		 int usMonth = usTime.get(Calendar.MONTH);
//		 int usDay = usTime.get(Calendar.DAY_OF_MONTH);
//		 int usYear = usTime.get(Calendar.YEAR);
//		 int usHours = usTime.get(Calendar.HOUR_OF_DAY);
//		 final int usMinutes = usTime.get(Calendar.MINUTE);
//		 final int secs = usTime.get(Calendar.SECOND);
		
		long next_number = getNextAsnNumber();
		
//		 final StringBuffer usTimeStr = new StringBuffer("").append(usYear).append(usMonth).append(usDay).append(usHours)
//				 .append(usMinutes).append(secs).append(vendorID);
		
		final StringBuffer usTimeStr = new StringBuffer("").append(next_number);
		
		return usTimeStr.toString();
		
	}
	
	private long getNextAsnNumber() {

		ASNNumber next_number = aSNNumberRepository.findAsnNextNumber(AppConstants.ASN_ID);
				
		long asn_no = next_number.getNext_num();
		
		next_number.setNext_num(asn_no + 1);	
		
		aSNNumberRepository.save(next_number);
		
		return asn_no;
	}

	public List<OpenPODetails> getRejectedPoByDate(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPODetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getVendorId() != null && !"".equals(byDateRequest.getVendorId())) {
				list = openPODetailsRepository.getRejectedOpenPoDetailsByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
			} else if (byDateRequest.getVendorId() != null && !"".equals(byDateRequest.getVendorId())) {
				list = openPODetailsRepository.getRejectedOpenPoDetailsByVendorId(byDateRequest.getVendorId());
			} else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getBuyerId() != null && !"".equals(byDateRequest.getBuyerId())) {
				list = openPODetailsRepository.getRejectedPoDetailsByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getBuyerId());
			} else if (byDateRequest.getBuyerId() != null && !"".equals(byDateRequest.getBuyerId())) {
				list = openPODetailsRepository.getRejectedPoDetailsByBuyerId(byDateRequest.getBuyerId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
        if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}

		return list;

	}
	
	public List<OpenPODetails> getAcceptedPoByDateSupplier(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPODetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getVendorId() != null) {
				list = openPODetailsRepository.getAcceptedOpenPoDetailsByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
			} else if (byDateRequest.getVendorId() != null) {
				list = openPODetailsRepository.getAcceptedOpenPoDetailsByVendorId(byDateRequest.getVendorId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
		if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}

		return list;

	}
	
	public List<OpenPoChangeDetails> getChangedPoByDateSupplier(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPoChangeDetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getVendorId() != null) {
				list = openPoChangeDetailsRepository.getChangedPoDetailsByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
			} else if (byDateRequest.getVendorId() != null) {
				list = openPoChangeDetailsRepository.getChangedPoDetailsByVendorId(byDateRequest.getVendorId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
       if(list == null) {
			
			list = new ArrayList<OpenPoChangeDetails>();
		}

		return list;

	}
	
	public POCountDetails getPoCountBySupplier(GetOpenPoByDateRequest byDateRequest) {
		POCountDetails poCount = new POCountDetails();
		try {
			if (byDateRequest.getVendorId() != null) {
				
				long rejectedPO = 0;
				long acceptedPO = 0;
				long openPO = 0;
				
				rejectedPO = openPODetailsRepository.getRejectedPoCountByVendorId(byDateRequest.getVendorId());
				
				acceptedPO = openPODetailsRepository.getAcceptedPoCountByVendorId(byDateRequest.getVendorId());
				
				openPO = openPODetailsRepository.getOpenPoCountByVendorId(byDateRequest.getVendorId());
				
				poCount.setRejectedBySupplier(rejectedPO);
				poCount.setAcknowledgedBySupplier(acceptedPO);
				poCount.setOpenPO(openPO);
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}

		return poCount;

	}
	
	
	public POCountDetails getPoCountByBuyer(GetOpenPoByDateRequest byDateRequest) {
		POCountDetails poCount = new POCountDetails();
		try {
			if (byDateRequest.getBuyerId() != null) {
				
				long rejectedPO = 0;
				long changeRequestPO = 0;
				long openPO = 0;
				
				rejectedPO = openPODetailsRepository.getRejectedPoCountByBuyerId(byDateRequest.getBuyerId());
				
				changeRequestPO = openPoChangeDetailsRepository.getChangeRequestPoCountByBuyerId(byDateRequest.getBuyerId());
				
				openPO = openPODetailsRepository.getOpenPoCountByBuyerId(byDateRequest.getBuyerId());
				
				poCount.setRejectedBySupplier(rejectedPO);
				poCount.setChangeRequestPO(changeRequestPO);
				poCount.setOpenPO(openPO);
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}

		return poCount;

	}
	
	public List<OpenPODetails> getRejectedPoByDateBuyer(GetOpenPoByDateRequest byDateRequest) {
		List<OpenPODetails> list = null;
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null && 
					byDateRequest.getBuyerId() != null) {
				list = openPODetailsRepository.getRejectedPoDetailsByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getBuyerId());
			} else if (byDateRequest.getBuyerId() != null) {
				list = openPODetailsRepository.getRejectedPoDetailsByBuyerId(byDateRequest.getBuyerId());
			}

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		
        if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}

		return list;

	}
	
	
	public List<OpenPODetails> updateRejectionByBuyer(List<GetOpenPoByDateRequest> list , HttpServletRequest request) {

		List<OpenPODetails> rejectionPOS = new ArrayList<OpenPODetails>();

		for (GetOpenPoByDateRequest dateRequest : list) {

			OpenPODetails openPODetails = null;

			try {

				openPODetails = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(dateRequest.getUnique_id(),
						dateRequest.getPoLineLocation_id());
				openPODetails.setAck(null);

				openPODetailsRepository.save(openPODetails);

				rejectionPOS.add(openPODetails);

			} catch (Exception e) {
				// throw new ProjectIdException("Project ID
				// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
				throw new AppException("Unable to update po_line_location_id : " + dateRequest.getPoLineLocation_id());
			}

		}

		try {
			
		   sendNewOrReminderMailByBuyer(rejectionPOS, 'Z' ,  request);
		   
		}catch(Exception ex) {
			logger.info("***************** Unable to send mail *********************\n" + ex);
		}

		return rejectionPOS;

	}


	private void sendMail(List<OpenPODetails> list , char ackOrReject , HttpServletRequest request) {

		if (list != null && list.size() > 0) {

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User supplier = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();
			String subject = new String();
			
			if('Y' == ackOrReject) {
				
				 subject = AppConstants.supplierAckSubject.replace("???", list.get(0).getVendor_name());
				 
			}else {
				
				subject = AppConstants.supplierRejectionSubject.replace("???", list.get(0).getVendor_name());;
			}

			
			String text = emailHtmlLoader.loadSupplierAckText(list , ackOrReject);

//			emailFrom = supplier.getEmail();
			emailFrom = emailSubject.getUsername();

			long agentId = Long.parseLong(list.get(0).getBuyer_id());

			List<User> agents = userRepository.findByAgentId(agentId);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}
	
	
	private void sendChangeRequestMail(OpenPoChangeDetails openPoChangeDetails , HttpServletRequest request) {

		if (openPoChangeDetails != null) {

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User supplier = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();
			String subject = AppConstants.supplierChangeReqSubject.replace("???", openPoChangeDetails.getVendor_name());
			String text = emailHtmlLoader.loadSupplierChangeReqText(openPoChangeDetails, 'A');

//			emailFrom = supplier.getEmail();
			
			emailFrom = emailSubject.getUsername();

			long agentId = Long.parseLong(openPoChangeDetails.getBuyer_id());

			List<User> agents = userRepository.findByAgentId(agentId);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}
	
	private void sendMailByBuyer(List<OpenPoChangeDetails> list , char ack, HttpServletRequest request) {

		if (list != null && list.size() > 0) {

			OpenPoChangeDetails openPOChangeDetails = list.get(0);
			
			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User buyer = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();
			
			String subject = new String();
			
			if('Y' == ack) {
				
				 subject = AppConstants.buyerAckSubject;
				 
			}else {
				
				subject = AppConstants.buyerRejectSubject;
			}
			
			
			String text = emailHtmlLoader.loadSupplierChangeReqText(openPOChangeDetails , ack);

			emailFrom = buyer.getEmail();

			long vendorID = openPOChangeDetails.getVendor_id();

			List<User> agents = userRepository.findByVendorId(vendorID);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}
	
	
	public void sendUploadedInvoice(String asn, File uploadFile , String scn , String fileName , HttpServletRequest request) {

		if (uploadFile != null) {

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}
			
			List<OpenPODetails> openPOs = null;

			if(asn != null) {
				
				openPOs = openPODetailsRepository.findPOByASN(asn);
								
				
			} else if(scn != null) {
				
				openPOs = openPODetailsRepository.findPOBySCN(scn);
			}

			if (openPOs != null && openPOs.size() > 0) {

				User supplier = userRepository.findUser(getUserIdFromRequest(request))
						.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

				String emailFrom = new String();
				List<String> emailTo = new ArrayList<String>();
				List<String> emailCC = new ArrayList<String>();
				String subject = AppConstants.buyerASNUploadSubject.replace("???", openPOs.get(0).getVendor_name());
				String text = emailHtmlLoader.loadInvoiceUploadText(openPOs , asn , scn);

//				emailFrom = supplier.getEmail();
				emailFrom = emailSubject.getUsername();

				long agentId = Long.parseLong(openPOs.get(0).getBuyer_id());

				List<User> agents = userRepository.findByAgentId(agentId);

				// add first one for to mail and others for cc
				emailTo.add(agents.get(0).getEmail());

				for (User agent : agents) {

					if (agent == agents.get(0))
						continue;
					emailCC.add(agent.getEmail());
				}
				
				List<File> uploadFiles = new ArrayList<File>();
				uploadFiles.add(uploadFile);

				emailSubject.init(emailFrom, emailTo, emailCC, uploadFiles, subject, text);
				emailSubject.setHTML(true);

				SendMail sm = new SendMail();

				sm.sendMail(emailSubject);
			}
			
			
			/*try {
				
				callInvoiceAttachmentProc(fileName , asn != null ? asn : scn);
				
			} catch(Exception ex) {
				logger.info("***************** Unable call attachement procedure *********************\n" + ex);
			}*/
		}
	}
	
	public void sendReminder(List<OpenPODetails> list , char isNewPO , HttpServletRequest request) {

		Map<Long, List<OpenPODetails>> map = new HashMap<Long, List<OpenPODetails>>();
		
		OpenPODetails openPOdetail = null;

		for (OpenPODetails openPO : list) {
			
		    Long key  = openPO.getVendor_id();
		    
		    if(map.containsKey(key)){
		    	
		        List<OpenPODetails> vendorGrList = map.get(key);
		        vendorGrList.add(openPO);

		    }else{
		    	List<OpenPODetails> vendorGrList = new ArrayList<OpenPODetails>();
		    	vendorGrList.add(openPO);
		        map.put(key, vendorGrList);
		    }
		    
		    if ('R' == isNewPO) {
		    	
		    	openPOdetail = openPODetailsRepository.findByHeaderIdAndPoLineLocationId(openPO.getHeaderId(),
		    			openPO.getPoLineLocationId());
		    	openPOdetail.setReminder_date(new Date());
		    	openPODetailsRepository.save(openPOdetail);
		    }

		}
		
		for (Map.Entry<Long, List<OpenPODetails>> entry : map.entrySet()) {
 
			try {
				
			   sendNewOrReminderMailByBuyer(entry.getValue(), isNewPO ,  request);
			   
			}catch(Exception ex) {
				logger.info("***************** Unable to send mail *********************\n" + ex);
			}
		}

	}
	
	private void sendNewOrReminderMailByBuyer(List<OpenPODetails> list , char isNewPO , HttpServletRequest request) {

		if (list != null && list.size() > 0) {

			OpenPODetails openPODetails = list.get(0);
			
			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}
			
			User buyer = null;

			if(request != null) {
			
				 buyer = userRepository.findUser(getUserIdFromRequest(request))
						.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));
			} else {
				
				long agentId = Long.parseLong(list.get(0).getBuyer_id());
				
				List<User> buyers = userRepository.findByAgentId(agentId);
				buyer = buyers.get(0);
			}
			

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();
			
			String subject = new String();
			
			if('P' == isNewPO) {
				
				 subject = AppConstants.buyerNewPOSubject;
				 
			}else if ('R' == isNewPO){
				
				subject = AppConstants.buyerReminderSubject;  
				
			}else if ('Z' == isNewPO){
				
				subject = AppConstants.buyerActionAginstRejectoionSubject; 
			}
			
			
			String text = emailHtmlLoader.loadSupplierAckText(list , isNewPO);

			emailFrom = buyer.getEmail();

			long vendorID = openPODetails.getVendor_id();

			List<User> agents = userRepository.findByVendorId(vendorID);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}
	
	public ServiceRelatedObjects getAllServiceRelatedObjects(Long vendorId) {			

		ServiceRelatedObjects serviceObj = new ServiceRelatedObjects();

		try {		
			
			    Set<Long> ouIdList = new HashSet<Long>() ;
			    Set<Long> businessGroupIdList = new HashSet<Long>() ;
			    Set<Long> invIdList = new HashSet<Long>() ;
			    
			    ApSuppliers supplier = apsuppliersrepository.findByVendorIDId(vendorId.toString());
			    
			    List<SupplierSites> supplier_sites = supplierSitesRepository.findSites(vendorId);
			    
			    List<ApSuppliers> suppliers = new ArrayList<ApSuppliers>();
			    
			    if(supplier != null ) {
			    	
			    	suppliers.add(supplier);
			    }
			    
			    for(SupplierSites site : supplier_sites) {
			    	
			    	ouIdList.add(site.getOu_id());
			    }
				
			    List<OperatingUnits> operatingUnits = operatingUnitsRepository.findAllWithOu(ouIdList);
			    
                for(OperatingUnits ou : operatingUnits) {
			    	
                	businessGroupIdList.add(ou.getBusiness_group_id());
			    }
			    
				List<AgentListProjection> buyers = poAgentsRepository.findBuyersWithBusinessGroup(businessGroupIdList);
			
				List<POLineTypes> filteredPoLineTypes = new ArrayList<POLineTypes>();				

				List<MasterOrganizations> organizations = masterOrganizationsRepository.findAllWithOU(ouIdList);
				
                for(MasterOrganizations inv : organizations) {
			    	
                	invIdList.add(inv.getOrganization_Id());
			    }

				List<Locations> locations = locationsRepository.findAllWithInvIdList(invIdList);
				
				List<POLineTypes> pOLineTypes = pOLineTypesRepository.findAllPOLineTypes();
				
				List<Currencies> currencies = currenciesRepository.findAllCurrencies();
				
				List<PurchasingCategory> categories = purchasingCategoryRepository.findAllPurchasingCategories();
				
				for(POLineTypes type : pOLineTypes) {
					
					if(AppConstants.LInE_TYPE_FIXEDPRICE.equals(type.getLine_type()) ){
						
						filteredPoLineTypes.add(type);
						
					}
				}
				
                for(PurchasingCategory category : categories) {
					
					category.setSegment1(category.getSegment1() + "." + category.getSegment2());
					
				}
				
				serviceObj.setBuyers(buyers);
				serviceObj.setSupplier_sites(supplier_sites);
				serviceObj.setOrganizations(organizations);
				serviceObj.setOperatingUnits(operatingUnits);
				serviceObj.setLocations(locations);
				serviceObj.setLineTypes(filteredPoLineTypes);
				serviceObj.setCurrencies(currencies);
				serviceObj.setSuppliers(suppliers);
				serviceObj.setCategories(categories);

									

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ related objects");
		}

		return serviceObj;

	}

	public List<OpenPODetails> getAllServices(Long vendorId, Long buyerId) {

		List<OpenPODetails> list = null;

		try {
			if (vendorId != null) {

				list = openPODetailsRepository.getAllServicesBySupplier(vendorId);

			} else if (buyerId != null) {

				list = openPODetailsRepository.getAllServicesByBuyer(buyerId.toString());
			}

		} catch (Exception e) {
			throw new AppException("Unable to get service details");
		}

       if(list == null) {
			
			list = new ArrayList<OpenPODetails>();
		}

		return list;

	}
	
	
	public List<OpenPODetails> getServiceLinesToView(Long serviceHeaderId) {

		List<OpenPODetails> list = null;

		try {			

				list = openPODetailsRepository.getServiceLinesToView(serviceHeaderId);
						

		} catch (Exception e) {
			throw new AppException("Unable to get service details");
		}

       if(list == null || list.size() == 0) {
			
			list = new ArrayList<OpenPODetails>();
			
		} else {
			
			// checking if there is a any service line  
			boolean isThereServicLine = isThereServicLine(list.get(0));
			
			// if there is no line then return null
			if(!isThereServicLine) {
				
				list = new ArrayList<OpenPODetails>();
			}
			
		}

		return list;

	}

	
	
	private void sendNewServiceMailByVendor(List<OpenPODetails> list , HttpServletRequest request) {

		if (list != null && list.size() > 0) {

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User supplier = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();
			String subject = new String();
			
			OpenPODetails openPO = list.get(0);			
			String vendorName = openPO.getVendor_name();			

		    subject = AppConstants.supplierNewServiceSubject.replace("?vendor_name", vendorName);				 			
			
			String text = emailHtmlLoader.loadNewServiceText(list);

			emailFrom = supplier.getEmail();

			long agentId = Long.parseLong(list.get(0).getBuyer_id());

			List<User> agents = userRepository.findByAgentId(agentId);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}


	
	public AsnResponse generateScnNumber(List<AsnRequest> list) {
		OpenPODetails openPODetails = null;
		String scnNUmber = null;

		for (AsnRequest asnRequest : list) {
			try {

				openPODetails = openPODetailsRepository.findByHeaderIdAndforASNcreations(asnRequest.getUnique_id(),
						asnRequest.getPo_line_location_id(), asnRequest.getVendor_id(),asnRequest.getBuyer_id());

				if (scnNUmber == null) {
					scnNUmber = getScnNumber();
				}
				
				if(asnRequest.getShipment_amount() == null) {
					asnRequest.setShipment_amount(openPODetails.getScn_reserve_amount());
				}
							
				double scnReserveAmount = openPODetails.getScn_reserve_amount() - asnRequest.getShipment_amount();
				
				openPODetails.setScn_reserve_amount(scnReserveAmount);
				
				openPODetails.setScn(scnNUmber);
				
                if(asnRequest.getSupp_invoice_num() != null) {
					
					openPODetails.setSupp_invoice_num(asnRequest.getSupp_invoice_num());
					
				}
				
				if(asnRequest.getSupp_shipped_date() == null) {
					
					java.util.Date date = new Date();
					
//					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					asnRequest.setSupp_shipped_date(date);
					
					openPODetails.setSupp_shipped_date(date);
					
				}else {
					
					openPODetails.setSupp_shipped_date(asnRequest.getSupp_shipped_date());
				}
				
				// latest shipment qty set to po to show it on ASN upload mail
				openPODetails.setShipment_amount(asnRequest.getShipment_amount());
				
				createSCN(asnRequest , openPODetails , scnNUmber);

				createShipment(openPODetails , asnRequest,  scnNUmber);

				openPODetailsRepository.save(openPODetails);
			} catch (Exception e) {
				
				throw new AppException("Unable to generate SCN ");
			}
		}
		
		AsnResponse asnResponse = new AsnResponse(scnNUmber);
		return asnResponse;

	}
	
	
	public String getScnNumber() {
		
		long next_number = getNextAsnNumber();
		
		final StringBuffer usTimeStr = new StringBuffer("").append(next_number);
		
		return usTimeStr.toString();
		
	}	
	
    private void createSCN(AsnRequest asnRequest , OpenPODetails openPODetails ,String scnNUmber ) {
		
		ASNDetails scn = new ASNDetails();
		scn.setAsn_amount(asnRequest.getShipment_amount());
		scn.setPo_header_id(openPODetails.getPo_header_id());
		scn.setPoLineLocationId(openPODetails.getPoLineLocationId());
		scn.setAsn(scnNUmber);
		scn.setOpen_po_id(openPODetails.getId());
		
		asnDetailsRepository.save(scn);
		
	}
    
    public AsnResponse generateScnNumberWithoutPO(Long serviceHeaderId , HttpServletRequest request) {
    	
    	List<OpenPODetails> services = openPODetailsRepository.getServiceLinesToView(serviceHeaderId);
		
		String scnNUmber = null;
		
		List<OpenPODetails> newList = new ArrayList<OpenPODetails>();

		for(OpenPODetails openPODetails : services) {
			try {

				if (scnNUmber == null) {
					scnNUmber = getScnNumber();
				}																
				
				openPODetails.setScn(scnNUmber);	
				
				AsnRequest asnRequest = new AsnRequest();
				asnRequest.setShipment_amount(openPODetails.getShipment_amount());
				
				createSCN(asnRequest , openPODetails , scnNUmber);

//				createShipment(openPODetails , asnRequest,  scnNUmber);
				
				openPODetailsRepository.save(openPODetails);
				
				newList.add(openPODetails);

			} catch (Exception e) {

				throw new AppException("Unable to generate SCN ");
			}
		}	
		
		
		try {
			sendNewServiceMailByVendor(services ,  request);
		} catch (Exception ex) {
			logger.info("***************** Unable to send mail *********************\n" + ex);
		}	
						
		AsnResponse asnResponse = new AsnResponse(scnNUmber);
		
		return asnResponse;

	}



	public List<OpenPODetails> toOpenPoList(final Iterable<OpenPODetails> iterable) {
		
		return StreamSupport.stream(iterable.spliterator(), false).collect(Collectors.toList());
	}

	public List<POLineTypes> getAsnFilterList() {

		List<POLineTypes> pOLineTypes;
		
		List<POLineTypes> filterpOLineTypes = new ArrayList<POLineTypes>();

		try {

			pOLineTypes = pOLineTypesRepository.findAllPOLineTypes();
			
			for(POLineTypes polineType : pOLineTypes) {
				
				if( AppConstants.LInE_TYPE_FIXEDPRICE.equals(polineType.getLine_type()) || 
						AppConstants.LINE_TYPE_GOODS.equals(polineType.getLine_type()) ||
						AppConstants.LINE_TYPE_AMOUNT_BASED.equals(polineType.getLine_type())){
					
					filterpOLineTypes.add(polineType);
				}
			}

		} catch (Exception e) {
			throw new AppException("Unable to get PO Line Types ");
		}

		return filterpOLineTypes;

	}
	
	
	public OpenPODetails updateServiceLineByByer(OpenPODetails openPO) {		
		
		
		    OpenPODetails service = openPODetailsRepository.findByCustomId(openPO.getId());
		    
		    service.setItem_description(openPO.getItem_description());
		    service.setCurrency_code(openPO.getCurrency_code());
		    service.setTax(openPO.getTax());
		    service.setNeed_by_date(openPO.getNeed_by_date());
		    service.setCategory_id(openPO.getCategory_id());
		    // category name
		    service.setSegment1(openPO.getSegment1());
			
			// fixed price service
			if ((service.getAmount() != null && service.getAmount() > 0)
					&& (service.getQty_ordered() == null || service.getQty_ordered() == 0)) {
				
				service.setShipment_amount(openPO.getAmount());
				service.setAmount(openPO.getAmount());
				
            // IGC service
			} else if ((service.getQty_ordered() != null && service.getQty_ordered() > 0)
					&& (service.getAmount() == null || service.getAmount() == 0)) {
				
				service.setShipment_qty(openPO.getQty_ordered());
				service.setQty_ordered(openPO.getQty_ordered());

			}			
		
		
		try {					
			
			return openPODetailsRepository.save(service);
			
		} catch (Exception e) {
			throw new AppException("Unable to update service line details");
		}

	}
	
	
	public OpenPODetails updateHeaderServiceByByer(OpenPODetails openPO) {		
		
		
		List<OpenPODetails> services = openPODetailsRepository.getServiceLinesToView(openPO.getService_header_id());

		for (OpenPODetails service : services) {

			service.setOu_name(openPO.getOu_name());
			service.setShip_to_location_id(openPO.getShip_to_location_id());
			service.setShip_to_location_code(openPO.getShip_to_location_code());
			service.setOrganization_name(openPO.getOrganization_name());
			service.setBuyer_id(openPO.getBuyer_id());
			service.setBuyer(openPO.getBuyer());
		}

		try {

			openPODetailsRepository.saveAll(services);

		} catch (Exception e) {
			throw new AppException("Unable to update header service details");
		}

		return openPO;

	}

	
	
	public void submitRequisitionByByer(Long serviceHeaderId) {

		List<OpenPODetails> services = openPODetailsRepository.findAllServiceByHeaderId(serviceHeaderId);		

		try {
			 
			for(OpenPODetails service : services) {
				
				AsnRequest asnRequest = new AsnRequest();
				asnRequest.setShipment_amount(service.getShipment_amount());
				
                
				asnRequest.setSupp_invoice_num(service.getSupp_invoice_num());
				asnRequest.setSupp_shipped_date(service.getSupp_shipped_date());

				// move shipment details when submit to create PR from buyer side
				// If it is any update on SCN without PO in buyer side , then that will be affect to the shipment
				createShipment(service , asnRequest,  service.getScn());
				
			}
			
			 dataMoveForPoRequisition(services);

		} catch (Exception e) {
			throw new AppException("Unable to submit service details");
		}

	}
	
	
	private void dataMoveForPoRequisition(List<OpenPODetails> list) {
		
		for (OpenPODetails service : list) {

			PORequisitionOracle porequisition = new PORequisitionOracle();
			BeanUtils.copyProperties(service, porequisition);

			try {
				porequisition.setInterface_source_code(AppConstants.INTERFACE_SOURCE_CODE);
				porequisition.setDestination_type_code(AppConstants.DESTINATION_TYPE_CODE);
				porequisition.setAuthorization_status(AppConstants.AUTHORIZATION_STATUS);
				porequisition.setCode_combination_id(AppConstants.CODE_COMBINATION_ID);
				porequisition.setCategory_id(service.getCategory_id());
				porequisition.setError_flag("N");
				porequisition.setDeliver_to_requestor(porequisition.getBuyer());

//				pORequisitionOracleRepository.save(porequisition);
				
				service.setSubmit_for_requisition("Y");
				service.setProcessStatus("C");
				
				openPODetailsRepository.save(service);
				
			} catch (Exception ex) {
				logger.info(
						"***************** Error while move po requisition from Mysql to Oracle ********************* : "
								+ service.getId() + " \n" + ex);
			}

		}

	}
	
	
	private void setServiceLineDetails(OpenPODetails service, long line_no, String vendorName , OpenPODetails headerService) {

		Long maxId = openPODetailsRepository.findMaxId();

		maxId = maxId == null ? 1 : maxId + 1;

		service.setPo_line_num(line_no);
		service.setShipment_num(1L);
		service.setVendor_name(vendorName);
		service.setPoLineLocationId(maxId);
		service.setBuyer_id(headerService.getBuyer_id());
		service.setBuyer(headerService.getBuyer());
		service.setOu_name(headerService.getOu_name());
		service.setVendor_id(headerService.getVendor_id());
		service.setVendor_site_code(headerService.getVendor_site_code());
		service.setShip_to_location_id(headerService.getShip_to_location_id());
		service.setShip_to_location_code(headerService.getShip_to_location_code());
		service.setBill_to_location_id(headerService.getBill_to_location_id());
		service.setBill_to_location_code(headerService.getBill_to_location_code());
		service.setOrganization_name(headerService.getOrganization_name());
		// supplier invoice and date details
		service.setSupp_invoice_num(headerService.getSupp_invoice_num());
		service.setSupp_shipped_date(headerService.getSupp_shipped_date());
		
		
		setServiceCommonLineDetails(service);

		setServiceAmountOrQty(service);
	}

	private void setServiceAmountOrQty(OpenPODetails service) {

		// fixed price service
		if ((service.getAmount() != null && service.getAmount() > 0)
				&& (service.getQty_ordered() == null || service.getQty_ordered() == 0)) {

			service.setPending_amount(service.getAmount());
			service.setShipment_amount(service.getAmount());
			service.setScn_reserve_amount(0.0);

			// IGC service
		} else if ((service.getQty_ordered() != null && service.getQty_ordered() > 0)
				&& (service.getAmount() == null || service.getAmount() == 0)) {

			service.setPending_qty(service.getQty_ordered());
			service.setShipment_qty(service.getQty_ordered());
			service.setAsn_reserve_qty(0.0);

		}
	}

	
	private void setServiceCommonLineDetails(OpenPODetails service ) {

		service.setIs_service("Y");
		service.setAck("Y");
		service.setProcessStatus("I");
		
	}
	
	private boolean isThereServicLine(OpenPODetails service ) {

		// fixed price service
//		if ((service.getAmount() != null && service.getAmount() > 0)
//				|| (service.getQty_ordered() != null || service.getQty_ordered() > 0)) {
//
//			return true;
//		}
		
		if ( service.getAmount() == null && service.getQty_ordered() == null) {
		
			return false;
			
		}
		
		return true;
		
	}
	
	/*public String callInvoiceAttachmentProc(String fileName , String asnOrscn) {
		
		String errbuf = "";
		String retcode = "";
		String v_file_name = fileName;
		Long v_header_id = Long.parseLong(asnOrscn);
		
		try {
			
		JdbcTemplate jdbcTemplate = new JdbcTemplate(oraclelDataSourceConfig.ordersDataSource());
		
		   jdbcTemplate.update("call XX_Receipt_attachment_prc (?, ? , ? , ?)", errbuf, retcode , v_file_name , v_header_id);		
		}catch (Exception ex) {
			logger.info("***************** Unable call attachment procedure *********************\n" + ex);
		}
		
		return "Success";
	}*/
	
	
	private Long getUserIdFromRequest(HttpServletRequest request) {
		
		String bearerToken = request.getHeader("Authorization");
		
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			
			String jwt = bearerToken.substring(7, bearerToken.length());
			
			Long userId = tokenProvider.getUserIdFromJWT(jwt);
			
			return userId;
		}
		
		
		return null;
	}
	

	private boolean isFixedPriceService(OpenPODetails openPO) {

		boolean isFxedPriceService = false;
		String fixedPriceType = AppConstants.LInE_TYPE_FIXEDPRICE;

		if (fixedPriceType.equals(openPO.getLine_type())) {

			isFxedPriceService = true;
		}

		return isFxedPriceService;

	}
	
	/*public  String encodeFileToBase64(File file) {
	    try {
	        byte[] fileContent = Files.readAllBytes(file.toPath());
	        String base64Str = Base64.getEncoder().encodeToString(fileContent);
	        System.out.println(base64Str);
	        return base64Str;
	    } catch (IOException e) {
	        throw new IllegalStateException("could not read file " + file, e);
	    }
	}*/
	
	public ResponseEntity<?> updateINVUploadToShipment(String asn ) {
		
		SCAUtil scaUtil = new SCAUtil();
		
		try {
		List<ShipMentTbl> shipList = shipMentTblRepository.getShipMentByOnlyASN(asn);
		
		for(ShipMentTbl shipment : shipList) {
				
				shipment.setIs_inv_uploaded("Y");
				shipment.setInv_upload_date(new Date());
		}
		
		shipMentTblRepository.saveAll(shipList);
		
		} catch (Exception e) {
			
			logger.error("***************** Unable to update INV doc!  *********************\n" + e);

			String msg = scaUtil.getErrorMessage(e);

			return new ResponseEntity(new ApiResponse(false, "Unable to update INV doc!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity(new ApiResponse(true, "INV doc updated!"),
				HttpStatus.OK);
	}

}
