package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.OpenCreditMysql;

@Repository
public interface OpenCreditMysqlRepository extends CrudRepository<OpenCreditMysql, Long> {
	   
	
    @Override
    Iterable<OpenCreditMysql> findAll();
   

    @Query(value = "select * from OPEN_CREDIT_TBL where HEADER_ID =:header_id ", nativeQuery = true)
    OpenCreditMysql getOpenCreditById(@Param("header_id") Long header_id);
    
    @Query(value = "select * from OPEN_CREDIT_TBL WHERE VENDOR_ID = :vendor_id", nativeQuery = true)
    List<OpenCreditMysql> getOpenCreditByVendor(@Param("vendor_id") String vendor_id);


}