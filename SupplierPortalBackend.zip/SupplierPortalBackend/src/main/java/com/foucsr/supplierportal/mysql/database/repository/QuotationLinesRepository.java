package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.QuotationLines;

@Repository
public interface QuotationLinesRepository extends CrudRepository<QuotationLines, Long> {

	
    @Override
    Iterable<QuotationLines> findAll();
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE STATUS = :status AND RFQ_HEADER_ID IN (select RFQ_HEADER_ID from RFQ_VENDORS where VENDOR_ID = :vendorId) ORDER BY RFQ_NUMBER , LINE_NUM , SHIPMENT_NUM", nativeQuery = true)
    List<QuotationLines> findAllLines(@Param("vendorId") Long vendorId , @Param("status") String status);
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId and RFQ_LINE_LOCATION_ID = :rfq_line_location_id", nativeQuery = true)
    QuotationLines findLine(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId , @Param("rfq_line_location_id") Long rfq_line_location_id);            
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE RFQ_HEADER_ID in (SELECT RFQ_HEADER_ID FROM QUOTATION_LINE_DETAILS  WHERE RFQ_HEADER_ID = :rfqHeaderId and VENDOR_ID = :vendorId ) ", nativeQuery = true)
    List<QuotationLines> findLinesByHeaderIdAndVenor(@Param("rfqHeaderId") Long rfqHeaderId , @Param("vendorId") Long vendorId );
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE RFQ_NUMBER = :rfqNo AND AGENT_ID = :agentId ORDER BY RFQ_NUMBER , LINE_NUM , SHIPMENT_NUM", nativeQuery = true)
    List<QuotationLines> findAllQuotationsByByerWithRFQno(@Param("rfqNo") String rfqNo , @Param("agentId") Long agentId);
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE AGENT_ID = :agentId ORDER BY RFQ_NUMBER , LINE_NUM , SHIPMENT_NUM", nativeQuery = true)
    List<QuotationLines> findAllQuotationsByByer(@Param("agentId") Long agentId);
    
    @Query(value = "SELECT * FROM QUOTATION_LINES  WHERE RFQ_HEADER_ID = :rfqHeaderId ORDER BY RFQ_NUMBER , LINE_NUM , SHIPMENT_NUM", nativeQuery = true)
    List<QuotationLines> findAllQuotationLinesToActive(@Param("rfqHeaderId") Long rfqHeaderId);



}