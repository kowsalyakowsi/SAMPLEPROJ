package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.foucsr.supplierportal.model.audit.DateAudit;

@Entity
@Table(name = "SUPPLIERS_REGISTER" , uniqueConstraints = {
            @UniqueConstraint(columnNames = {
                "EMAIL"
            })
    })

public class SuppliersRegister extends DateAudit {

	@Id
	@SequenceGenerator(name = "AP_SUPPLIERS_REGISTER_SEQ", sequenceName = "AP_SUPPLIERS_REGISTER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AP_SUPPLIERS_REGISTER_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "VENDOR_NAME")
	private String vendor_name;

	@Column(name = "VENDOR_NAME_ALT")
	private String vendor_name_alt;

	@Column(name = "MIN_ORDER_AMOUNT")
	private Double min_order_amount;

	@Column(name = "INVOICE_CURRENCY_CODE")
	private String invoice_currency_code;

	@Column(name = "PAYMENT_CURRENCY_CODE")
	private String payment_currency_code;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE_ACTIVE")
	private Date start_date_active;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE_ACTIVE")
	private Date end_date_active;

	@Column(name = "COMPANY_REGISTRATION_NUMBER")
	private String company_registration_number;
	
	@Column(name = "ORG_URL")
	private String org_url;
	
	@Column(name = "TERRITORY_CODE")
	private String territory_code;

	@Column(name = "TERRITORY_SHORT_NAME")
	private String territory_short_name;

	
	@Column(name = "DUNS")
	private String duns;
	
	@Column(name = "VAT_REGISTRATION_NUM")
	private String vat_registration_num;
	
	// tax payer id
	@Column(name = "NUM_1099")
	private String num_1099;
	
	// **************************************SITE details start**************************************
	@Column(name = "VENDOR_SITE_CODE")
	private String vendor_site_code;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "ADDRESS")
	private String address;		
	
	@Column(name = "ADDRESS_LINE1")
	private String address_line1;
	
	@Column(name = "ADDRESS_LINE2")
	private String address_line2;
	
	@Column(name = "CITY")
	private String city;
	
	// operating unit
	@Column(name = "ORG_ID")
	private Long org_id;
	
	@Column(name = "ORG_NAME")
	private String org_name;
	// **************************************SITE details end**************************************
	
	
	
	
	
	// **************************************Contact details start**************************************
	@Column(name = "FIRST_NAME")
	private String first_name;

	@Column(name = "MIDDLE_NAME")
	private String middle_name;

	@Column(name = "LAST_NAME")
	private String last_name;

	// department
	@Column(name = "CONTACT_TITLE")
	private String contact_title;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "PHONE_CODE")
	private String phone_code;

	@Column(name = "PHONE_NO")
	private String phone_no;

	@Column(name = "EXTENSION")
	private String extension;

	@Column(name = "FAX_NO")
	private String fax_no;
	// **************************************Contact details end**************************************


	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@Column(name="IS_SUBMIT")
	private String is_submit;
	
	@Column(name="BUYER_NAME")
	private String buyer_name;
	
	@Column(name="BUYER_ID")
	private Long buyer_id;
	
	@Column(name="USER_NAME")
	private String user_name;
	
	@Column(name = "IS_SEND_TO_SUPPLIER_CREATION")
	private String is_send_to_supplier_creation;
	
	
	@Column(name="TOKEN")
	private String token;
	
	@Column(name = "PAY_SITE_FLAG")
	private String pay_site_flag;
	
	@Column(name = "RFQ_ONLY_SITE_FLAG")
	private String rfq_only_site_flag;
	
	@Column(name = "PURCHASING_SITE_FLAG")
	private String purchasing_site_flag;
	
	
	@OneToMany(cascade = CascadeType.REFRESH , mappedBy = "supplierRegistration" )
	private List<SupplierProductsRegister> products;
	
	@OneToMany(cascade = CascadeType.REFRESH , mappedBy = "supplierRegistration" )
	private List<SupplierBankDetailsRegister> banks;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_name_alt() {
		return vendor_name_alt;
	}

	public void setVendor_name_alt(String vendor_name_alt) {
		this.vendor_name_alt = vendor_name_alt;
	}

	public Double getMin_order_amount() {
		return min_order_amount;
	}

	public void setMin_order_amount(Double min_order_amount) {
		this.min_order_amount = min_order_amount;
	}

	public String getInvoice_currency_code() {
		return invoice_currency_code;
	}

	public void setInvoice_currency_code(String invoice_currency_code) {
		this.invoice_currency_code = invoice_currency_code;
	}

	public String getPayment_currency_code() {
		return payment_currency_code;
	}

	public void setPayment_currency_code(String payment_currency_code) {
		this.payment_currency_code = payment_currency_code;
	}

	public Date getStart_date_active() {
		return start_date_active;
	}

	public void setStart_date_active(Date start_date_active) {
		this.start_date_active = start_date_active;
	}

	public Date getEnd_date_active() {
		return end_date_active;
	}

	public void setEnd_date_active(Date end_date_active) {
		this.end_date_active = end_date_active;
	}

	public String getCompany_registration_number() {
		return company_registration_number;
	}

	public void setCompany_registration_number(String company_registration_number) {
		this.company_registration_number = company_registration_number;
	}

	public String getOrg_url() {
		return org_url;
	}

	public void setOrg_url(String org_url) {
		this.org_url = org_url;
	}

	public String getTerritory_code() {
		return territory_code;
	}

	public void setTerritory_code(String territory_code) {
		this.territory_code = territory_code;
	}

	public String getTerritory_short_name() {
		return territory_short_name;
	}

	public void setTerritory_short_name(String territory_short_name) {
		this.territory_short_name = territory_short_name;
	}

	public String getDuns() {
		return duns;
	}

	public void setDuns(String duns) {
		this.duns = duns;
	}

	public String getVat_registration_num() {
		return vat_registration_num;
	}

	public void setVat_registration_num(String vat_registration_num) {
		this.vat_registration_num = vat_registration_num;
	}

	public String getNum_1099() {
		return num_1099;
	}

	public void setNum_1099(String num_1099) {
		this.num_1099 = num_1099;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress_line1() {
		return address_line1;
	}

	public void setAddress_line1(String address_line1) {
		this.address_line1 = address_line1;
	}

	public String getAddress_line2() {
		return address_line2;
	}

	public void setAddress_line2(String address_line2) {
		this.address_line2 = address_line2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getContact_title() {
		return contact_title;
	}

	public void setContact_title(String contact_title) {
		this.contact_title = contact_title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone_code() {
		return phone_code;
	}

	public void setPhone_code(String phone_code) {
		this.phone_code = phone_code;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getFax_no() {
		return fax_no;
	}

	public void setFax_no(String fax_no) {
		this.fax_no = fax_no;
	}

	@JsonIgnore
	public List<SupplierProductsRegister> getProducts() {
		return products;
	}

	public void setProducts(List<SupplierProductsRegister> products) {
		this.products = products;
	}

	public String getIs_submit() {
		return is_submit;
	}

	public void setIs_submit(String is_submit) {
		this.is_submit = is_submit;
	}

	@JsonIgnore
	public List<SupplierBankDetailsRegister> getBanks() {
		return banks;
	}

	public void setBanks(List<SupplierBankDetailsRegister> banks) {
		this.banks = banks;
	}

	public String getBuyer_name() {
		return buyer_name;
	}

	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}

	public Long getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getIs_send_to_supplier_creation() {
		return is_send_to_supplier_creation;
	}

	public void setIs_send_to_supplier_creation(String is_send_to_supplier_creation) {
		this.is_send_to_supplier_creation = is_send_to_supplier_creation;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getOrg_id() {
		return org_id;
	}

	public void setOrg_id(Long org_id) {
		this.org_id = org_id;
	}

	public String getOrg_name() {
		return org_name;
	}

	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}

	public String getPay_site_flag() {
		return pay_site_flag;
	}

	public void setPay_site_flag(String pay_site_flag) {
		this.pay_site_flag = pay_site_flag;
	}

	public String getRfq_only_site_flag() {
		return rfq_only_site_flag;
	}

	public void setRfq_only_site_flag(String rfq_only_site_flag) {
		this.rfq_only_site_flag = rfq_only_site_flag;
	}

	public String getPurchasing_site_flag() {
		return purchasing_site_flag;
	}

	public void setPurchasing_site_flag(String purchasing_site_flag) {
		this.purchasing_site_flag = purchasing_site_flag;
	}

	
}