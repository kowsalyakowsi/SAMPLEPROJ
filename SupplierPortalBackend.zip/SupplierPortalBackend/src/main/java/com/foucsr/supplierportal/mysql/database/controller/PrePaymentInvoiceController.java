package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.PrePaymentInvoice;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PrePaymentInvoiceService;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@RestController
@RequestMapping("/PrePaymentDetails/Service")
@CrossOrigin
public class PrePaymentInvoiceController {

	@Autowired
	private PrePaymentInvoiceService prePaymentInvoiceService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	
	@PostMapping("/getPrePaymentByDate")
	public List<PrePaymentInvoice> getPrePaymentsByDate(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return prePaymentInvoiceService.getClosedPoByDate(byDateRequest);

	}
	
	
}
