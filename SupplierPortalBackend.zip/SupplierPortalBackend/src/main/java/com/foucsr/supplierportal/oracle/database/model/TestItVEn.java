package com.foucsr.supplierportal.oracle.database.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(namespace = "http://www.w3.org/2003/05/soap-envelope" , name = "")
public class TestItVEn {

	@XmlElementWrapper(name = "IT_VEN")
	@XmlElement(name = "item")
	private List<TestElementXml> IT_VEN;

	public List<TestElementXml> getIT_VEN() {
		return IT_VEN;
	}

	public void setIT_VEN(List<TestElementXml> iT_VEN) {
		IT_VEN = iT_VEN;
	}
}