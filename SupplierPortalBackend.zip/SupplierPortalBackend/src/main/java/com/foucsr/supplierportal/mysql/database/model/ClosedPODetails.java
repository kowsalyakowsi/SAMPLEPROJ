package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "CLOSED_PO_DETAILS")
public class ClosedPODetails {

	@Id
	// commented to fix ack service issue
//	@SequenceGenerator(name = "CLOSED_PO_DETAILS_SEQ", sequenceName = "CLOSED_PO_DETAILS_SEQ", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CLOSED_PO_DETAILS_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "OU_NAME")
	private String ou_name;

	@Column(name = "PO_HEADER_ID")
	private Long po_header_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "PO_DATE")
	private Date po_date;

	@Column(name = "PO_NUMBER")
	private String po_number;

	@Column(name = "VENDOR_NAME")
	private String vendor_name;

	@Column(name = "VENDOR_ID")
	private Long vendor_id;

	@Column(name = "VENDOR_SITE_CODE")
	private String vendor_site_code;

	@Column(name = "BUYER")
	private String buyer;

	@Column(name = "BUYER_ID")
	private Long buyer_id;

	@Column(name = "PO_LINE_NUM")
	private Long po_line_num;

	@Column(name = "ITEM")
	private String item;

	@Column(name = "ITEM_DESCRIPTION")
	private String item_description;

	@Column(name = "PO_UOM")
	private String po_uom;

	@Column(name = "UNIT_PRICE")
	private Double unit_price;

	@Column(name = "QTY_ORDERED")
	private Double qty_ordered;

	@Column(name = "QTY_RECEIVED")
	private Double qty_received;

	@Column(name = "ORGANIZATION_NAME")
	private String organization_name;

	@Column(name = "RECEIPT_NUM")
	private String receipt_num;

	@Column(name = "SHIPMENT_NUM")
	private String shipment_num;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "RECEIPT_DATE")
	private Date receipt_date;

	@Column(name = "INVOICE_NUM")
	private String invoice_num;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "INVOICE_DATE")
	private Date invoice_date;

	@Column(name = "PAYMENT_NUM")
	private Long payment_num;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "PAYMENT_DATE")
	private Date payment_date;

	@Column(name = "PO_STATUS")
	private String po_status;

	@Column(name = "RECEIPT_QUANTITY")
	private Double receipt_quantity;

	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@Column(name = "INVOICE_AMOUNT")
	private Double invoice_amount;
	
	@Column(name = "PAID_AMOUNT")
	private Double paid_amount;
	
	@Column(name="SHIPMENT_LINE_NUM")
	private Long shipmentLineNo;
	
	@Column(name="REVISION_NO")
	private Long revisionNo;
	
	@Column(name="CURRENCY_CODE")
	private String currency_code;	
	
	@Column(name = "LINE_TYPE")
	private String line_type;
	
	@Column(name="AMOUNT")
	private Double amount;
	
	public ClosedPODetails() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public Long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	public String getPo_number() {
		return po_number;
	}

	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public Long getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public Double getQty_received() {
		return qty_received;
	}

	public void setQty_received(Double qty_received) {
		this.qty_received = qty_received;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public String getReceipt_num() {
		return receipt_num;
	}

	public void setReceipt_num(String receipt_num) {
		this.receipt_num = receipt_num;
	}

	public String getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(String shipment_num) {
		this.shipment_num = shipment_num;
	}

	public Date getReceipt_date() {
		return receipt_date;
	}

	public void setReceipt_date(Date receipt_date) {
		this.receipt_date = receipt_date;
	}

	public String getInvoice_num() {
		return invoice_num;
	}

	public void setInvoice_num(String invoice_num) {
		this.invoice_num = invoice_num;
	}

	public Date getInvoice_date() {
		return invoice_date;
	}

	public void setInvoice_date(Date invoice_date) {
		this.invoice_date = invoice_date;
	}

	public Long getPayment_num() {
		return payment_num;
	}

	public void setPayment_num(Long payment_num) {
		this.payment_num = payment_num;
	}

	public Date getPayment_date() {
		return payment_date;
	}

	public void setPayment_date(Date payment_date) {
		this.payment_date = payment_date;
	}

	public String getPo_status() {
		return po_status;
	}

	public void setPo_status(String po_status) {
		this.po_status = po_status;
	}

	public Double getReceipt_quantity() {
		return receipt_quantity;
	}

	public void setReceipt_quantity(Double receipt_quantity) {
		this.receipt_quantity = receipt_quantity;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public Double getInvoice_amount() {
		return invoice_amount;
	}

	public void setInvoice_amount(Double invoice_amount) {
		this.invoice_amount = invoice_amount;
	}

	public Double getPaid_amount() {
		return paid_amount;
	}

	public void setPaid_amount(Double paid_amount) {
		this.paid_amount = paid_amount;
	}

	public Long getShipmentLineNo() {
		return shipmentLineNo;
	}

	public void setShipmentLineNo(Long shipmentLineNo) {
		this.shipmentLineNo = shipmentLineNo;
	}

	@Override
	public String toString() {
		return "ClosedPODetails [id=" + id + ", ou_name=" + ou_name + ", po_header_id=" + po_header_id + ", po_date="
				+ po_date + ", po_number=" + po_number + ", vendor_name=" + vendor_name + ", vendor_id=" + vendor_id
				+ ", vendor_site_code=" + vendor_site_code + ", buyer=" + buyer + ", buyer_id=" + buyer_id
				+ ", po_line_num=" + po_line_num + ", item=" + item + ", item_description=" + item_description
				+ ", po_uom=" + po_uom + ", unit_price=" + unit_price + ", qty_ordered=" + qty_ordered
				+ ", qty_received=" + qty_received + ", organization_name=" + organization_name + ", receipt_num="
				+ receipt_num + ", shipment_num=" + shipment_num + ", receipt_date=" + receipt_date + ", invoice_num="
				+ invoice_num + ", invoice_date=" + invoice_date + ", payment_num=" + payment_num + ", payment_date="
				+ payment_date + ", po_status=" + po_status + ", receipt_quantity=" + receipt_quantity
				+ ", processStatus=" + processStatus + ", invoice_amount=" + invoice_amount + ", paid_amount="
				+ paid_amount + ", shipmentLineNo=" + shipmentLineNo + "]";
	}

	public Long getRevisionNo() {
		return revisionNo;
	}

	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}


	
	

}