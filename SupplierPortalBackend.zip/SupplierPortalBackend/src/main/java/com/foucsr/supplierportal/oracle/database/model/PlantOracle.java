package com.foucsr.supplierportal.oracle.database.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PlantOracle {

	@JsonProperty("PLANT")
	private String plant;

	@JsonProperty("PLANT_DESP")
	private String plant_desp;
	
	@JsonProperty("PSTAT")
	private String pstat;

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlant_desp() {
		return plant_desp;
	}

	public void setPlant_desp(String plant_desp) {
		this.plant_desp = plant_desp;
	}

	public String getPstat() {
		return pstat;
	}

	public void setPstat(String pstat) {
		this.pstat = pstat;
	}

		
}