package com.foucsr.supplierportal.mysql.database.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "PO_AGENTS", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "AGENT_ID"
            })
    })
public class PoAgents {
	
	@Id	
	@SequenceGenerator(name="PO_AGENTS_SEQ", sequenceName="PO_AGENTS_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PO_AGENTS_SEQ")	
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "AGENT_ID")
	private long agentId;
	
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="LAST_UPDATE_DATE")
	private Date lastUpdateDate;
	
	@Column(name="LAST_UPDATED_BY")
	private long lastUpdatedBy;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="CREATION_DATE")
	private Date creationDate;
	
	@Column(name="CREATED_BY")
	private long createdBy;
	
	@Column(name="LAST_UPDATE_LOGIN")
	private long lastUpdateLogin;
	
	@Column(name="LOCATION_ID")
	private Long locationId;
	
	@Column(name="CATEGORY_ID")
	private Long categoryId;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="START_DATE_ACTIVE")
	private Date startDateActive;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="END_DATE_ACTIVE")
	private Date endDateActive;
	
	@Column(name="IS_CONTRACT_OFFICER")
	private String isContractOfficer;	
	
	@Column(name="PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@Column(name="AGENT_NAME")
	private String agentName;
	
	@Column(name="BUSINESS_GROUP_ID")
	private Long business_group_id;
	
	public PoAgents() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getAgentId() {
		return agentId;
	}

	public void setAgentId(long agentId) {
		this.agentId = agentId;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public long getLastUpdateLogin() {
		return lastUpdateLogin;
	}

	public void setLastUpdateLogin(long lastUpdateLogin) {
		this.lastUpdateLogin = lastUpdateLogin;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Date getStartDateActive() {
		return startDateActive;
	}

	public void setStartDateActive(Date startDateActive) {
		this.startDateActive = startDateActive;
	}

	public Date getEndDateActive() {
		return endDateActive;
	}

	public void setEndDateActive(Date endDateActive) {
		this.endDateActive = endDateActive;
	}

	public String getIsContractOfficer() {
		return isContractOfficer;
	}

	public void setIsContractOfficer(String isContractOfficer) {
		this.isContractOfficer = isContractOfficer;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Long getBusiness_group_id() {
		return business_group_id;
	}

	public void setBusiness_group_id(Long business_group_id) {
		this.business_group_id = business_group_id;
	}

	
	
}