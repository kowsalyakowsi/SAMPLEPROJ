package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PrePaymentInvoiceOracle {

	private Long id;

	private String invoiceNumber;

	private String supplierName;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date invoiceDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date termsDate;

	private Double invoiceAmount;

	private String supplierSite;

	private long invoiceAging;

	private String poProcessStatus;

	private String paymentStatus;

	private long vendorId;

	public PrePaymentInvoiceOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Date getTermsDate() {
		return termsDate;
	}

	public void setTermsDate(Date termsDate) {
		this.termsDate = termsDate;
	}

	public Double getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(Double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getSupplierSite() {
		return supplierSite;
	}

	public void setSupplierSite(String supplierSite) {
		this.supplierSite = supplierSite;
	}

	public long getInvoiceAging() {
		return invoiceAging;
	}

	public void setInvoiceAging(long invoiceAging) {
		this.invoiceAging = invoiceAging;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}

}