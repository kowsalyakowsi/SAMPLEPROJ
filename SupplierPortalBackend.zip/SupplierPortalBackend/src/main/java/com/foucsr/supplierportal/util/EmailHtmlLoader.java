package com.foucsr.supplierportal.util;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;

@Component
public class EmailHtmlLoader {

	Logger logger = LoggerFactory.getLogger(EmailHtmlLoader.class);
	
	@Autowired
	private TemplateEngine templateEngine;

	public String getText(String templateName, String forgetPasswordContent) {

		Context context = new Context();

		String body = new String();

		if ("email/forgetpassword_template".equals(templateName)) {

			body = loadForgetPasswordText(context, templateName, forgetPasswordContent);
			
//			logger.info("***************** Email Template body *********************\n" + body);
			
		}

		return body;
	}

	private String loadForgetPasswordText(Context context, String templateName, String forgetPasswordContent) {
		
//		logger.info("***************** Email ForgetPassword Link *********************\n" + forgetPasswordContent);

		context.setVariable("password_link", forgetPasswordContent);
		String body = templateEngine.process(templateName, context);

		return body;

	}
	
	
	public String loadSupplierAckText(List<OpenPODetails> list , char ackOrReject) {

		String body = new String();
		
        if(list.size() > 0 && list.get(0).getPo_num() != null && list.get(0).getPo_line_num() != null && list.get(0).getShipment_num() != null) {
			
			Collections.sort(list, new OpenPoComparator());
			
		}

		if (list != null && list.size() > 0) {

			String text = new String();
			
			if ('Y' == ackOrReject) {

				text = list.get(0).getVendor_name() + " " + AppConstants.supplierAckReplaceText;

			} else if ('N' == ackOrReject) {

				text = list.get(0).getVendor_name() + " " + AppConstants.supplierRejectionReplaceText;
				
			} else if ('P' == ackOrReject) {

				text = list.get(0).getVendor_name() + " " + AppConstants.newPOText;
				
			} else if ('R' == ackOrReject) {

				text = list.get(0).getVendor_name() + " " + AppConstants.reminderPOText;
				
			} else if ('Z' == ackOrReject) {

				text = list.get(0).getVendor_name() + " " + AppConstants.rejectionActionText;
				
			}
			
			body = AppConstants.supplierBodyContent.replace("?supplier_ack", text);
			

			for (OpenPODetails openPO : list) {

				body = body + "<tr>\n";
				body = body + "<td>" + openPO.getPo_num() + "</td>\n";
				body = body + "<td>" + openPO.getPo_line_num() + "&" + openPO.getShipment_num() + "</td>\n";
				body = body + "<td>" + openPO.getItem() + "</td>\n";
				body = body + "<td>" + openPO.getItem_description() + "</td>\n";
				body = body + "<td>" + openPO.getQty_ordered() + "</td>\n";
				body = body + "<td>" + openPO.getUnit_price() + "</td>\n";
				body = body + "</tr>";

			}
			
			body = body + AppConstants.supplierBottomContent;
		}

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	public String loadSupplierChangeReqText(OpenPoChangeDetails openPoChangeDetails, char ack) {

		String body = new String();
		

		if (openPoChangeDetails != null && 'Y' == ack) {

			String text = new String();

			text = openPoChangeDetails.getBuyer() + " " + AppConstants.buyerChangeReqAccptText;

			body = AppConstants.supplierChangeReqContent.replace("?replace_text", text);

			body = loadChangeRequestBodyAndBottom(body, openPoChangeDetails);
		}
		
		else if (openPoChangeDetails != null && 'N' == ack) {

			String text = new String();
			
			text = openPoChangeDetails.getBuyer() + " " + AppConstants.buyerChangeReqRejectText;
				
			body = AppConstants.supplierChangeReqContent.replace("?replace_text", text);

			body = loadChangeRequestBodyAndBottom(body, openPoChangeDetails);
			
		} 
		
		else if (openPoChangeDetails != null) {

			String text = new String();
			
			text = openPoChangeDetails.getVendor_name() + " " + AppConstants.supplierChangeReqText;
				
			body = AppConstants.supplierChangeReqContent.replace("?replace_text", text);

			body = loadChangeRequestBodyAndBottom(body, openPoChangeDetails);
			
		} 

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	public String loadInvoiceUploadText(List<OpenPODetails> list, String asn , String scn) {

		String body = new String();
		
		if(list.size() > 0 && list.get(0).getPo_num() != null && list.get(0).getPo_line_num() != null && list.get(0).getShipment_num() != null) {
			
			Collections.sort(list, new OpenPoComparator());
			
		}
		

		if (list != null && list.size() > 0) {

			String text = new String();
				
		    text = list.get(0).getVendor_name() + " " + AppConstants.buyerASNUploadText;
		    
		    if(asn != null) {
		    	
		    	text = text + "\n" + "ASN : " + asn;
		    	
		    } else if(scn != null) {
		    	
		    	text = text + "\n" + "SCN : " + scn;
		    }
		    

			body = AppConstants.supplierBodyContent.replace("?supplier_ack", text);
			

			for (OpenPODetails openPO : list) {

				body = body + "<tr>\n";
				body = body + "<td>" + openPO.getPo_num() + "</td>\n";
				body = body + "<td>" + openPO.getPo_line_num() + "&" + openPO.getShipment_num() + "</td>\n";
				body = body + "<td>" + openPO.getItem() + "</td>\n";
				body = body + "<td>" + openPO.getItem_description() + "</td>\n";
				
				if(asn != null) {
					
					body = body + "<td>" + openPO.getShipment_qty() + "</td>\n";
					
				} else if(scn != null) {
					
					body = body + "<td>" + openPO.getShipment_amount() + "</td>\n";
				}
				body = body + "<td>" + openPO.getUnit_price() + "</td>\n";
				body = body + "</tr>";							

			}
			
			body = body + AppConstants.supplierBottomContent;
		}

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	
	private String loadChangeRequestBodyAndBottom(String body , OpenPoChangeDetails openPoChangeDetails) {
		
		body = body + "<tr>\n";
		body = body + "<td>" + openPoChangeDetails.getPo_num() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getShipment_num() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getItem() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getItem_description() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getPending_qty() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getUnit_price() + "</td>\n";
		body = body + "<td>" + getdateYYFormat(openPoChangeDetails.getNeed_by_date()) + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getChanged_qty() + "</td>\n";
		body = body + "<td>" + openPoChangeDetails.getSupplierChangePrice() + "</td>\n";
		body = body + "<td>" + getdateYYFormat(openPoChangeDetails.getReschedule_date()) + "</td>\n";
		body = body + "</tr>";
		
	    body = body + AppConstants.supplierBottomContent;
	    
	    return body;
	}
	
	
	public String getdateYYFormat(Date date) {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = date != null ? formatter.format(date) : "";
		return strDate;
	}
	
	
	public String loadRFQBuyerText(List<RFQMailObject> list) {

		String body = new String();

		if (list != null && list.size() > 0) {

			String text = new String();
				
		    text = list.get(0).getUser_name() + " " + AppConstants.buyerRFQText;
		    

			body = AppConstants.rfqBuyerBodyContent.replace("?buyer_rfq", text);
			

			for (RFQMailObject rfqObj : list) {

				body = body + "<tr>\n";
				body = body + "<td>" + rfqObj.getRfq_number() + "</td>\n";
				body = body + "<td>" + rfqObj.getAgent_name() + "</td>\n";
				body = body + "<td>" + rfqObj.getUser_name() + "</td>\n";
				body = body + "<td>" + rfqObj.getItem_name() + "</td>\n";
				body = body + "<td>" + rfqObj.getItem_description() + "</td>\n";
				body = body + "<td>" + rfqObj.getQuantity() + "</td>\n";
				body = body + "<td>" + rfqObj.getPrice_override() + "</td>\n";
				body = body + "<td>" + rfqObj.getPrice_discount() + "</td>\n";
				body = body + "<td>" + rfqObj.getRfq_close_date() + "</td>\n";
				body = body + "<td>" + rfqObj.getOrganization() + "</td>\n";
				body = body + "<td>" + rfqObj.getShip_to_location() + "</td>\n";
				body = body + "</tr>";							

			}
			
			body = body + AppConstants.supplierBottomContent;
		}

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	
	public String loadQuotationText(List<QuotationMailObject> list) {

		String body = new String();

		if (list != null && list.size() > 0) {

			String text = new String();
				
		    text = list.get(0).getUser_name() + " " + AppConstants.quotationText;
		    
			body = AppConstants.quotationBodyContent.replace("?vendor_quotation", text);
			

			for (QuotationMailObject quotObj : list) {
				
				String freight = quotObj.getFreight_charge() == 0 ? "--" : Double.toString(quotObj.getFreight_charge());
				
				String from_qty = quotObj.getFrom_quantity() == 0 ? "--" : Double.toString(quotObj.getFrom_quantity());
				
				String to_qty = quotObj.getTo_quantity() == 0 ? "--" : Double.toString(quotObj.getTo_quantity());
				
				String discount = quotObj.getPrice_discount() == 0 ? "--" : Double.toString(quotObj.getPrice_discount());

				body = body + "<tr>\n";
				body = body + "<td>" + quotObj.getRfq_number() + "</td>\n";
				body = body + "<td>" + quotObj.getItem_name() + "</td>\n";
				body = body + "<td>" + quotObj.getItem_description() + "</td>\n";
				body = body + "<td>" + quotObj.getUpdated_price_by_supplier() + "</td>\n";
				body = body + "<td>" + freight + "</td>\n";
				body = body + "<td>" + from_qty + "</td>\n";
				body = body + "<td>" + to_qty + "</td>\n";
				body = body + "<td>" + discount + "</td>\n";
				body = body + "</tr>";							

			}
			
			body = body + AppConstants.supplierBottomContent;
		}

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	
	
	public String loadNewServiceText(List<OpenPODetails> list) {

		String body = new String();
		
        if(list.size() > 0 && list.get(0).getPo_num() != null && list.get(0).getPo_line_num() != null && list.get(0).getShipment_num() != null) {
			
			Collections.sort(list, new OpenPoComparator());
			
		}

		if (list != null && list.size() > 0) {

			String text = new String();			

			text = list.get(0).getVendor_name() + " " + AppConstants.supplierNewServiceText;							
			
			body = AppConstants.supplierNewServiceBodyContent.replace("?supplier_new_service", text);			

			for (OpenPODetails openPO : list) {

				body = body + "<tr>\n";
				body = body + "<td>" + openPO.getLine_type() + "</td>\n";
				body = body + "<td>" + openPO.getPo_line_num() + "</td>\n";
				body = body + "<td>" + openPO.getItem_description() + "</td>\n";
				
				if(AppConstants.LInE_TYPE_FIXEDPRICE.equals(openPO.getLine_type())){
					
					body = body + "<td>" + openPO.getAmount() + "</td>\n";
					
				} else if(AppConstants.LIE_TYPE_IGC.equals(openPO.getLine_type())) {
					
					body = body + "<td>" + openPO.getQty_ordered() + "</td>\n";
				}
				
				body = body + "<td>" + openPO.getOu_name() + "</td>\n";
				body = body + "<td>" + openPO.getOrganization_name() + "</td>\n";
				body = body + "<td>" + openPO.getShip_to_location_code() + "</td>\n";
				body = body + "<td>" + openPO.getTax() + "</td>\n";
				body = body + "<td>" + openPO.getVendor_site_code() + "</td>\n";
				body = body + "<td>" + openPO.getScn() + "</td>\n";
				body = body + "</tr>";

			}
			
			body = body + AppConstants.supplierBottomContent;
		}

//		logger.info("***************** Email Body content  *********************\n" + body);
		
		return body;

	}
	
	public String getSupplierRegistrationText(String supplierRegURL) {

		String body = new String();

		body = AppConstants.supplierRegistrationBody;

		body = body.replace("${register_link}", supplierRegURL);

		return body;
	}
	
	public String getSupplierRegistrationSubmittedText(String supplierName , String id) {

		String body = new String();

		body = AppConstants.supplierRegistrationSubmissionBody;

		body = body.replace("?supplier_name?", supplierName);
		body = body.replace("?id?", id);

		return body;
	}
	

}