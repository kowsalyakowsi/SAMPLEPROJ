package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQLines;

@Repository
public interface RFQLinesRepository extends CrudRepository<RFQLines, Long> {

	
    @Override
    Iterable<RFQLines> findAll();
    
    @Query(value = "SELECT * FROM RFQ_LINES_ALL  WHERE RFQ_HEADER_ID = :rfqHeaderId ", nativeQuery = true)
    List<RFQLines> findAllLines(@Param("rfqHeaderId") Long rfqHeaderId);
    
    @Query(value = "SELECT MAX(LINE_NUM) FROM RFQ_LINES_ALL  WHERE RFQ_HEADER_ID = :rfqHeaderId ", nativeQuery = true)
    Long findMaxLineCount(@Param("rfqHeaderId") Long rfqHeaderId);
    
    @Query(value = "SELECT * FROM RFQ_LINES_ALL  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId", nativeQuery = true)
    RFQLines findLine(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId);


}