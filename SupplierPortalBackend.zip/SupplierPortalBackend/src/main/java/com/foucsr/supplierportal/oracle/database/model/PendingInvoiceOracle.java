package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PendingInvoiceOracle {

	private Long id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date poCreateionDate;

	private String supplierName;

	private String supplierSite;

	private String po_num;

	private long po_line_num;

	private String item_code;

	private String item_desc;

	private String uom;

	private Double ordered_qty;

	private Double receipted_qty;

	private Double pending_qty;

	private String ou_name;

	private String ship_to_org;

	private String poProcessStatus;

	private long vendorId;

	public PendingInvoiceOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getPoCreateionDate() {
		return poCreateionDate;
	}

	public void setPoCreateionDate(Date poCreateionDate) {
		this.poCreateionDate = poCreateionDate;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierSite() {
		return supplierSite;
	}

	public void setSupplierSite(String supplierSite) {
		this.supplierSite = supplierSite;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_desc() {
		return item_desc;
	}

	public void setItem_desc(String item_desc) {
		this.item_desc = item_desc;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getOrdered_qty() {
		return ordered_qty;
	}

	public void setOrdered_qty(Double ordered_qty) {
		this.ordered_qty = ordered_qty;
	}

	public Double getReceipted_qty() {
		return receipted_qty;
	}

	public void setReceipted_qty(Double receipted_qty) {
		this.receipted_qty = receipted_qty;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public String getShip_to_org() {
		return ship_to_org;
	}

	public void setShip_to_org(String ship_to_org) {
		this.ship_to_org = ship_to_org;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}

}