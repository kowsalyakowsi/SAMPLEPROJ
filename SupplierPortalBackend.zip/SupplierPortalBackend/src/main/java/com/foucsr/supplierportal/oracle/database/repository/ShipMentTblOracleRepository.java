package com.foucsr.supplierportal.oracle.database.repository;
import java.io.StringWriter;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.oracle.database.model.ShipMentTblOracle;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.SCAUtil;



@Component
public class ShipMentTblOracleRepository {
	
	Logger log = LoggerFactory.getLogger(ShipMentTblOracleRepository.class);
	
   
	 public ResponseEntity<?> SendShipmentbySOAPService(ShipMentTblOracle shipmentData) {
			
			String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zser_shipasn_rec/800/zser_shipasn_rec/zbind1?sap-client=800";
			
			String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zser_shipasn_rec/800/zser_shipasn_rec/zbind1";
			
			SCAUtil scaUtil = new SCAUtil();
			
			try {
				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();

				// Send SOAP Message to SOAP Server
				SOAPMessage soapResponse = soapConnection.call(createShipmentSOAPRequest(soapAction , shipmentData), soapEndpointUrl);

				// Print the SOAP Response
				System.out.println("Response SOAP Message:");
				soapResponse.writeTo(System.out);
				System.out.println();

				soapConnection.close();
				
				return new ResponseEntity(true, HttpStatus.OK);
				
			} catch (Exception e) {
				
				log.info("Error occurred while sending Shipment SOAP Request to Server!" + e);
				
				String msg = scaUtil.getErrorMessage(e);

				return new ResponseEntity(new ApiResponse(false, "Unable to send shipment to SAP!" + msg),
						HttpStatus.BAD_REQUEST);
			}
		}
	    
	    private SOAPMessage createShipmentSOAPRequest(String soapAction , ShipMentTblOracle shipmentData) throws Exception {
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();

			createShipmentSoapEnvelope(soapMessage ,  shipmentData);

			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", soapAction);
			
			String loginPassword = "developer:saphana2";
			
			soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


			soapMessage.saveChanges();

			/* Print the request message, just for debugging purposes */
			System.out.println("Request SOAP Message:");
			soapMessage.writeTo(System.out);
			System.out.println("\n");

			return soapMessage;
		}

	    
	    private void createShipmentSoapEnvelope(SOAPMessage soapMessage , ShipMentTblOracle shipmentData) throws SOAPException {

			SOAPPart soapPart = soapMessage.getSOAPPart();
			String serverURI = "urn:sap-com:document:sap:rfc:functions";
			SOAPEnvelope envelope = soapPart.getEnvelope();

			envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

			SOAPBody soapBody = envelope.getBody();
			SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZVEN_SHIPASN_REC", "urn", ""));
//			 bodyElement.addChildElement("INPUT").addTextNode("SHIPMENT");
			 SOAPElement it_ven_element = bodyElement.addChildElement("IT_PORTAL");

			 addShipmentItems(it_ven_element ,  shipmentData);
			 
					 DOMSource source = new DOMSource(soapBody);
					 StringWriter stringResult = new StringWriter();
					 try {
						TransformerFactory.newInstance().newTransformer().transform(source, new StreamResult(stringResult));
					} catch (TransformerException | TransformerFactoryConfigurationError e) {
						log.info("Error occurred while sending Shipment SOAP Request to Server!" + e);
					}
					 String message = stringResult.toString();
					 System.out.println(message);
			 
			soapMessage.saveChanges();
		}

	    private void addShipmentItems(SOAPElement it_ven_element , ShipMentTblOracle shipmentData) throws SOAPException {
	    	    	
	    		
	    		QName itemQ = new QName("item");
	    		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);
	    		
	    		itemQ = new QName("HEADER_ID");
	    		SOAPElement headerIdElement = itemElement.addChildElement(itemQ);
	    		headerIdElement.addTextNode(Long.toString(shipmentData.getHeader_id()));    	
	    		
	    		
	    		itemQ = new QName("OU_NAM");
	    		SOAPElement ouNameElement = itemElement.addChildElement(itemQ);
	    		ouNameElement.addTextNode(shipmentData.getOu_name());
	    		
	    		itemQ = new QName("PO_HEADER_ID");
	    		SOAPElement poHeaderIdElement = itemElement.addChildElement(itemQ);
	    		poHeaderIdElement.addTextNode(Long.toString(shipmentData.getPo_header_id()));
	    		
	    		itemQ = new QName("PO_DATE");
	    		SOAPElement poDateElement = itemElement.addChildElement(itemQ);
	    		Format formatter = new SimpleDateFormat("yyyy-MM-dd");
	    		String str = formatter.format(shipmentData.getPO_DATE());
	    		poDateElement.addTextNode(str);
	    		
	    		itemQ = new QName("PO_NUM");
	    		SOAPElement poNumElement = itemElement.addChildElement(itemQ);
	    		poNumElement.addTextNode(shipmentData.getPo_number());
	    		
	    		itemQ = new QName("VEN_NAM");
	    		SOAPElement vendorNameElement = itemElement.addChildElement(itemQ);
	    		vendorNameElement.addTextNode(shipmentData.getVendor_name());
	    		
	    		if(shipmentData.getVendor_site_code() != null) {
	    			
	    			itemQ = new QName("VEN_SITE_CODE");
	    			SOAPElement vendorSiteElement = itemElement.addChildElement(itemQ);
	    			vendorSiteElement.addTextNode(shipmentData.getVendor_site_code());
	    		}
	    		
	    		itemQ = new QName("BUYER");
	    		SOAPElement buyerElement = itemElement.addChildElement(itemQ);
	    		buyerElement.addTextNode(shipmentData.getBuyer());
	    		
	    		itemQ = new QName("BUYER_ID");
	    		SOAPElement buyerIdElement = itemElement.addChildElement(itemQ);
	    		buyerIdElement.addTextNode(Long.toString(shipmentData.getBuyer_id()));
	    		
	    		itemQ = new QName("PO_LINE_NUM");
	    		SOAPElement poLineNumElement = itemElement.addChildElement(itemQ);
	    		poLineNumElement.addTextNode(Long.toString(shipmentData.getPo_line_num()));
	    		
	    		if(shipmentData.getItem() != null) {
	    			
	    			itemQ = new QName("ITEM");
	    			SOAPElement poItemElement = itemElement.addChildElement(itemQ);
	    			poItemElement.addTextNode(shipmentData.getItem());
	    		}
	    		
	    		if(shipmentData.getItem_description() != null) {
	    			
	    			itemQ = new QName("ITEM_DESP");
	    			SOAPElement poItemDescElement = itemElement.addChildElement(itemQ);
	    			poItemDescElement.addTextNode(shipmentData.getItem_description());
	    		}
	    		
	    		if(shipmentData.getPo_uom() != null) {
	    			
	    			itemQ = new QName("PO_UOM");
	    			SOAPElement uomElement = itemElement.addChildElement(itemQ);
	    			uomElement.addTextNode(shipmentData.getPo_uom());
	    		}
	    		
	    		
	    		
	    		if(shipmentData.getUnit_price() != null) {
	    			
	    			itemQ = new QName("UNIT_PRICE");
	    			SOAPElement unitPriceElement = itemElement.addChildElement(itemQ);
	    			unitPriceElement.addTextNode(Double.toString(shipmentData.getUnit_price()));
	    		}
	    		
	    		itemQ = new QName("QTY_ORDERED");
	    		SOAPElement qtyOrderedElement = itemElement.addChildElement(itemQ);
	    		qtyOrderedElement.addTextNode(Double.toString(shipmentData.getQty_ordered()));
	    		
	    		itemQ = new QName("ORG_NAM");
	    		SOAPElement orgElement = itemElement.addChildElement(itemQ);
	    		orgElement.addTextNode(shipmentData.getOrganization_name());
	    		
	    		if(shipmentData.getNeed_by_date() != null) {
	    			
	    			itemQ = new QName("NEED_BY_DAT");
	    			SOAPElement nbdElement = itemElement.addChildElement(itemQ);
	    			Format nbd_formatter = new SimpleDateFormat("yyyy-MM-dd");
	    			String nbd_str = nbd_formatter.format(shipmentData.getNeed_by_date());
	    			nbdElement.addTextNode(nbd_str);
	    		}
	    		
	    		itemQ = new QName("ASN");
	    		SOAPElement asnElement = itemElement.addChildElement(itemQ);
	    		asnElement.addTextNode(shipmentData.getAsn());
	    		
	    		itemQ = new QName("LINE_TYPE");
	    		SOAPElement linetype = itemElement.addChildElement(itemQ);
	    		linetype.addTextNode(shipmentData.getLine_type());
	    		
	    		itemQ = new QName("SHPMNT_NO");
	    		SOAPElement shipNoElement = itemElement.addChildElement(itemQ);
	    		shipNoElement.addTextNode(Long.toString(shipmentData.getShipment_num()));
	    		
	    		itemQ = new QName("PO_LINE_ID");
	    		SOAPElement poLineIdElement = itemElement.addChildElement(itemQ);
	    		poLineIdElement.addTextNode(Long.toString(shipmentData.getPo_line_id()));
	    		
	    		itemQ = new QName("PO_LIN_LOC_ID");
	    		SOAPElement poLineLocElement = itemElement.addChildElement(itemQ);
	    		poLineLocElement.addTextNode(Long.toString(shipmentData.getPo_line_location_id()));
	    		
	    		itemQ = new QName("VEN_ID");
	    		SOAPElement vendorIdElement = itemElement.addChildElement(itemQ);
	    		vendorIdElement.addTextNode(Long.toString(shipmentData.getVendor_id()));

	    		itemQ = new QName("SHPMNT_QTY");
	    		SOAPElement shipQtyElement = itemElement.addChildElement(itemQ);
	    		shipQtyElement.addTextNode(Double.toString(shipmentData.getSHIPMENT_QTY()));
	    		
	    		itemQ = new QName("RECEIVING_QTY");
	    		SOAPElement recQtyElement = itemElement.addChildElement(itemQ);
	    		recQtyElement.addTextNode(Double.toString(shipmentData.getReceiving_quantity()));
	    		
	    		itemQ = new QName("PENDING_QTY");
	    		SOAPElement pendingQtyElement = itemElement.addChildElement(itemQ);
	    		pendingQtyElement.addTextNode(Double.toString(shipmentData.getPending_qty()));
	    		
	    		if(shipmentData.getSupp_invoice_num() != null) {
	    			
	    			itemQ = new QName("SUPP_INV");
	    			SOAPElement suppInv = itemElement.addChildElement(itemQ);
	    			suppInv.addTextNode(shipmentData.getSupp_invoice_num());
	    		}
	    		
               /* if(shipmentData.getSupp_shipped_date() != null) {
	    			
	    			itemQ = new QName("SUPP_INV");
	    			SOAPElement suppInv = itemElement.addChildElement(itemQ);
	    			suppInv.addTextNode(shipmentData.getSupp_shipped_date());
	    		}*/
	    		
	    		
//

		}

}