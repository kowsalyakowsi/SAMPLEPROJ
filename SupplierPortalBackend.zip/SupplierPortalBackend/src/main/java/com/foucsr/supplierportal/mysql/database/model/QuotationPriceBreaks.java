package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "QUOTATION_PRICE_BREAKS")
public class QuotationPriceBreaks {

	@Id
	@SequenceGenerator(name = "QUOTATION_PRICE_BREAKS_SEQ", sequenceName = "QUOTATION_PRICE_BREAKS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QUOTATION_PRICE_BREAKS_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "QUOTATION_LINE_ID")
	private Long quotation_line_id;
	
	@Column(name = "RFQ_LINE_LOCATION_ID")
	private Long rfq_line_location_id;

	@Column(name = "RFQ_HEADER_ID")
	private Long rfq_header_id;

	@Column(name = "RFQ_LINE_ID")
	private Long rfq_line_id;

	@Column(name = "SHIPMENT_NUM")
	private long shipment_num;

	@Column(name = "FROM_QUANTITY")
	private double from_quantity;

	@Column(name = "TO_QUANTITY")
	private double to_quantity;

	@Column(name = "PRICE_DISCOUNT")
	private double price_discount;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "DISCOUNT_END_DATE")
	private Date discount_end_date;

	@Column(name = "UNIT_MEAS_LOOKUP_CODE")
	private String unit_meas_lookup_code;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE")
	private Date start_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE")
	private Date end_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;

	@Column(name = "USER_NAME")
	private String user_name;
	
	@Column(name = "VENDOR_ID")
	private Long vendor_id;
	
	@Column(name = "VENDOR_NAME")
	private String vendor_name;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "QUOTATION_LINE_ID", insertable = false, updatable = false)
	private QuotationLines quotationLines;

	public QuotationPriceBreaks() {

	}

	public Long getRfq_line_location_id() {
		return rfq_line_location_id;
	}

	public void setRfq_line_location_id(Long rfq_line_location_id) {
		this.rfq_line_location_id = rfq_line_location_id;
	}

	public Long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(Long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	public Long getRfq_line_id() {
		return rfq_line_id;
	}

	public void setRfq_line_id(Long rfq_line_id) {
		this.rfq_line_id = rfq_line_id;
	}

	public long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public double getFrom_quantity() {
		return from_quantity;
	}

	public void setFrom_quantity(double from_quantity) {
		this.from_quantity = from_quantity;
	}

	public double getTo_quantity() {
		return to_quantity;
	}

	public void setTo_quantity(double to_quantity) {
		this.to_quantity = to_quantity;
	}

	public double getPrice_discount() {
		return price_discount;
	}

	public void setPrice_discount(double price_discount) {
		this.price_discount = price_discount;
	}

	public String getUnit_meas_lookup_code() {
		return unit_meas_lookup_code;
	}

	public void setUnit_meas_lookup_code(String unit_meas_lookup_code) {
		this.unit_meas_lookup_code = unit_meas_lookup_code;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Long getLast_update_login() {
		return last_update_login;
	}

	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	@JsonIgnore
	public QuotationLines getQuotationLines() {
		return quotationLines;
	}

	public void setQuotationLines(QuotationLines quotationLines) {
		this.quotationLines = quotationLines;
	}

	public Long getQuotation_line_id() {
		return quotation_line_id;
	}

	public void setQuotation_line_id(Long quotation_line_id) {
		this.quotation_line_id = quotation_line_id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDiscount_end_date() {
		return discount_end_date;
	}

	public void setDiscount_end_date(Date discount_end_date) {
		this.discount_end_date = discount_end_date;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

}