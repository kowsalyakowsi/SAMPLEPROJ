package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.foucsr.supplierportal.model.audit.UserDateAudit;

@Entity
@Table(name = "OPEN_PO_DETAILS", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "po_line_location_id"
            })
    })
public class OpenPODetails  extends UserDateAudit{
	
	@Id
	@SequenceGenerator(name = "OPEN_PO_DETAILS_SEQ", sequenceName = "OPEN_PO_DETAILS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OPEN_PO_DETAILS_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name="OU_NAME")
	private String ou_name;
	
	@Column(name="PO_HEADER_ID")
	private Long po_header_id;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="PO_DATE")
	private Date po_date;
	
	@Column(name="PO_NUMBER")
	private String po_num;
	
	@Column(name="VENDOR_NAME")
	private String vendor_name;
	
	@Column(name="VENDOR_SITE_CODE")
	private String vendor_site_code;
	
	@Column(name="BUYER")
	private String buyer;
	
	@Column(name="BUYER_ID")
	private String buyer_id;
	
	@Column(name="PO_LINE_NUM")
	@JsonProperty("line_num")
	private Long po_line_num;
	
	@Column(name="ITEM")
	@JsonProperty("item_code")
	private String item;
	
	@Column(name="ITEM_DESCRIPTION")
	@JsonProperty("item_desc")
	private String item_description;
	
	@Column(name="PO_UOM")
	@JsonProperty("uom")
	private String po_uom;
	
	@Column(name="UNIT_PRICE")
	@JsonProperty("unit_price")
	private Double unit_price;
	
	@Column(name="QTY_ORDERED")
	@JsonProperty("ordered_qty")
	private Double qty_ordered;
	
	@Column(name="ORGANIZATION_NAME")
	@JsonProperty("org")
	private String organization_name;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
    @JsonProperty("nbd")
	@Column(name="NEED_BY_DATE")
	private Date need_by_date;
	
	@Column(name="ACK")
	private String ack;
	
	@Column(name="RESCHEDULE")
	private String reschedule;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="RESCHEDULE_DATE")
	private Date reschedule_date;
	
	@Column(name="PROCESS_FLAG")
	private String process_flag;
	
	@Column(name="ASN")
	private String asn;
	
	@Column(name="SHIPMENT_NUM")
	private Long shipment_num;
	
	@Column(name="RECEIPT_CREATED_FLAG")
	private String receipt_created_flag;
	
	@Column(name="PO_LINE_ID")
	private Long po_line_id;
	
	@Column(name="PO_LINE_LOCATION_ID")
	@JsonProperty("po_line_location_id")
	private long poLineLocationId;
	
	@Column(name="RECEIPT_NUMBER")
	private Long receipt_number;
	
	@Column(name="VENDOR_ID")
	private Long vendor_id;
	
	@Column(name="SHIPMENT_QTY")
	private Double shipment_qty;
	
	@Column(name="RECEIVING_QUANTITY")
	private Double receiving_quantity;
	
	@Column(name="HEADER_ID")
	@JsonProperty("unique_id")
	private long headerId;

	@Column(name="PENDING_QTY")
	private Double pending_qty;
	
	@Column(name="BUYER_APPROVAL")
	private String buyer_approval;
	
	@Column(name="CHANGED_QTY")
	private Double changed_qty;
	
	@Column(name="NEW_QTY")
	private Double new_qty;
	
	@Column(name="RELEASE_ID")
	private Long release_id;
	
	@Column(name="RELEASE_NUMBER")
	private Long release_number;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="RELEASE_DATE")
	private Date release_date;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@Column(name = "IS_CHANGED")
	private String isChanged;
	 
	@Column(name = "IS_REJECTED")
	private String isRejected;
	
	@Column(name = "REASON_FOR_REJECTED")
	@Size(max = 2080)
	private String reaasonForRejected;
	
	@Column(name="ASN_RESERVE_QTY")
	private Double asn_reserve_qty;
	
	@Column(name="CHANGE_REQUEST_COUNT")
	private Integer changeRequestCount;
	
	@Column(name="REVISION_NO")
	private Long revisionNo;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="REMINDER_DATE")
	private Date reminder_date;
	
	@Column(name="CURRENCY_CODE")
	private String currency_code;
	
	@Column(name = "LINE_TYPE_ID")
	private Long line_type_id;
	
	@Column(name = "LINE_TYPE")
	private String line_type;
	
	@Column(name="AMOUNT")
	private Double amount;
	
	@Column(name="SCN_RESERVE_AMOUNT")
	private Double scn_reserve_amount;
	
	@Column(name="PENDING_AMOUNT")
	private Double pending_amount;
	
	@Column(name="SHIPMENT_AMOUNT")
	private Double shipment_amount;
	
	@Column(name="TAX")
	private Double tax;
	
	@Column(name="IS_SERVICE")
	private String is_service;
	
	@Column(name = "SHIP_TO_LOCATION_ID")
	private Long ship_to_location_id;
	
	@Column(name = "SHIP_TO_LOCATION_CODE")
	private String ship_to_location_code;
	
	@Column(name = "BILL_TO_LOCATION_ID")
	private Long bill_to_location_id;
	
	@Column(name = "BILL_TO_LOCATION_CODE")
	private String bill_to_location_code;
	
	@Column(name="SCN")
	private String scn;

	@Column(name="SUBMIT_FOR_REQUISITION")
	private String submit_for_requisition;
	
	@Column(name = "SERVICE_HEADER_ID")
	private Long service_header_id;
	
	@Column(name="MINIMUM_SHIP_QTY")
	private Double minimum_ship_qty;
	
	@Column(name = "CATEGORY_ID")
	private Long category_id;	
	
	@Column(name = "CATEGORY_NAME")
	private String segment1;
	
	@Column(name="SUPP_INVOICE_NUM")
    private String supp_invoice_num;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="SUPP_SHIPPED_DATE")
	private Date supp_shipped_date;
	
	@Column(name="DO_NUM")
    private String do_num;
	


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public Long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public Date getNeed_by_date() {
		return need_by_date;
	}

	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}

	public String getReschedule() {
		return reschedule;
	}

	public void setReschedule(String reschedule) {
		this.reschedule = reschedule;
	}

	public Date getReschedule_date() {
		return reschedule_date;
	}

	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}

	public String getProcess_flag() {
		return process_flag;
	}

	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}

	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public Long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public String getReceipt_created_flag() {
		return receipt_created_flag;
	}

	public void setReceipt_created_flag(String receipt_created_flag) {
		this.receipt_created_flag = receipt_created_flag;
	}

	public Long getPo_line_id() {
		return po_line_id;
	}

	public void setPo_line_id(Long po_line_id) {
		this.po_line_id = po_line_id;
	}

	public long getPoLineLocationId() {
		return poLineLocationId;
	}

	public void setPoLineLocationId(long poLineLocationId) {
		this.poLineLocationId = poLineLocationId;
	}

	public Long getReceipt_number() {
		return receipt_number;
	}

	public void setReceipt_number(Long receipt_number) {
		this.receipt_number = receipt_number;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Double getShipment_qty() {
		return shipment_qty;
	}

	public void setShipment_qty(Double shipment_qty) {
		this.shipment_qty = shipment_qty;
	}

	public Double getReceiving_quantity() {
		return receiving_quantity;
	}

	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}

	public long getHeaderId() {
		return headerId;
	}

	public void setHeaderId(long headerId) {
		this.headerId = headerId;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getBuyer_approval() {
		return buyer_approval;
	}

	public void setBuyer_approval(String buyer_approval) {
		this.buyer_approval = buyer_approval;
	}

	public Double getChanged_qty() {
		return changed_qty;
	}

	public void setChanged_qty(Double changed_qty) {
		this.changed_qty = changed_qty;
	}

	public Double getNew_qty() {
		return new_qty;
	}

	public void setNew_qty(Double new_qty) {
		this.new_qty = new_qty;
	}

	public Long getRelease_id() {
		return release_id;
	}

	public void setRelease_id(Long release_id) {
		this.release_id = release_id;
	}

	public Long getRelease_number() {
		return release_number;
	}

	public void setRelease_number(Long release_number) {
		this.release_number = release_number;
	}

	public Date getRelease_date() {
		return release_date;
	}

	public void setRelease_date(Date release_date) {
		this.release_date = release_date;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getIsChanged() {
		return isChanged;
	}

	public void setIsChanged(String isChanged) {
		this.isChanged = isChanged;
	}

	public String getIsRejected() {
		return isRejected;
	}

	public void setIsRejected(String isRejected) {
		this.isRejected = isRejected;
	}

	public String getReaasonForRejected() {
		return reaasonForRejected;
	}

	public void setReaasonForRejected(String reaasonForRejected) {
		this.reaasonForRejected = reaasonForRejected;
	}

	public Double getAsn_reserve_qty() {
		return asn_reserve_qty;
	}

	public void setAsn_reserve_qty(Double asn_reserve_qty) {
		this.asn_reserve_qty = asn_reserve_qty;
	}

	public Integer getChangeRequestCount() {
		return changeRequestCount == null ? 0 : changeRequestCount;
	}

	public void setChangeRequestCount(Integer changeRequestCount) {
		this.changeRequestCount = changeRequestCount;
	}

	public Long getRevisionNo() {
		return revisionNo;
	}

	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}

	public Date getReminder_date() {
		return reminder_date;
	}

	public void setReminder_date(Date reminder_date) {
		this.reminder_date = reminder_date;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getScn_reserve_amount() {
		return scn_reserve_amount;
	}

	public void setScn_reserve_amount(Double scn_reserve_amount) {
		this.scn_reserve_amount = scn_reserve_amount;
	}

	public Double getPending_amount() {
		return pending_amount;
	}

	public void setPending_amount(Double pending_amount) {
		this.pending_amount = pending_amount;
	}

	public Double getShipment_amount() {
		return shipment_amount;
	}

	public void setShipment_amount(Double shipment_amount) {
		this.shipment_amount = shipment_amount;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public String getIs_service() {
		return is_service;
	}

	public void setIs_service(String is_service) {
		this.is_service = is_service;
	}

	public Long getShip_to_location_id() {
		return ship_to_location_id;
	}

	public void setShip_to_location_id(Long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}

	public String getShip_to_location_code() {
		return ship_to_location_code;
	}

	public void setShip_to_location_code(String ship_to_location_code) {
		this.ship_to_location_code = ship_to_location_code;
	}

	public String getScn() {
		return scn;
	}

	public void setScn(String scn) {
		this.scn = scn;
	}

	public String getSubmit_for_requisition() {
		return submit_for_requisition;
	}

	public void setSubmit_for_requisition(String submit_for_requisition) {
		this.submit_for_requisition = submit_for_requisition;
	}

	public Long getService_header_id() {
		return service_header_id;
	}

	public void setService_header_id(Long service_header_id) {
		this.service_header_id = service_header_id;
	}

	public Long getBill_to_location_id() {
		return bill_to_location_id;
	}

	public void setBill_to_location_id(Long bill_to_location_id) {
		this.bill_to_location_id = bill_to_location_id;
	}

	public String getBill_to_location_code() {
		return bill_to_location_code;
	}

	public void setBill_to_location_code(String bill_to_location_code) {
		this.bill_to_location_code = bill_to_location_code;
	}

	public Double getMinimum_ship_qty() {
		return minimum_ship_qty;
	}

	public void setMinimum_ship_qty(Double minimum_ship_qty) {
		this.minimum_ship_qty = minimum_ship_qty;
	}

	public Long getCategory_id() {
		return category_id;
	}

	public void setCategory_id(Long category_id) {
		this.category_id = category_id;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getSupp_invoice_num() {
		return supp_invoice_num;
	}

	public void setSupp_invoice_num(String supp_invoice_num) {
		this.supp_invoice_num = supp_invoice_num;
	}

	public Date getSupp_shipped_date() {
		return supp_shipped_date;
	}

	public void setSupp_shipped_date(Date supp_shipped_date) {
		this.supp_shipped_date = supp_shipped_date;
	}

	public String getDo_num() {
		return do_num;
	}

	public void setDo_num(String do_num) {
		this.do_num = do_num;
	}


		
}