package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.Locations;

@Repository
public interface LocationsRepository extends CrudRepository<Locations, Long> {

	
    @Override
    Iterable<Locations> findAll();
    
    @Query(value = "select * from LOCATIONS where INACTIVE_DATE IS NULL order by LOCATION_CODE", nativeQuery = true)
    List<Locations> findAllValid();
    
    @Query(value = "select * from LOCATIONS where INACTIVE_DATE IS NULL and LOCATION_ID = :locationId", nativeQuery = true)
    Locations findLocation(@Param("locationId") long locationId);
    
    @Query(value = "select * from LOCATIONS where INACTIVE_DATE IS NULL AND INVENTORY_ORGANIZATION_ID IN (:invIdList)  order by LOCATION_CODE", nativeQuery = true)
    List<Locations> findAllWithInvIdList(@Param("invIdList") Set<Long> invIdList);
    
        

}