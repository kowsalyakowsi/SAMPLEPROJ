package com.foucsr.supplierportal.mysql.database.controller;

import java.net.URI;
import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.exception.ResourceNotFoundException;
import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.Role;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.RoleRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.mysql.database.service.ApSuppliersService;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PoAgentsService;
import com.foucsr.supplierportal.mysql.database.service.UserService;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.DeleteUserRequest;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;
import com.foucsr.supplierportal.payload.UpdateUserRequest;
import com.foucsr.supplierportal.payload.UserIdentityAvailability;
import com.foucsr.supplierportal.payload.UserProfile;
import com.foucsr.supplierportal.payload.UserSummary;
import com.foucsr.supplierportal.security.CurrentUser;
import com.foucsr.supplierportal.security.UserPrincipal;

@RestController
@RequestMapping("/Users/Service")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	ApSuppliersService apSuppliersService;

	@Autowired
	PoAgentsService poAgentsService;

	// private static final Logger logger =
	// LoggerFactory.getLogger(UserController.class);

	@GetMapping("/user/me")
	@PreAuthorize("hasRole('USER')")
	public UserSummary getCurrentUser(@CurrentUser UserPrincipal currentUser) {
		UserSummary userSummary = new UserSummary(currentUser.getId(), currentUser.getUsername(),
				currentUser.getName());
		return userSummary;
	}

	@GetMapping("/user/checkUsernameAvailability")
	public UserIdentityAvailability checkUsernameAvailability(@RequestParam(value = "username") String username) {
		Boolean isAvailable = !userRepository.existsByUsername(username);
		return new UserIdentityAvailability(isAvailable);
	}

	@GetMapping("/user/checkEmailAvailability")
	public UserIdentityAvailability checkEmailAvailability(@RequestParam(value = "email") String email) {
		Boolean isAvailable = !userRepository.existsByEmail(email);
		return new UserIdentityAvailability(isAvailable);
	}

	@GetMapping("/users/{username}")
	public UserProfile getUserProfile(@PathVariable(value = "username") String username) {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new ResourceNotFoundException("User", "username", username));

		 if('Y' != user.getIs_Active()) {
	        	throw new UsernameNotFoundException("User is not active : " + username);
	     }
		
		long pollCount = 0;// = pollRepository.countByCreatedBy(user.getId());
		long voteCount = 0;// voteRepository.countByUserId(user.getId());

		UserProfile userProfile = new UserProfile(user.getId(), user.getUsername(), user.getName(), pollCount,
				voteCount);

		return userProfile;
	}

	@GetMapping("/getListOfUsers")
	public List<User> getAllProjects(Principal principal) {
		List<User> listofUsers = userService.findAllProjects(principal.getName());
		return listofUsers;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/updateUserDetails")
	public ResponseEntity<?> updateUserDetails(@Valid @RequestBody UpdateUserRequest signUpRequest,
			BindingResult result) {
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		User user = userRepository.findById(signUpRequest.getId()).orElseThrow(
				() -> new ResourceNotFoundException("User Id is does not exist!", "id", signUpRequest.getId()));

		if (signUpRequest.getPassword() != null) {
			user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));

		}
		
		user.setFull_name(signUpRequest.getFull_name());

		if (signUpRequest.getVendorID() != null) {
			ApSuppliers vendorID = apSuppliersService.findByVendorID(signUpRequest.getVendorID());

			if (vendorID == null) {
				return new ResponseEntity(new ApiResponse(false, "Vendor Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}
			
			user.setSupplier_flag('Y');
			user.setBuyer_flag('N');
			user.setVendorID(signUpRequest.getVendorID());
			user.setAgentId("");

		}

		if (signUpRequest.getAgentId() != null) {
			PoAgents agentId = poAgentsService.findByAgentId(signUpRequest.getAgentId());

			if (agentId == null) {
				return new ResponseEntity(new ApiResponse(false, "Agent Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}

			user.setBuyer_flag('Y');
			user.setVendorID("");
			user.setAgentId(signUpRequest.getVendorID());
			
		}
		/*
		 * if (signUpRequest.getVendorID() != null) { user.setSupplier_flag('Y');
		 * user.setBuyer_flag('N'); user.setVendorID(signUpRequest.getVendorID());
		 * user.setAgentId(""); }
		 * 
		 * if (signUpRequest.getAgentId() != null) { user.setSupplier_flag('N');
		 * user.setBuyer_flag('Y'); user.setVendorID("");
		 * user.setAgentId(signUpRequest.getVendorID()); }
		 */

		if (signUpRequest.getUserRoles() != null) {
		Role userRole = roleRepository.findByName(signUpRequest.getUserRoles())
				.orElseThrow(() -> new AppException("User Role not set."));
			Set rolesMap = new HashSet();
			Role setRoles = new Role();
			setRoles.setId((long) userRole.getId());
			setRoles.setName(userRole.getName());
			user.setRoles(rolesMap);

			Set rolesMap1 = new HashSet();
			rolesMap1.add(userRole);
			user.setRoles(rolesMap1);
		}
		if (signUpRequest.getName() != null) {
			user.setName(signUpRequest.getName());
		}
		
		/*if(signUpRequest.getUsername()!=null) {
			user.setUsername(signUpRequest.getUsername());
			}*/
		
		if(signUpRequest.getOrgname()!=null) {
			user.setOrgname(signUpRequest.getOrgname());
		}
		user.setEmail(signUpRequest.getEmail());
		User results = userRepository.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
				.buildAndExpand(results.getUsername()).toUri();

		return ResponseEntity.created(location).body(new ApiResponse(true, "User Updated successfully"));
	}
	
	@DeleteMapping("/{userId}")
	public ResponseEntity<?> deleteUser(@PathVariable long userId, Principal principal) {
		
		userService.deleteUserById(userId);
		return new ResponseEntity<String>("User with ID: '" + userId + "' was deleted", HttpStatus.OK);
	}
	
	@PostMapping("/deleteUser")
	public ResponseEntity<?> activeOrInactiveUser(@Valid @RequestBody DeleteUserRequest deleteRequest,
			Principal principal) {
		return userService.activeOrInactiveUser(deleteRequest);

	}
	
}
