package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.MasterOrganizations;

@Repository
public interface MasterOrganizationsRepository extends CrudRepository<MasterOrganizations, Long> {
	   
	
    @Override
    Iterable<MasterOrganizations> findAll();
    
    @Query(value = "select * from MASTER_ORGANIZATIONS where DISABLE_DATE IS NULL order by ORGANIZATION_NAME , ORGANIZATION_CODE", nativeQuery = true)
    List<MasterOrganizations> findAllValid();
    
    @Query(value = "select * from MASTER_ORGANIZATIONS where DISABLE_DATE IS NULL and ORGANIZATION_ID = :organizationId", nativeQuery = true)
    MasterOrganizations findOrganization(@Param("organizationId") long organizationId);
    
    @Query(value = "select * from MASTER_ORGANIZATIONS where DISABLE_DATE IS NULL and ORGANIZATION_NAME = :organizationName", nativeQuery = true)
    MasterOrganizations findOrganizationByName(@Param("organizationName") String organizationName);
    
    @Query(value = "select * from MASTER_ORGANIZATIONS where DISABLE_DATE IS NULL AND OPERATING_UNIT IN (:ouIdList) order by ORGANIZATION_NAME , ORGANIZATION_CODE", nativeQuery = true)
    List<MasterOrganizations> findAllWithOU(@Param("ouIdList") Set<Long> ouIdList);
    

}