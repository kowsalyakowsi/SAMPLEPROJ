package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "MASTER_ORGANIZATIONS")
public class MasterOrganizations {

	@Id
	@Column(name = "ORGANIZATION_ID")
	private Long organization_id;

	@Column(name = "BUSINESS_GROUP_ID")
	private long business_group_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "USER_DEFINITION_ENABLE_DATE")
	private Date user_def_enable_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "DISABLE_DATE")
	private Date disable_date;

	@Column(name = "ORGANIZATION_CODE")
	private String organization_code;

	@Column(name = "ORGANIZATION_NAME")
	private String organization_name;

	@Column(name = "SET_OF_BOOKS_ID")
	private long set_of_books_id;

	@Column(name = "CHART_OF_ACCOUNTS_ID")
	private long chart_of_accounts_id;

	@Column(name = "INVENTORY_ENABLED_FLAG")
	private String inventory_enabled_flag;

	@Column(name = "OPERATING_UNIT")
	private Long operating_unit;

	@Column(name = "LEGAL_ENTITY")
	private Long legal_entity;

	@Column(name = "PO_PROCESS_STATUS")
	private String poProcessStatus;

	public MasterOrganizations() {

	}

	public Long getOrganization_Id() {
		return organization_id;
	}

	public void setOrganization_Id(Long organization_id) {
		this.organization_id = organization_id;
	}

	public long getBusiness_group_id() {
		return business_group_id;
	}

	public void setBusiness_group_id(long business_group_id) {
		this.business_group_id = business_group_id;
	}

	public Date getUser_def_enable_date() {
		return user_def_enable_date;
	}

	public void setUser_def_enable_date(Date user_def_enable_date) {
		this.user_def_enable_date = user_def_enable_date;
	}

	public Date getDisable_date() {
		return disable_date;
	}

	public void setDisable_date(Date disable_date) {
		this.disable_date = disable_date;
	}

	public String getOrganization_code() {
		return organization_code;
	}

	public void setOrganization_code(String organization_code) {
		this.organization_code = organization_code;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public long getSet_of_books_id() {
		return set_of_books_id;
	}

	public void setSet_of_books_id(long set_of_books_id) {
		this.set_of_books_id = set_of_books_id;
	}

	public long getChart_of_accounts_id() {
		return chart_of_accounts_id;
	}

	public void setChart_of_accounts_id(long chart_of_accounts_id) {
		this.chart_of_accounts_id = chart_of_accounts_id;
	}

	public String getInventory_enabled_flag() {
		return inventory_enabled_flag;
	}

	public void setInventory_enabled_flag(String inventory_enabled_flag) {
		this.inventory_enabled_flag = inventory_enabled_flag;
	}

	public Long getOperating_unit() {
		return operating_unit;
	}

	public void setOperating_unit(Long operating_unit) {
		this.operating_unit = operating_unit;
	}

	public Long getLegal_entity() {
		return legal_entity;
	}

	public void setLegal_entity(Long legal_entity) {
		this.legal_entity = legal_entity;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

}