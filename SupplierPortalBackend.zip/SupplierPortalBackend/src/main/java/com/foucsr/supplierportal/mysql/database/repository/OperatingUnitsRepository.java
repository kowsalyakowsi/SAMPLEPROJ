package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;

@Repository
public interface OperatingUnitsRepository extends CrudRepository<OperatingUnits, Long> {
	   
	
    @Override
    Iterable<OperatingUnits> findAll();
    
    @Query(value = "select * from OPERATING_UNITS where DATE_TO IS NULL AND BUSINESS_GROUP_ID IN (SELECT BUSINESS_GROUP_ID FROM PO_AGENTS WHERE AGENT_ID = :agentId ) order by NAME", nativeQuery = true)
    List<OperatingUnits> findAllValid(@Param("agentId") Long agentId);
    
    @Query(value = "select * from OPERATING_UNITS where DATE_TO IS NULL order by NAME", nativeQuery = true)
    List<OperatingUnits> findAllValid();
    
    @Query(value = "select * from OPERATING_UNITS where DATE_TO IS NULL AND ORGANIZATION_ID IN (:ouIdList) order by NAME", nativeQuery = true)
    List<OperatingUnits> findAllWithOu(@Param("ouIdList") Set<Long> ouIdList);
    
    
    @Query(value = "select * from OPERATING_UNITS where DATE_TO IS NULL AND BUSINESS_GROUP_ID = :busGroupId order by NAME", nativeQuery = true)
    List<OperatingUnits> findAllByBusinessGroup(@Param("busGroupId") Long busGroupId);
    

}