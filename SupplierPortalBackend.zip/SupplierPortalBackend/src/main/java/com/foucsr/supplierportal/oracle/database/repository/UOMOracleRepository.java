package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class UOMOracleRepository  {
//	   
//    @Query(value = "select * from XX_UNITS_OF_MEASURE where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<UOMOracle> findAllUOM();
   
}