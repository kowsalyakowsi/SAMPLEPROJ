package com.foucsr.supplierportal.mysql.database.model;

import java.util.List;

public class SupplierBankObject {

	List<Currencies> currencies;

	private List<SupplierBankDetailsRegister> banks;

	public List<Currencies> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(List<Currencies> currencies) {
		this.currencies = currencies;
	}

	public List<SupplierBankDetailsRegister> getBanks() {
		return banks;
	}

	public void setBanks(List<SupplierBankDetailsRegister> banks) {
		this.banks = banks;
	}	

	}
