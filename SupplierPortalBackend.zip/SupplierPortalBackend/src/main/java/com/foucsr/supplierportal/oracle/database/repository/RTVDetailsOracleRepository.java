package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class RTVDetailsOracleRepository  {
	   
//    @Query(value = "select * from XX_RTV_TABLE where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<RTVDetailsOracle> findByFirstNameAndLastName();
}