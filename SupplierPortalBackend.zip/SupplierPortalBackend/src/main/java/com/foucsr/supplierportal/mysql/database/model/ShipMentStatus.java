package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "SHIPMENT_STATUS")
public class ShipMentStatus {

	@Id
	@SequenceGenerator(name = "SHIPMENT_STATUS_SEQ", sequenceName = "SHIPMENT_STATUS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SHIPMENT_STATUS_SEQ")
	@Column(name = "ID")
	private Long id;
	

	@Column(name="OU_NAME")
	private String ou_name;
	
	@Column(name="PO_HEADER_ID")
	private Long po_header_id;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="PO_DATE")
	private Date PO_DATE;
	
	@Column(name="PO_NUMBER")
	private String po_number;
	
	@Column(name="VENDOR_NAME")
	private String vendor_name;
	
	@Column(name="VENDOR_SITE_CODE")
	private String vendor_site_code;
	
	@Column(name="BUYER")
	private String buyer;
	
	@Column(name="BUYER_ID")
	private Long buyer_id;
	
	@Column(name="PO_LINE_NUM")
	private Long po_line_num;
	
	@Column(name="ITEM")
	private String item;
	
	@Column(name="ITEM_DESCRIPTION")
	private String item_description;
	
	@Column(name="PO_UOM")
	private String po_uom;
	
	@Column(name="UNIT_PRICE")
	private Double unit_price;
	
	@Column(name="QTY_ORDERED")
	private Double qty_ordered;
	
	@Column(name="ORGANIZATION_NAME")
	private String organization_name;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="NEED_BY_DATE")
	private Date need_by_date;
	
	@Column(name="ACK")
	private String ack;
	
	@Column(name="RESCHEDULE")
	private String reschedule;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="RESCHEDULE_DATE")
	private Date reschedule_date;
	
	@Column(name="PROCESS_FLAG")
	private String process_flag;
	
	@Column(name="ASN")
	private String asn;
	
	@Column(name="SHIPMENT_NUM")
	private Long shipment_num;
	
	@Column(name="RECEIPT_CREATED_FLAG")
	private String receipt_created_flag;
	
	@Column(name="PO_LINE_ID")
	private Long po_line_id;
	
	@Column(name="PO_LINE_LOCATION_ID")
	private Long po_line_location_id;
	
	@Column(name="RECEIPT_NUMBER")
	private String receipt_number;
	
	@Column(name="VENDOR_ID")
	private Long vendor_id;
	
	@Column(name="shipment_qty")
	private Double SHIPMENT_QTY;
	
	@Column(name="RECEIVING_QUANTITY")
	private Double receiving_quantity;
	
	@Column(name="HEADER_ID")
	private Long header_id;

	@Column(name="PENDING_QTY")
	private Double pending_qty;
	
	@Column(name="BUYER_APPROVAL")
	private String buyer_approval;
	
	@Column(name="QUANTITY_ORDERED")
	private Double quantity_ordered;
	
	@Column(name="QUANTITY_RECEIVED")
	private Double quantity_received;
	
	@Column(name="QUANTITY_ACCEPTED")
	private Double quantity_accepted;
	
	@Column(name="QUANTITY_REJECTED")
	private Double quantity_rejected;
	
	@Column(name="QUANTITY_BILLED")
	private Double quantity_billed;
	
	@Column(name="QUANTITY_CANCELLED")
	private Double quantity_cancelled;
	
	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@Column(name="REQUISITION_HEADER_ID")
	private Long requisition_header_id;
	
	@Column(name="REQUISITION_NUMBER")
	private Long requisition_number;
	
	@Column(name="CURRENCY_CODE")
	private String currency_code;
	
	@Column(name="LINE_TYPE")
	private String line_type;
	
	@Column(name="SUPP_INVOICE_NUM")
    private String supp_invoice_num;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="SUPP_SHIPPED_DATE")
	private Date supp_shipped_date;
	
	@Column(name="RECEIPT_NUMBER_LIST")
	private String receipt_number_list;
	
	@Column(name="REVISION_NO")
	private Long revisionNo;
	
	@Column(name="DO_NUM")
    private String do_num;
	
	@Column(name="IS_DO_DOC_UPLOADED")
    private String is_do_doc_uploaded;
	
	@Column(name="IS_INV_UPLOADED")
    private String is_inv_uploaded;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="INV_UPLOAD_DATE")
	private Date inv_upload_date;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="DO_UPLOAD_DATE")
	private Date do_upload_date;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="ASN_CREATION_DATE")
	private Date asn_creation_date;
	
	public ShipMentStatus() {

	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOu_name() {
		return ou_name;
	}
	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}
	public Long getPo_header_id() {
		return po_header_id;
	}
	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}
	public Date getPO_DATE() {
		return PO_DATE;
	}
	public void setPO_DATE(Date pO_DATE) {
		PO_DATE = pO_DATE;
	}
	public String getPo_number() {
		return po_number;
	}
	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	public String getVendor_site_code() {
		return vendor_site_code;
	}
	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public Long getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}
	public Long getPo_line_num() {
		return po_line_num;
	}
	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getItem_description() {
		return item_description;
	}
	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}
	public String getPo_uom() {
		return po_uom;
	}
	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}
	public Double getUnit_price() {
		return unit_price;
	}
	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}
	public Double getQty_ordered() {
		return qty_ordered;
	}
	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}
	public String getOrganization_name() {
		return organization_name;
	}
	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}
	public Date getNeed_by_date() {
		return need_by_date;
	}
	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}
	public String getAck() {
		return ack;
	}
	public void setAck(String ack) {
		this.ack = ack;
	}
	public String getReschedule() {
		return reschedule;
	}
	public void setReschedule(String reschedule) {
		this.reschedule = reschedule;
	}
	public Date getReschedule_date() {
		return reschedule_date;
	}
	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}
	public String getProcess_flag() {
		return process_flag;
	}
	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}
	public String getAsn() {
		return asn;
	}
	public void setAsn(String asn) {
		this.asn = asn;
	}
	public Long getShipment_num() {
		return shipment_num;
	}
	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}
	public String getReceipt_created_flag() {
		return receipt_created_flag;
	}
	public void setReceipt_created_flag(String receipt_created_flag) {
		this.receipt_created_flag = receipt_created_flag;
	}
	public Long getPo_line_id() {
		return po_line_id;
	}
	public void setPo_line_id(Long po_line_id) {
		this.po_line_id = po_line_id;
	}
	public Long getPo_line_location_id() {
		return po_line_location_id;
	}
	public void setPo_line_location_id(Long po_line_location_id) {
		this.po_line_location_id = po_line_location_id;
	}
	public String getReceipt_number() {
		return receipt_number;
	}
	public void setReceipt_number(String receipt_number) {
		this.receipt_number = receipt_number;
	}
	public Long getVendor_id() {
		return vendor_id;
	}
	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}
	public Double getSHIPMENT_QTY() {
		return SHIPMENT_QTY;
	}
	public void setSHIPMENT_QTY(Double sHIPMENT_QTY) {
		SHIPMENT_QTY = sHIPMENT_QTY;
	}
	public Double getReceiving_quantity() {
		return receiving_quantity;
	}
	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}
	public Long getHeader_id() {
		return header_id;
	}
	public void setHeader_id(Long header_id) {
		this.header_id = header_id;
	}
	public Double getPending_qty() {
		return pending_qty;
	}
	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}
	public String getBuyer_approval() {
		return buyer_approval;
	}
	public void setBuyer_approval(String buyer_approval) {
		this.buyer_approval = buyer_approval;
	}
	public Double getQuantity_ordered() {
		return quantity_ordered;
	}
	public void setQuantity_ordered(Double quantity_ordered) {
		this.quantity_ordered = quantity_ordered;
	}
	public Double getQuantity_received() {
		return quantity_received;
	}
	public void setQuantity_received(Double quantity_received) {
		this.quantity_received = quantity_received;
	}
	public Double getQuantity_accepted() {
		return quantity_accepted;
	}
	public void setQuantity_accepted(Double quantity_accepted) {
		this.quantity_accepted = quantity_accepted;
	}
	public Double getQuantity_rejected() {
		return quantity_rejected;
	}
	public void setQuantity_rejected(Double quantity_rejected) {
		this.quantity_rejected = quantity_rejected;
	}
	public Double getQuantity_billed() {
		return quantity_billed;
	}
	public void setQuantity_billed(Double quantity_billed) {
		this.quantity_billed = quantity_billed;
	}
	public Double getQuantity_cancelled() {
		return quantity_cancelled;
	}
	public void setQuantity_cancelled(Double quantity_cancelled) {
		this.quantity_cancelled = quantity_cancelled;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public Long getRequisition_header_id() {
		return requisition_header_id;
	}
	public void setRequisition_header_id(Long requisition_header_id) {
		this.requisition_header_id = requisition_header_id;
	}
	public Long getRequisition_number() {
		return requisition_number;
	}
	public void setRequisition_number(Long requisition_number) {
		this.requisition_number = requisition_number;
	}
	public String getCurrency_code() {
		return currency_code;
	}
	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}
	public String getLine_type() {
		return line_type;
	}
	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}
	public String getSupp_invoice_num() {
		return supp_invoice_num;
	}
	public void setSupp_invoice_num(String supp_invoice_num) {
		this.supp_invoice_num = supp_invoice_num;
	}
	public Date getSupp_shipped_date() {
		return supp_shipped_date;
	}
	public void setSupp_shipped_date(Date supp_shipped_date) {
		this.supp_shipped_date = supp_shipped_date;
	}
	public String getReceipt_number_list() {
		return receipt_number_list;
	}
	public void setReceipt_number_list(String receipt_number_list) {
		this.receipt_number_list = receipt_number_list;
	}
	public Long getRevisionNo() {
		return revisionNo;
	}
	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}
	public String getDo_num() {
		return do_num;
	}
	public void setDo_num(String do_num) {
		this.do_num = do_num;
	}
	public String getIs_do_doc_uploaded() {
		return is_do_doc_uploaded;
	}
	public void setIs_do_doc_uploaded(String is_do_doc_uploaded) {
		this.is_do_doc_uploaded = is_do_doc_uploaded;
	}
	public String getIs_inv_uploaded() {
		return is_inv_uploaded;
	}
	public void setIs_inv_uploaded(String is_inv_uploaded) {
		this.is_inv_uploaded = is_inv_uploaded;
	}
	public Date getInv_upload_date() {
		return inv_upload_date;
	}
	public void setInv_upload_date(Date inv_upload_date) {
		this.inv_upload_date = inv_upload_date;
	}
	public Date getDo_upload_date() {
		return do_upload_date;
	}
	public void setDo_upload_date(Date do_upload_date) {
		this.do_upload_date = do_upload_date;
	}
	public Date getAsn_creation_date() {
		return asn_creation_date;
	}
	public void setAsn_creation_date(Date asn_creation_date) {
		this.asn_creation_date = asn_creation_date;
	}


	
	
}