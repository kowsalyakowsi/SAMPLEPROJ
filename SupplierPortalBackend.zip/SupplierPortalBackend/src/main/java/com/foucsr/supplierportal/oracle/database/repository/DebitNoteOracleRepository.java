package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class DebitNoteOracleRepository  {
	   
//    
//    @Query(value = "select * from XX_DEBIT_INVOICES where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<DebitNoteOracle> findAllDebitNotes();
   
}