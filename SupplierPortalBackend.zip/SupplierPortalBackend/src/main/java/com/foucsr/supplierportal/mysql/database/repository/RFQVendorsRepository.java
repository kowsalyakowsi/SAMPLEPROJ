package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQLines;
import com.foucsr.supplierportal.mysql.database.model.RFQVendors;

@Repository
public interface RFQVendorsRepository extends CrudRepository<RFQVendors, Long> {

	
    @Override
    Iterable<RFQVendors> findAll();
    
    @Query(value = "SELECT * FROM RFQ_VENDORS  WHERE RFQ_HEADER_ID = :rfqHeaderId", nativeQuery = true)
    List<RFQVendors> findAllVendors(@Param("rfqHeaderId") Long rfqHeaderId);
    
    @Query(value = "SELECT MAX(SEQUENCE_NUM) FROM RFQ_VENDORS  WHERE RFQ_HEADER_ID = :rfqHeaderId ", nativeQuery = true)
    Integer findMaxLineCount(@Param("rfqHeaderId") Long rfqHeaderId);
    
    @Query(value = "SELECT * FROM RFQ_VENDORS  WHERE RFQ_HEADER_ID = :rfqHeaderId and VENDOR_ID = :vendorId", nativeQuery = true)
    RFQVendors findVendor(@Param("rfqHeaderId") Long rfqHeaderId , @Param("vendorId") Long vendorId);
    
    @Query(value = "SELECT * FROM RFQ_VENDORS  WHERE RFQ_HEADER_ID = :rfqHeaderId and (IS_MAIL_SENT = null or IS_MAIL_SENT = 'N')", nativeQuery = true)
    List<RFQVendors> findAllUnnotifiedVendors(@Param("rfqHeaderId") Long rfqHeaderId);

}