package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RTVDetailsOracle {

	private Long id;

	private String organization_code;

	private String po_number;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date po_date;

	private Long po_line_num;

	private Long shipment_num;

	private Long vendor_id;

	private Long vendor_site_id;

	private Long line_location_id;

	private Long transaction_id;

	private String receipt_num;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date receipt_date;

	private String item;

	private String item_description;

	private Double quantity_ordered;

	private Double quantity_received;

	private Double quantity_rejeced;

	private Double quantity_billed;

	private Double quantity_cancelled;

	private Double quantity_returned;

	private Double unit_price;

	private String processStatus;

	public RTVDetailsOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganization_code() {
		return organization_code;
	}

	public void setOrganization_code(String organization_code) {
		this.organization_code = organization_code;
	}

	public String getPo_number() {
		return po_number;
	}

	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public Long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Long getVendor_site_id() {
		return vendor_site_id;
	}

	public void setVendor_site_id(Long vendor_site_id) {
		this.vendor_site_id = vendor_site_id;
	}

	public Long getLine_location_id() {
		return line_location_id;
	}

	public void setLine_location_id(Long line_location_id) {
		this.line_location_id = line_location_id;
	}

	public Long getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(Long transaction_id) {
		this.transaction_id = transaction_id;
	}

	public String getReceipt_num() {
		return receipt_num;
	}

	public void setReceipt_num(String receipt_num) {
		this.receipt_num = receipt_num;
	}

	public Date getReceipt_date() {
		return receipt_date;
	}

	public void setReceipt_date(Date receipt_date) {
		this.receipt_date = receipt_date;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public Double getQuantity_ordered() {
		return quantity_ordered;
	}

	public void setQuantity_ordered(Double quantity_ordered) {
		this.quantity_ordered = quantity_ordered;
	}

	public Double getQuantity_received() {
		return quantity_received;
	}

	public void setQuantity_received(Double quantity_received) {
		this.quantity_received = quantity_received;
	}

	public Double getQuantity_rejeced() {
		return quantity_rejeced;
	}

	public void setQuantity_rejeced(Double quantity_rejeced) {
		this.quantity_rejeced = quantity_rejeced;
	}

	public Double getQuantity_billed() {
		return quantity_billed;
	}

	public void setQuantity_billed(Double quantity_billed) {
		this.quantity_billed = quantity_billed;
	}

	public Double getQuantity_cancelled() {
		return quantity_cancelled;
	}

	public void setQuantity_cancelled(Double quantity_cancelled) {
		this.quantity_cancelled = quantity_cancelled;
	}

	public Double getQuantity_returned() {
		return quantity_returned;
	}

	public void setQuantity_returned(Double quantity_returned) {
		this.quantity_returned = quantity_returned;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

}