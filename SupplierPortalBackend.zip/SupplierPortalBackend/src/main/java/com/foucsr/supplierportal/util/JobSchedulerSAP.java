package com.foucsr.supplierportal.util;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.ClosedPODetails;
import com.foucsr.supplierportal.mysql.database.model.DebitNote;
import com.foucsr.supplierportal.mysql.database.model.InvoiceDetailsTbl;
import com.foucsr.supplierportal.mysql.database.model.Locations;
import com.foucsr.supplierportal.mysql.database.model.MasterItems;
import com.foucsr.supplierportal.mysql.database.model.MasterOrganizations;
import com.foucsr.supplierportal.mysql.database.model.OpenCreditMysql;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;
import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;
import com.foucsr.supplierportal.mysql.database.model.PaymentAdviceMysql;
import com.foucsr.supplierportal.mysql.database.model.PaymentDetailsTbl;
import com.foucsr.supplierportal.mysql.database.model.PendingInvoice;
import com.foucsr.supplierportal.mysql.database.model.PlantMysql;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.PrePaymentInvoice;
import com.foucsr.supplierportal.mysql.database.model.RTVDetails;
import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.model.ShipMentTbl;
import com.foucsr.supplierportal.mysql.database.model.SupplierSites;
import com.foucsr.supplierportal.mysql.database.model.UOM;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.ClosedPODetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.DebitNoteRepository;
import com.foucsr.supplierportal.mysql.database.repository.InvoiceDetailsTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.LocationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterItemsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterOrganizationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenCreditMysqlRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPODetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPoChangeDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OperatingUnitsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PaymentAdviceMysqlRepository;
import com.foucsr.supplierportal.mysql.database.repository.PaymentDetailsTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.PendingInvoiceRepository;
import com.foucsr.supplierportal.mysql.database.repository.PlantMysqlRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PrePaymentInvoiceDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.RTVDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentStatusRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierSitesRepository;
import com.foucsr.supplierportal.mysql.database.repository.UOMRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.mysql.database.service.OpenPODetailsService;
import com.foucsr.supplierportal.oracle.database.model.ApSuppliersOracle;
import com.foucsr.supplierportal.oracle.database.model.ClosedPODetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.DebitNoteOracle;
import com.foucsr.supplierportal.oracle.database.model.InvoiceDetailsTblOracle;
import com.foucsr.supplierportal.oracle.database.model.LocationsOracle;
import com.foucsr.supplierportal.oracle.database.model.MasterItemsOracle;
import com.foucsr.supplierportal.oracle.database.model.MasterOrganizationsOracle;
import com.foucsr.supplierportal.oracle.database.model.OpenCreditOracle;
import com.foucsr.supplierportal.oracle.database.model.OpenPODetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.OperatingUnitsOracle;
import com.foucsr.supplierportal.oracle.database.model.POAgentsOracle;
import com.foucsr.supplierportal.oracle.database.model.PaymentAdviceOracle;
import com.foucsr.supplierportal.oracle.database.model.PaymentDetailsTblOracle;
import com.foucsr.supplierportal.oracle.database.model.PendingInvoiceOracle;
import com.foucsr.supplierportal.oracle.database.model.PlantOracle;
import com.foucsr.supplierportal.oracle.database.model.PrePaymentInvoiceOracle;
import com.foucsr.supplierportal.oracle.database.model.RTVDetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.ShipMentStatusOracle;
import com.foucsr.supplierportal.oracle.database.model.ShipMentTblOracle;
import com.foucsr.supplierportal.oracle.database.model.SupplierSitesOracle;
import com.foucsr.supplierportal.oracle.database.model.UOMOracle;
import com.foucsr.supplierportal.oracle.database.repository.ApSuppliersOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ClosedPODetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.DebitNoteOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.InvoiceDetailsTblOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.LocationsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.MasterItemsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.MasterOrganizationsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.OpenCreditOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.OpenPODetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.OperatingUnitsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.POAgentsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PaymentAdviceOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PaymentDetailsTblOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PendingInvoiceOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PlantOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PrePaymentInvoiceDetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.RTVDetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ShipMentStatusOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ShipMentTblOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.SupplierSitesOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.UOMOracleRepository;

@Service
public class JobSchedulerSAP {

	@Autowired
	private ClosedPODetailsOracleRepository closedPODetailsRepositoryOracel;

	@Autowired
	private ClosedPODetailsRepository closedPODetailsRepositoryMysql;
	
	
	@Autowired
	private InvoiceDetailsTblOracleRepository invoiceDetailsTblOracleRepositoryOracle;
	
	@Autowired
	private InvoiceDetailsTblRepository invoiceDetailsTblRepositoryMysql;
	
	
	@Autowired
	private OpenPODetailsOracleRepository openPODetailsOracleRepositoryOracle;
	
	@Autowired
	private OpenPODetailsRepository openPODetailsRepositoryMysql;
	
	@Autowired
	private OpenPoChangeDetailsRepository openPOChengeDetailsRepositoryMysql;
	
	@Autowired
	private PaymentDetailsTblOracleRepository paymentDetailsTblOracleRepositoryOracle;
	
	@Autowired
	private PaymentDetailsTblRepository paymentDetailsTblRepositoryyMysql;
	
	
	@Autowired
	private RTVDetailsOracleRepository rTVDetailsOracleRepositoryOracle;
	
	@Autowired
	private RTVDetailsRepository rTVDetailsRepositoryMysql;
	//
	
	@Autowired
	private ShipMentStatusOracleRepository shipMentStatusOracleRepositoryOracle;
	
	@Autowired
	private POAgentsOracleRepository poAgentsOracleRepositoryOracle;
	
	@Autowired
	private ShipMentStatusRepository shipMentStatusRepositoryMysql;
	
	@Autowired
	private PoAgentsRepository poAgentsRepositoryMysql;
	
	@Autowired
	private ApSuppliersOracleRepository apSuppliersOracleRepository;
	
	@Autowired
	private ApSuppliersRepository apSuppliersMysqlRepository;
	
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    OpenPODetailsService openPODetailsService;
    
    @Autowired
	private PrePaymentInvoiceDetailsOracleRepository prePaymentInvoiceDetailsOracleRepository;
    
    @Autowired
	private PrePaymentInvoiceDetailsRepository prePaymentInvoiceDetailsRepository;
    
    @Autowired
	private DebitNoteOracleRepository debitNoteOracleRepository;
    
    @Autowired
	private DebitNoteRepository debitNoteRepository;
    
    @Autowired
   	private PendingInvoiceOracleRepository pendingInvoiceOracleRepository;
       
    @Autowired
   	private PendingInvoiceRepository pendingInvoiceRepository;
    
    @Autowired
   	private MasterItemsOracleRepository masterItemsOracleRepository;
       
    @Autowired
   	private MasterItemsRepository masterItemsRepository;
    
    @Autowired
   	private MasterOrganizationsOracleRepository masterOrganizationsOracleRepository;
       
    @Autowired
   	private MasterOrganizationsRepository masterOrganizationsRepository;
   	
    @Autowired
   	private OperatingUnitsOracleRepository operatingUnitsOracleRepository;
       
    @Autowired
   	private OperatingUnitsRepository operatingUnitsRepository;
    
    @Autowired
   	private LocationsOracleRepository locationsOracleRepository;
       
    @Autowired
   	private LocationsRepository locationsRepository;
    
    @Autowired
   	private SupplierSitesOracleRepository supplierSitesOracleRepository;
       
    @Autowired
   	private SupplierSitesRepository supplierSitesRepository;
    
    @Autowired
   	private UOMOracleRepository uOMOracleRepository;
       
    @Autowired
   	private UOMRepository uOMRepository;
    
    @Autowired
    private ShipMentTblRepository shipMentTblRepository;
    
    @Autowired
   	private OpenCreditOracleRepository openCreditOracleRepository;
       
    @Autowired
   	private OpenCreditMysqlRepository openCreditMysqlRepository;
    
    
    @Autowired
   	private PlantOracleRepository plantOracleRepository;
       
    @Autowired
   	private PlantMysqlRepository plantMysqlRepository;
      
    
	
	
	Logger log = LoggerFactory.getLogger(JobSchedulerSAP.class);

//	@Scheduled(cron = "0 0/1 * * * *")
	@Scheduled(fixedRate=5*60*1000)
	public void add2DBJob() {
		
		try {
			
//			testConnection();
			
			dataMoveForOpenPODetails();
			dataMoveForShipMentStatus();
			dataMoveForClosedPODetails();
			dataMoveForPaymentDetailsTbl();
			dataMoveForPOAgents();
			dataMoveForSuppliers();
			
			
			
			
//			dataMoveForPlant();
			
			
//			dataMoveForInvoiceDetailsTbl();
//			dataMoveForRTVDetails();
//			dataMoveForPrePaymentInvoiceDetails();
//			dataMoveForDebitNoteDetails();
//			dataMoveForPendingInvoiceDetails();
//			dataMoveForMasterItemsDetails();
//			dataMoveForMasterOrganizationsDetails();
//			dataMoveForOperatingUnitDetails();
//			dataMoveForLocationDetails();
//			dataMoveForSupplierSitesDetails();
//			dataMoveForUOMDetails();
//			getForEntityEmployeesAsArray();
		} catch (Exception e) {
			System.out.println(e);
			log.info("***************** Error while move data from SAP to Mysql  *********************\n" + e);
		}
	}

	
	private void dataMoveForShipMentStatus() throws BeansException {
		List<ShipMentStatusOracle> list = null;
		List<ShipMentStatus> shipList = new ArrayList<ShipMentStatus>();
		list = shipMentStatusOracleRepositoryOracle.findByFirstNameAndLastName();
		for (ShipMentStatusOracle user : list) {
			
			ShipMentStatus shipMentStatus = new ShipMentStatus();
			
			user.setQuantity_accepted(user.getQuantity_received());
			
			if ("I".equals(user.getProcessStatus())) {
				
				shipMentStatus = shipMentStatusRepositoryMysql.findByHeaderIdAndPoLineLocationId(user.getHeader_id(),
						user.getPo_line_location_id(),user.getAsn());				
				
				if(shipMentStatus != null) {
					continue;
				}
				shipMentStatus = new ShipMentStatus();
				
				BeanUtils.copyProperties(user, shipMentStatus);
				
				// for demo purpose 
				shipMentStatus.setLine_type("Goods");
				
				// Set the supplier invoice no , invoice date , do num
				ShipMentTbl shipment = shipMentTblRepository.getShipMentStatusByASNOfMaxId(user.getAsn());
				
				shipMentStatus.setSupp_invoice_num(shipment.getSupp_invoice_num());
				shipMentStatus.setSupp_shipped_date(shipment.getSupp_shipped_date());
				shipMentStatus.setDo_num(shipment.getDo_num());
				shipMentStatus.setAsn_creation_date(shipment.getCreatedAt());
				
				String inv_upload_status = shipment.getIs_inv_uploaded() == null ? "N" : shipment.getIs_inv_uploaded();
				shipMentStatus.setIs_inv_uploaded(inv_upload_status);
				
				if(shipment.getInv_upload_date() != null) {
					shipMentStatus.setInv_upload_date(shipment.getInv_upload_date());
				}
				
				if(user.getDo_date() != null) {
					
					SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
					Date do_upload_date = new Date();
					try {
						do_upload_date = inFormat.parse(user.getDo_date());
					} catch (ParseException e) {
						do_upload_date = new Date();
					}
					shipMentStatus.setDo_upload_date(do_upload_date);
				}
				

			} else if ("U".equals(user.getProcessStatus())) {

				shipMentStatus = shipMentStatusRepositoryMysql.findByHeaderIdAndPoLineLocationId(user.getHeader_id(),
						user.getPo_line_location_id(),user.getAsn());
				
				if(shipMentStatus != null) {
					
//					shipMentStatus.setQty_ordered(user.getQty_ordered());
//					shipMentStatus.setQty_ordered(user.getQuantity_ordered());
//					shipMentStatus.setReceiving_quantity(user.getReceiving_quantity());
					shipMentStatus.setPending_qty(user.getPending_qty());
					shipMentStatus.setQuantity_received(user.getQuantity_received());
					shipMentStatus.setQuantity_accepted(user.getQuantity_accepted());
					shipMentStatus.setQuantity_rejected(user.getQuantity_rejected());
					shipMentStatus.setQuantity_billed(user.getQuantity_billed());
					shipMentStatus.setQuantity_cancelled(user.getQuantity_cancelled());
//					shipMentStatus.setReceipt_number(user.getReceipt_number());
					shipMentStatus.setReceipt_number_list(user.getReceipt_number_list());
					
				}
				
			}
			
			if(shipMentStatus != null) {
			  shipMentStatus.setProcessStatus("C");
			 try { 
			  shipMentStatusRepositoryMysql.save(shipMentStatus);
			  shipList.add(shipMentStatus);
			}catch(Exception ex) {
				log.info("***************** Error while move shipment status from SAP to Mysql  *********************\n" + ex);
			}
//			  user.setProcessStatus("C");
//			  shipMentStatusOracleRepositoryOracle.save(user);
			}
		}
		
		// ack the shipment status by call the SOAP service
		try {

			if (shipList.size() > 0) {

				shipMentStatusOracleRepositoryOracle.ackAgentbySOAPService(shipList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for payment  *********************\n" + e);
		}
	}
	
	
	/*private void dataMoveForRTVDetails() throws BeansException {
		List<RTVDetailsOracle> list = null;
		list = rTVDetailsOracleRepositoryOracle.findByFirstNameAndLastName();
		for (RTVDetailsOracle user : list) {
			RTVDetails rTVDetails = new RTVDetails();
			BeanUtils.copyProperties(user, rTVDetails,"id");
			rTVDetails.setProcessStatus("P");
			rTVDetailsRepositoryMysql.save(rTVDetails);
			user.setProcessStatus("C");
			rTVDetailsOracleRepositoryOracle.save(user);
		}
	}
	
	*/
	
	
	private void dataMoveForPaymentDetailsTbl() throws BeansException {
		List<PaymentDetailsTblOracle> list = null;
		List<PaymentDetailsTbl> payList = new ArrayList<PaymentDetailsTbl>();
		
		list = paymentDetailsTblOracleRepositoryOracle.findByFirstNameAndLastName();
		for (PaymentDetailsTblOracle user : list) {
			PaymentDetailsTbl paymentDetailsTbl = new PaymentDetailsTbl();
			
			paymentDetailsTbl = paymentDetailsTblRepositoryyMysql.getPaymentDetailsById(user.getId());
			
			if ("I".equals(user.getProcessStatus())) {

				if (paymentDetailsTbl != null) {
					continue;
				}

				paymentDetailsTbl = new PaymentDetailsTbl();

				BeanUtils.copyProperties(user, paymentDetailsTbl, "id");
				paymentDetailsTbl.setId(user.getId());
				paymentDetailsTbl.setProcessStatus("C");

			} else if ("U".equals(user.getProcessStatus())) {

				if (paymentDetailsTbl == null) {
					continue;
				}
				
				paymentDetailsTbl.setPayment_number(user.getPayment_number());
				paymentDetailsTbl.setInvoice_id(user.getInvoice_id());
				paymentDetailsTbl.setPayment_date(user.getPayment_date());
				paymentDetailsTbl.setCurrency_code(user.getCurrency_code());
				paymentDetailsTbl.setPayment_amount(user.getPayment_amount());
				paymentDetailsTbl.setInvoice_payment_type(user.getInvoice_payment_type());
				paymentDetailsTbl.setPayment_status(user.getPayment_status());
				
				paymentDetailsTbl.setProcessStatus("C");
			}
			
			try {
			  paymentDetailsTblRepositoryyMysql.save(paymentDetailsTbl);
			  payList.add(paymentDetailsTbl);
			}catch(Exception ex) {
				log.info("***************** Error while move payment from SAP to Mysql  *********************\n" + ex);
			}
//			user.setProcessStatus("C");
//			paymentDetailsTblOracleRepositoryOracle.save(user);
		}
		
		// ack the closed po by call the SOAP service
		try {

			if (payList.size() > 0) {

				paymentDetailsTblOracleRepositoryOracle.ackAgentbySOAPService(payList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for payment  *********************\n" + e);
		}
	}
	
	
	private void dataMoveForOpenPODetails() throws BeansException {
		
		List<OpenPODetailsOracle> list = null;
		List<OpenPODetails> newPOsList = new ArrayList<OpenPODetails>();
		List<OpenPODetails> savedPOsList = new ArrayList<OpenPODetails>();
		list = openPODetailsOracleRepositoryOracle.findByFirstNameAndLastName();
		
		Long po_header_id = null;
		Long rev_no = null;
		
		for (OpenPODetailsOracle user : list) {
			
//			if (user.getHeaderId() != 271 && user.getHeaderId() != 272  ) {
//				continue;
//			}
			
			
			System.out.println(user.toString());
			
			OpenPODetails openPODetails = new OpenPODetails();

			if ("I".equals(user.getProcessStatus())) {
				
				// as of now avoid duplicat
				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
				if(openPODetails != null) {
					continue;
				}
				
				openPODetails = new OpenPODetails();
				
				//

				BeanUtils.copyProperties(user, openPODetails);
				openPODetails.setAsn_reserve_qty((user.getPending_qty()));
				
				openPODetails.setScn_reserve_amount(user.getPending_amount());
				
				// By default set 0 for the change request count
				openPODetails.setChangeRequestCount(0);
				
				newPOsList.add(openPODetails);
				
			} else if ("U".equals(user.getProcessStatus())) {

				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
								
				if(openPODetails != null) {
					
					if(po_header_id == null ) {
						
						po_header_id = openPODetails.getPo_header_id();
						rev_no = user.getRevisionNo();
					}
					
					// added this for => orderd 100 changed 50 shipped 40 receipt 20 case issue fix
//					if(openPODetails.getQty_ordered() != user.getQty_ordered()) {
				    if(Double.compare(openPODetails.getQty_ordered(), user.getQty_ordered()) != 0) {
						
						openPODetails.setAsn_reserve_qty(user.getQty_ordered());
					}
							
					openPODetails.setQty_ordered(user.getQty_ordered());
					openPODetails.setUnit_price((user.getUnit_price()));
					openPODetails.setNeed_by_date((user.getNeed_by_date()));
					openPODetails.setPending_qty(user.getPending_qty());
					// commented for orderd 100 shipped 40 receipt 20 case issue fix 
//					openPODetails.setAsn_reserve_qty(user.getPending_qty());
					openPODetails.setRevisionNo(user.getRevisionNo());
					
					openPODetails.setIsChanged(null);
					
					openPODetails.setReschedule(null);
					
					/*if(openPODetails.getChangeRequestCount() == 2) {
				   	
					openPODetails.setAck("Y");

				}else if (openPODetails.getChangeRequestCount() == 1) {
					
					openPODetails.setAck(null);
					openPODetails.setBuyer_approval(null);
				}*/
					
					openPODetails.setBuyer_approval(null);
					
					// need to delete
					OpenPoChangeDetails openPOChengeDetails = openPOChengeDetailsRepositoryMysql.findByHeaderIdAndPoLineLocationId(openPODetails.getHeaderId(),openPODetails.getPoLineLocationId());
					
					if(openPOChengeDetails != null) {
						
						openPOChengeDetailsRepositoryMysql.delete(openPOChengeDetails);
					}
					
				}
			} else if("R".equals(user.getProcessStatus())) {
				
				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
				
				if(openPODetails != null) {
					
					openPODetails.setReschedule(user.getReschedule());
					
					if(user.getReschedule() == null) {
						
						openPODetails.setIsChanged(null);
						openPODetails.setBuyer_approval(null);
						
						OpenPoChangeDetails openPOChengeDetails = openPOChengeDetailsRepositoryMysql.findByHeaderIdAndPoLineLocationId(openPODetails.getHeaderId(),openPODetails.getPoLineLocationId());
						
						if(openPOChengeDetails != null) {
							
							openPOChengeDetailsRepositoryMysql.delete(openPOChengeDetails);
						}
						
					}												
				}
				
				// Service amount updation
			} else if ("A".equals(user.getProcessStatus())) {

				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
								
				if(openPODetails != null) {
					
					if(po_header_id == null ) {
						
						po_header_id = openPODetails.getPo_header_id();
						rev_no = user.getRevisionNo();
					}
							
					openPODetails.setPending_amount(user.getPending_amount());																				
					
				}
			}
			
			if(openPODetails != null) {
				
				openPODetails.setProcessStatus("C");
				// openPODetails.setPoLineLocationId(user.getPo_line_location_id());
				
				try {
				openPODetailsRepositoryMysql.save(openPODetails);
				savedPOsList.add(openPODetails);
				}catch(Exception ex) {
					log.info("***************** Error while move po from SAP to Mysql  *********************\n" + ex);
				}
				user.setProcessStatus("C");
				
//				try {
//					openPODetailsOracleRepositoryOracle.updatePOProcess(user);
//				} catch (JsonProcessingException | URISyntaxException e) {
//					log.info("***************** Error while move data from SAP to Mysql  *********************\n" + e);
//				}
			}
			
		}
		
		//  ack the open po by call the SOAP service
		try {
			
			if(savedPOsList.size() > 0 ) {
				
				openPODetailsOracleRepositoryOracle.ackOpenPObySOAPService(savedPOsList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for open po  *********************\n" + e);
		}
		
		
		
		// update Rev no to all lines 		
		/*List<OpenPODetails> allPOLines = openPODetailsRepositoryMysql.findPOBYHeaderId(po_header_id);
		
		if(allPOLines != null && allPOLines.size() > 0) {
			
			for(OpenPODetails  openPO : allPOLines) {
				
				openPO.setRevisionNo(rev_no);
			}
			
			openPODetailsRepositoryMysql.saveAll(allPOLines);
		}*/
		
//		openPODetailsService.sendReminder(newPOsList, 'P');		
		
	}
	
	
	/*private void dataMoveForInvoiceDetailsTbl() throws BeansException {
		List<InvoiceDetailsTblOracle> list = null;
		list = invoiceDetailsTblOracleRepositoryOracle.findByFirstNameAndLastName();
		for (InvoiceDetailsTblOracle user : list) {
			InvoiceDetailsTbl invoiceDetailsTbl = new InvoiceDetailsTbl();
			BeanUtils.copyProperties(user, invoiceDetailsTbl,"id");
			invoiceDetailsTbl.setProcessStatus("P");
			invoiceDetailsTblRepositoryMysql.save(invoiceDetailsTbl);
			user.setProcessStatus("C");
			invoiceDetailsTblOracleRepositoryOracle.save(user);
		}
	}
*/	

	private void dataMoveForClosedPODetails() throws BeansException {
		List<ClosedPODetailsOracle> list = null;
		
		List<ClosedPODetails> closedPOList = new ArrayList<ClosedPODetails>();
		
		list = closedPODetailsRepositoryOracel.findByFirstNameAndLastName();
		for (ClosedPODetailsOracle user : list) {
			ClosedPODetails ClosedPODetailsMysql = new ClosedPODetails();
			
			ClosedPODetailsMysql = closedPODetailsRepositoryMysql.getClosedPoDetailsById(user.getId());
			
			if(ClosedPODetailsMysql != null) {
				continue;
			}
			ClosedPODetailsMysql = new ClosedPODetails();
			
			MasterOrganizations masterOrg = masterOrganizationsRepository.findOrganizationByName(user.getOrganization_name());
			BeanUtils.copyProperties(user, ClosedPODetailsMysql, "id");
			ClosedPODetailsMysql.setId(user.getId());
			
			String asn = user.getShipment_num();
			
			if(masterOrg != null) {
				
				 asn = user.getShipment_num().replaceAll(masterOrg.getOrganization_Id().toString(), "");
			}
			ClosedPODetailsMysql.setShipment_num(asn);
			ClosedPODetailsMysql.setProcessStatus("C");
			try {
			 closedPODetailsRepositoryMysql.save(ClosedPODetailsMysql);
			 closedPOList.add(ClosedPODetailsMysql);
			} catch (Exception ex) {
				log.info("***************** Error while move closed po from SAP to Mysql  *********************\n" + ex);
			}
//			user.setProcessStatus("C");
//			closedPODetailsRepositoryOracel.save(user);
						
		}
		
		// ack the closed po by call the SOAP service
		try {

			if (closedPOList.size() > 0) {

				closedPODetailsRepositoryOracel.ackAgentbySOAPService(closedPOList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for closed po  *********************\n" + e);
		}
	}
	
	private void dataMoveForPOAgents() throws BeansException {
		List<POAgentsOracle> list = null;
		List<PoAgents> savedAgentList = new ArrayList<PoAgents>();
		
		list = poAgentsOracleRepositoryOracle.findByFirstNameAndLastName();
		for (POAgentsOracle agent : list) {
			PoAgents agentMysql = new PoAgents();
			
			if ("I".equals(agent.getPoProcessStatus())) {
				
				agentMysql = poAgentsRepositoryMysql.findByAgentId(Long.toString(agent.getAgentId()));
				
				if(agentMysql != null) {
					continue;
				}
				agentMysql = new PoAgents();
				
				BeanUtils.copyProperties(agent, agentMysql);
			} 
			/*else if ("U".equals(agent.getPoProcessStatus())) {
				
				agentMysql = poAgentsRepositoryMysql.findByAgentId(Long.toString(agent.getAgentId()));
				
				if(agentMysql != null) {
					
					agentMysql.setStartDateActive(agent.getStartDateActive());
					agentMysql.setEndDateActive(agent.getEndDateActive());
					
					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					if(agent.getEndDateActive() != null && agent.getEndDateActive().compareTo(date) > 0) {
						
						List<User> users = userRepository.findByAgentId(agent.getAgentId());
						
						for(User user : users) {
							user.setIs_Active('N');
							userRepository.save(user);
						}
						
					}
				}
					
			}*/
			
			if(agentMysql != null) {
				
				agentMysql.setPoProcessStatus("C");
				try {
				poAgentsRepositoryMysql.save(agentMysql);
				savedAgentList.add(agentMysql);
				}catch(Exception ex) {
					log.info("***************** Error while move buyer from SAP to Mysql  *********************\n" + ex);
				}
//				agent.setPoProcessStatus("C");
//				poAgentsOracleRepositoryOracle.save(agent);
				
			}
		}
		
	//  ack the supplier by call the SOAP service
			try {
				
				if(savedAgentList.size() > 0 ) {
					
					poAgentsOracleRepositoryOracle.ackAgentbySOAPService(savedAgentList);
				}
			} catch (Exception e) {
				log.info("***************** Error while call ack service for buyer  *********************\n" + e);
			}
	}
	
	private void dataMoveForSuppliers() throws BeansException {
		List<ApSuppliersOracle> list = null;
		list = apSuppliersOracleRepository.findByFirstNameAndLastName();
		
		List<ApSuppliers> savedSupplierList = new ArrayList<ApSuppliers>();
		
		for (ApSuppliersOracle supplerPo : list) {
			ApSuppliers supplierMysql = new ApSuppliers();
			
			if ("I".equals(supplerPo.getProcessStatus())) {
				
				if(supplerPo.getVendor_id() == null) {
				
					continue;
				}
				
                supplierMysql = apSuppliersMysqlRepository.findByVendorIDId(Long.toString(supplerPo.getVendor_id()));
				
				if(supplierMysql != null) {
					
					continue;
				}
				
				supplierMysql = new ApSuppliers();
				
				
				BeanUtils.copyProperties(supplerPo, supplierMysql);
			} 
			
			/*else if ("U".equals(supplerPo.getProcessStatus())) {
				
				supplierMysql = apSuppliersMysqlRepository.findByVendorIDId(Long.toString(supplerPo.getVendor_id()));
				
				if(supplierMysql != null) {
					
					supplierMysql.setStart_date_active(supplerPo.getStart_date_active());
					supplierMysql.setEnd_date_active(supplerPo.getEnd_date_active());
					
					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					if(date != null && supplerPo.getEnd_date_active() != null && date.compareTo(supplerPo.getEnd_date_active()) > 0) {
						
						List<User> users = userRepository.findByVendorId(supplerPo.getVendor_id());
						
						for(User user : users) {
							user.setIs_Active('N');
							userRepository.save(user);
						}
						
					}
					
				}
			}*/
			
			if(supplierMysql != null) {
								
				supplierMysql.setProcessStatus("C");
			try {	
				apSuppliersMysqlRepository.save(supplierMysql);
				savedSupplierList.add(supplierMysql);
			}catch(Exception ex) {
				log.info("***************** Error while move vendor from SAP to Mysql  *********************\n" + ex);
			}
				supplerPo.setProcessStatus("C");
//				apSuppliersOracleRepository.save(supplerPo);
			}
		}
			
	//  ack the supplier by call the SOAP service
			try {
				
				if(savedSupplierList.size() > 0 ) {
					
					apSuppliersOracleRepository.ackSupplierbySOAPService(savedSupplierList);
				}
			} catch (Exception e) {
				log.info("***************** Error while call ack service for supplier  *********************\n" + e);
			}
	}
	
	/*private void dataMoveForPrePaymentInvoiceDetails() throws BeansException {
		List<PrePaymentInvoiceOracle> list = null;
		list = prePaymentInvoiceDetailsOracleRepository.findAllNewPrePayments();
		for (PrePaymentInvoiceOracle prePaymentOracle : list) {
			PrePaymentInvoice prePayment = new PrePaymentInvoice();
			BeanUtils.copyProperties(prePaymentOracle, prePayment,"id");
			prePayment.setPoProcessStatus("P");
			prePaymentInvoiceDetailsRepository.save(prePayment);
			prePaymentOracle.setPoProcessStatus("C");
			prePaymentInvoiceDetailsOracleRepository.save(prePaymentOracle);
		}
	}
	
	private void dataMoveForDebitNoteDetails() throws BeansException {
		List<DebitNoteOracle> list = null;
		list = debitNoteOracleRepository.findAllDebitNotes();
		for (DebitNoteOracle debitNoteOracle : list) {
			DebitNote debitNote = new DebitNote();
			BeanUtils.copyProperties(debitNoteOracle, debitNote,"id");
			debitNote.setPoProcessStatus("P");
			debitNoteRepository.save(debitNote);
			debitNoteOracle.setPoProcessStatus("C");
			debitNoteOracleRepository.save(debitNoteOracle);
		}
	}
	
	private void dataMoveForPendingInvoiceDetails() throws BeansException {
		List<PendingInvoiceOracle> list = null;
		list = pendingInvoiceOracleRepository.findAllPendingInvoice();
		for (PendingInvoiceOracle pendingInvoiceOracle : list) {
			PendingInvoice pendingInvoice = new PendingInvoice();
			BeanUtils.copyProperties(pendingInvoiceOracle, pendingInvoice,"id");
			pendingInvoice.setPoProcessStatus("P");
			pendingInvoiceRepository.save(pendingInvoice);
			pendingInvoiceOracle.setPoProcessStatus("C");
			pendingInvoiceOracleRepository.save(pendingInvoiceOracle);
		}
	}
	
	
	private void dataMoveForMasterItemsDetails() throws BeansException {
		List<MasterItemsOracle> list = null;
		list = masterItemsOracleRepository.findAllMasterItems();
		for (MasterItemsOracle masterItemOracle : list) {
			MasterItems masterItem = new MasterItems();
			BeanUtils.copyProperties(masterItemOracle, masterItem);
			masterItem.setPoProcessStatus("P");
			masterItem.setPurchase_item_flag("Y");
			masterItem.setPurchase_enable_flag("Y");
			masterItemsRepository.save(masterItem);
			masterItemOracle.setPoProcessStatus("C");
			masterItemsOracleRepository.save(masterItemOracle);
		}
	}
	
	private void dataMoveForMasterOrganizationsDetails() throws BeansException {
		List<MasterOrganizationsOracle> list = null;
		list = masterOrganizationsOracleRepository.findAllOrganizations();
		for (MasterOrganizationsOracle masterOrgOracle : list) {
			MasterOrganizations masterOrg = new MasterOrganizations();
			BeanUtils.copyProperties(masterOrgOracle, masterOrg);
			masterOrg.setPoProcessStatus("P");
			masterOrganizationsRepository.save(masterOrg);
			masterOrgOracle.setPoProcessStatus("C");
			masterOrganizationsOracleRepository.save(masterOrgOracle);
		}
	}
	
	private void dataMoveForOperatingUnitDetails() throws BeansException {
		List<OperatingUnitsOracle> list = null;
		list = operatingUnitsOracleRepository.findAllOperatingUnits();
		for (OperatingUnitsOracle ouOracle : list) {
			OperatingUnits ou = new OperatingUnits();
			BeanUtils.copyProperties(ouOracle, ou);
			ou.setPoProcessStatus("P");
			operatingUnitsRepository.save(ou);
			ouOracle.setPoProcessStatus("C");
			operatingUnitsOracleRepository.save(ouOracle);
		}
	}
	
	private void dataMoveForLocationDetails() throws BeansException {
		List<LocationsOracle> list = null;
		list = locationsOracleRepository.findAllLocations();
		for (LocationsOracle locationsOracle : list) {
			Locations locations = new Locations();
			BeanUtils.copyProperties(locationsOracle, locations);
			locations.setPoProcessStatus("P");
			locations.setShip_to_location_id(locationsOracle.getShip_to_location_id());
			locationsRepository.save(locations);
			locationsOracle.setPoProcessStatus("C");
			locationsOracleRepository.save(locationsOracle);
		}
	}
	
	private void dataMoveForSupplierSitesDetails() throws BeansException {
		List<SupplierSitesOracle> list = null;
		list = supplierSitesOracleRepository.findAllSupplierSites();
		for (SupplierSitesOracle supplierSitesOracle : list) {
			SupplierSites supplierSites = new SupplierSites();
			BeanUtils.copyProperties(supplierSitesOracle, supplierSites);
			supplierSites.setPoProcessStatus("P");
			supplierSitesRepository.save(supplierSites);
			supplierSitesOracle.setPoProcessStatus("C");
			supplierSitesOracleRepository.save(supplierSitesOracle);
		}
	}
	
	private void dataMoveForUOMDetails() throws BeansException {
		List<UOMOracle> list = null;
		list = uOMOracleRepository.findAllUOM();
		for (UOMOracle uomOracle : list) {
			UOM uom = new UOM();
			BeanUtils.copyProperties(uomOracle, uom);
			uom.setPoProcessStatus("P");
			uOMRepository.save(uom);
			uomOracle.setPoProcessStatus("C");
			uOMOracleRepository.save(uomOracle);
		}
	}
*/
  private void getForEntityEmployeesAsArray() {

	  RestTemplate restTemplate = new RestTemplate();
	  
	  String openPOURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zapi_protocal?sap-client=200";

		ResponseEntity<OpenPODetailsTest[]> response = restTemplate.getForEntity(
				openPOURL , OpenPODetailsTest[].class);

		OpenPODetailsTest[] openPODetailsTest = response.getBody();

		for (OpenPODetailsTest openPO : openPODetailsTest) {
			OpenPODetails openPODetails = new OpenPODetails();
			BeanUtils.copyProperties(openPO, openPODetails);
			openPODetails.setProcessStatus("P");
			// openPODetails.setPoLineLocationId(user.getPo_line_location_id());
			openPODetailsRepositoryMysql.save(openPODetails);
		}

	}
  
  private void testConnection() {

		try{  
			
			Class.forName("com.mysql.jdbc.Driver");  
			
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://192.168.1.36:3306/sap_vendor_portal","admin","Password@123");  
			  
			con.close();  
			
			}catch(Exception e){ 
				
				log.error("***************** Unable to get Mysql test connection  *********************\n" + e);

			}  
	}
	
  
  /*private void dataMoveForOpenCredit() throws BeansException {
		List<OpenCreditOracle> list = null;
		List<OpenCreditMysql> payList = new ArrayList<OpenCreditMysql>();
		
		list = openCreditOracleRepository.findLatestOpenCredit();
		for (OpenCreditOracle user : list) {
			OpenCreditMysql paymentDetailsTbl = new OpenCreditMysql();
			
			paymentDetailsTbl = openCreditMysqlRepository.getOpenCreditById(user.getHeader_id());
					
			if(paymentDetailsTbl != null) {
				continue;
			}
			
			paymentDetailsTbl = new OpenCreditMysql();
			
			BeanUtils.copyProperties(user, paymentDetailsTbl);
			paymentDetailsTbl.setPstat("C");
			try {
				openCreditMysqlRepository.save(paymentDetailsTbl);
			  payList.add(paymentDetailsTbl);
			}catch(Exception ex) {
				log.info("***************** Error while move OPen Credit from SAP to Mysql  *********************\n" + ex);
			}
//			user.setProcessStatus("C");
//			paymentDetailsTblOracleRepositoryOracle.save(user);
		}
		
		// ack the open credit po by call the SOAP service
		try {

			if (payList.size() > 0) {

				openCreditOracleRepository.ackAgentbySOAPService(payList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for open credit  *********************\n" + e);
		}
	}
*/

  /*private void dataMoveForPaymentAdvice() throws BeansException {
		List<PaymentAdviceOracle> list = null;
		List<PaymentAdviceMysql> payList = new ArrayList<PaymentAdviceMysql>();
		
		list = paymentAdviceOracleRepository.findLatestPaymentAdvice();
		for (PaymentAdviceOracle user : list) {
			PaymentAdviceMysql paymentDetailsTbl = new PaymentAdviceMysql();
			
			paymentDetailsTbl = paymentAdviceMysqlRepository.getpaymentAdviceById(user.getHeader_id());
					
			if(paymentDetailsTbl != null) {
				continue;
			}
			
			paymentDetailsTbl = new PaymentAdviceMysql();
			
			BeanUtils.copyProperties(user, paymentDetailsTbl);
			paymentDetailsTbl.setPstat("C");
			try {
				paymentAdviceMysqlRepository.save(paymentDetailsTbl);
			  payList.add(paymentDetailsTbl);
			}catch(Exception ex) {
				log.info("***************** Error while move payment advice from SAP to Mysql  *********************\n" + ex);
			}
//			user.setProcessStatus("C");
//			paymentDetailsTblOracleRepositoryOracle.save(user);
		}
		
		// ack the open credit po by call the SOAP service
		try {

			if (payList.size() > 0) {

				openCreditOracleRepository.ackAgentbySOAPService(payList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for payment advice  *********************\n" + e);
		}
	}
*/	
  
  private void dataMoveForPlant() throws BeansException {
		List<PlantOracle> list = null;
		List<PlantMysql> payList = new ArrayList<PlantMysql>();
		
		list = plantOracleRepository.findLatestPlant();
		
		for (PlantOracle user : list) {
			PlantMysql paymentDetailsTbl = new PlantMysql();
			
			paymentDetailsTbl = plantMysqlRepository.getPlantByPlant(user.getPlant());
					
			if(paymentDetailsTbl != null) {
				continue;
			}
			
			paymentDetailsTbl = new PlantMysql();
			
			BeanUtils.copyProperties(user, paymentDetailsTbl);
			paymentDetailsTbl.setPstat("C");
			try {
				plantMysqlRepository.save(paymentDetailsTbl);
			  payList.add(paymentDetailsTbl);
			}catch(Exception ex) {
				log.info("***************** Error while move Plant from SAP to Mysql  *********************\n" + ex);
			}
//			user.setProcessStatus("C");
//			paymentDetailsTblOracleRepositoryOracle.save(user);
		}
		
		// ack the open credit po by call the SOAP service
		/*try {

			if (payList.size() > 0) {

				openCreditOracleRepository.ackAgentbySOAPService(payList);
			}
		} catch (Exception e) {
			log.info("***************** Error while call ack service for open credit  *********************\n" + e);
		}*/
	}


}