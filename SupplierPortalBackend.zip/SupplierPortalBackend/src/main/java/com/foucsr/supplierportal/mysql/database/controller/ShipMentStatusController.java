package com.foucsr.supplierportal.mysql.database.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.ShipMentStatusRepositoryService;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;
import com.foucsr.supplierportal.payload.VendorInvDOStatusRequest;

@RestController
@RequestMapping("/ShipMentStatus/Service")
@CrossOrigin
public class ShipMentStatusController {

	@Autowired
	private ShipMentStatusRepositoryService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("")
	public ResponseEntity<?> createNewProject(@Valid @RequestBody ShipMentStatus project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		ShipMentStatus project1 = projectService.saveOrUpdateProject(project, principal.getName());
		return new ResponseEntity<ShipMentStatus>(project1, HttpStatus.CREATED);
	}

	@GetMapping("/{projectId}")
	public ResponseEntity<?> getProjectById(@PathVariable long projectId, Principal principal) {

		Optional<ShipMentStatus> project = projectService.findProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<Optional<ShipMentStatus>>(project, HttpStatus.OK);
	}

	@GetMapping("/all")
	public Iterable<ShipMentStatus> getAllProjects(Principal principal) {
		return projectService.findAllProjects(principal.getName());
	}

	@DeleteMapping("/{projectId}")
	public ResponseEntity<?> deleteProject(@PathVariable long projectId, Principal principal) {
		projectService.deleteProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<String>("Project with ID: '" + projectId + "' was deleted", HttpStatus.OK);
	}
	
	@PostMapping("/getShipmentStatusByDate")
	public List<ShipMentStatus> getShipMentStatusByDate(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getShipMentStatusByDate(byDateRequest);

	}
	
	/*@GetMapping("/getDOAttachments")
	public ResponseEntity<?> getDOAttachments(HttpServletRequest http ,@RequestParam Map<String, String> requestParams, Principal principal) {

		String asn = requestParams.get("asn");

		ResponseEntity<?> message = projectService.getDOAttachments(asn );

		return message;
	}*/
	
	@GetMapping("/getDOAttachments")
	public void zipDownload(@RequestParam Map<String, String> requestParams, HttpServletResponse response) throws IOException {
		
		String asn = requestParams.get("asn");

		projectService.getDOAttachments(asn ,  response );
		
	}
	
	@PostMapping("/getVendorInvDOStatus")
	public ResponseEntity<?> getVendorInvDOStatus(@Valid @RequestBody VendorInvDOStatusRequest byDateRequest,
			Principal principal) {
		return projectService.getVendorInvDOStatus(byDateRequest);

	}
}
