package com.foucsr.supplierportal.mysql.database.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.TaxCountry;

@Repository
public interface TaxCountryRepository extends CrudRepository<TaxCountry, Long> {

	@Query(value = "select * from TAX_COUNTRY", nativeQuery = true)
	List<TaxCountry> findAllTaxCountries();
	
	
	@Query(value = "select * from TAX_COUNTRY where TERRITORY_SHORT_NAME = :name", nativeQuery = true)
	TaxCountry findTaxCountryByName(@Param("name") String name );

}