package com.foucsr.supplierportal.mysql.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RTVDetails;

@Repository
public interface RTVDetailsRepository extends CrudRepository<RTVDetails, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<RTVDetails> findAll();

   
}