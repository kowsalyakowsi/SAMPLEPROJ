package com.foucsr.supplierportal.mysql.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.AgentListProjection;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;

@Service
public class PoAgentsService {

	@Autowired
	private PoAgentsRepository poAgentsRepository;

	public PoAgents saveOrUpdateProject(PoAgents project, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return poAgentsRepository.save(project);

	}

	public Optional<PoAgents> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<PoAgents> project = poAgentsRepository.findById(id);

		return project;
	}

	public Iterable<PoAgents> findAllProjects(String username) {
		return poAgentsRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		poAgentsRepository.deleteById(id);
	}
	
	
	public PoAgents findByAgentId(String agentID) {

		PoAgents findVendorId=	poAgentsRepository.findByAgentId(agentID);
		
		return findVendorId; 
	}
	
	public List<AgentListProjection> findAllByAgentId() {

		return poAgentsRepository.findDistinctByAgents(); 
	}
	
}
