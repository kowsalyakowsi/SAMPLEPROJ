package com.foucsr.supplierportal.mysql.database.service;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentStatusRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;
import com.foucsr.supplierportal.payload.VendorInvDOStatusRequest;
import com.foucsr.supplierportal.payload.VendorInvDOStatusResponse;
import com.foucsr.supplierportal.util.AppConstants;

@Service
public class ShipMentStatusRepositoryService {
	
	Logger logger = LoggerFactory.getLogger(ShipMentStatusRepositoryService.class);

	@Autowired
	private ShipMentStatusRepository shipMentStatusRepository;
	
	@Autowired
	ServletContext context;

	public ShipMentStatus saveOrUpdateProject(ShipMentStatus shipMentStatus, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return shipMentStatusRepository.save(shipMentStatus);

	}

	public Optional<ShipMentStatus> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<ShipMentStatus> shipMentStatus = shipMentStatusRepository.findById(id);

		return shipMentStatus;
	}

	public Iterable<ShipMentStatus> findAllProjects(String username) {
		return shipMentStatusRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		shipMentStatusRepository.deleteById(id);
	}
	
	 public List<ShipMentStatus> getShipMentStatusByDate(GetOpenPoByDateRequest byDateRequest) {
			
			List<ShipMentStatus> list = null;
			
			String line_type = AppConstants.LInE_TYPE_FIXEDPRICE;

			
			try {
				if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
						&& byDateRequest.getVendorId() != null && byDateRequest.getDo_num() != null 
						&& !"".equals(byDateRequest.getDo_num())) {
					
					if("Y".equals(byDateRequest.getIs_asn())) {
						
						Date t_date = getFormattedDateFRomStr(byDateRequest.getToDate());
						t_date.setDate(t_date.getDate() + 1);
		  				String p_to_date = getFormattedDateStrYearFirst2(t_date);
						
						list = shipMentStatusRepository.getShipMentStatusByASNAndDate(byDateRequest.getFromDate(),
								p_to_date, byDateRequest.getVendorId(), byDateRequest.getDo_num(),line_type);
					}else {
						
						list = shipMentStatusRepository.getShipMentStatusBySCnAndDate(byDateRequest.getFromDate(),
								byDateRequest.getToDate(), byDateRequest.getVendorId(), byDateRequest.getASN_ShipmentStatus(),line_type);
						
						
					}
				} 
				else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
						&& byDateRequest.getVendorId() != null) {
					
					if("Y".equals(byDateRequest.getIs_asn())) {
						
						Date t_date = getFormattedDateFRomStr(byDateRequest.getToDate());
						t_date.setDate(t_date.getDate() + 1);
		  				String p_to_date = getFormattedDateStrYearFirst2(t_date);
						
						list = shipMentStatusRepository.getShipMentStatusByAllParm(byDateRequest.getFromDate(),
								p_to_date, byDateRequest.getVendorId(),line_type);
					} else {
						
						list = shipMentStatusRepository.getShipMentStatusScnByAllParm(byDateRequest.getFromDate(),
								byDateRequest.getToDate(), byDateRequest.getVendorId() , line_type);
						
					}
				}
				else if (byDateRequest.getDo_num() != null
						&& byDateRequest.getVendorId() != null) {
					
					if("Y".equals(byDateRequest.getIs_asn())) {
						
						list = shipMentStatusRepository.getShipMentStatusByASN(byDateRequest.getVendorId(), byDateRequest.getDo_num() , line_type);
						
					}else {
						
						list = shipMentStatusRepository.getShipMentStatusBySCN(byDateRequest.getVendorId(), byDateRequest.getASN_ShipmentStatus() , line_type);
						
					}
				}
				else if (byDateRequest.getVendorId() != null) {
					
					if("Y".equals(byDateRequest.getIs_asn())) {
						
						list = shipMentStatusRepository.getShipMentStatusByVendorId(byDateRequest.getVendorId() , line_type);
						
					} else {
						
						list = shipMentStatusRepository.getShipMentStatusSCNByVendorId(byDateRequest.getVendorId() , line_type);
						
					}
				}

			} catch (Exception e) {
				throw new AppException("Unable to get Closed PO details");
			}

			return list;

		}
	 
	public void getDOAttachments(String asn, HttpServletResponse response) {

		try {
			String realPathtoUploads = "K://supplier/";

			File dir = new File(realPathtoUploads);

			Long asnLong = Long.valueOf(asn);
			String formattedASN = String.format("%010d", asnLong);		    
		    formattedASN = "DO-" + formattedASN;

			ResponseEntity<?> resp = null;
			InputStreamResource inputStream = null;

			ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream());

			int count = 0;

			for (File file : dir.listFiles()) {

				if (file.getName().startsWith(formattedASN)) {

					FileSystemResource resource = new FileSystemResource(file.getAbsolutePath());
					java.util.zip.ZipEntry zipEntry = new java.util.zip.ZipEntry(resource.getFilename());
					zipEntry.setSize(resource.contentLength());
					zipOut.putNextEntry(zipEntry);
					StreamUtils.copy(resource.getInputStream(), zipOut);
					zipOut.closeEntry();

					count++;
				}
			}

			if (count == 0) {

				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				return;
			}

			zipOut.finish();
			zipOut.close();

			response.setStatus(HttpServletResponse.SC_OK);
			response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + asn + "\"");

		} catch (Exception e) {

			logger.error("***************** Unable to get DO attachment!  *********************\n" + e);
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}

	}
	
	
   public ResponseEntity<?> getVendorInvDOStatus(VendorInvDOStatusRequest req) {
  		
  		String p_from_date = req.getFromDate();
  		String p_to_date = req.getToDate();
  		String is_inv_uploaded = (req.getIs_inv_uploaded() == null || "".equals(req.getIs_inv_uploaded())) ? "N" : req.getIs_inv_uploaded();
  		String is_do_uploaded = (req.getIs_do_uploaded() == null || "".equals(req.getIs_do_uploaded())) ? "N" : req.getIs_do_uploaded();
  		Date fromDate = null;
  		Date toDate = null;
  		
  		List<VendorInvDOStatusResponse> list = null;
  		
  		try {
  			
  			if(p_from_date == null || "".equals(p_from_date)) {
  				
  				fromDate = shipMentStatusRepository.getMinimumASNCreationDate();
  				fromDate = fromDate == null ? new Date() : fromDate;
  				p_from_date = getFormattedDateStrYearFirst(fromDate);
  				
  			} else {
  				
  				Date f_date = getFormattedDateFRomStr(p_from_date);
  				p_from_date = getFormattedDateStrYearFirst(f_date);
  			}
  			
            if(p_to_date == null || "".equals(p_to_date)) {
  				
  				toDate = shipMentStatusRepository.getMaximumASNCreationDate();
  				toDate = toDate == null ? new Date() : toDate;
  				toDate.setDate(toDate.getDate() + 1);
  				
  				p_to_date = getFormattedDateStrYearFirst(toDate);
  				
  			} else {
  				
  				Date t_date = getFormattedDateFRomStr(p_to_date);
  				p_to_date = getFormattedDateStrYearFirst(t_date);
  			}
            
            list = shipMentStatusRepository.getVendorInvDOStatus(p_from_date, p_to_date, is_inv_uploaded, is_do_uploaded);

  		
  		} catch (Exception e) {

  			logger.error("***************** Unable to get Inv/Do status!  *********************\n" + e);

  			String msg = e.getMessage() != null ? e.getMessage() : "";

  			return new ResponseEntity(new ApiResponse(false, "Unable to get Inv/Do status!" + msg),
  					HttpStatus.BAD_REQUEST);
  		}
  		
  		if(list == null || list.size() == 0) {
  			
  			list = new ArrayList<VendorInvDOStatusResponse>();
  		}

  		return new ResponseEntity(list, HttpStatus.OK);

  	}
   
   
   private String getFormattedDateStrYearFirst(Date date) {

		DateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd");
		String dateString = "";

		try {

			if (date != null) {

				dateString = formatter.format(date);

			} else {

				dateString = "--";
			}

		} catch (Exception e) {

			dateString = "--";
		}

		return dateString;
	}


   private Date getFormattedDateFRomStr(String dateString) {

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
		Date date = new Date();

		try {

			if (dateString != null) {

				date = formatter.parse(dateString);
				
			} else {

				date = new Date();
			}

		} catch (Exception e) {

			date = new Date();
		}

		return date;
	}
   
   
   private String getFormattedDateStrYearFirst2(Date date) {

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = "";

		try {

			if (date != null) {

				dateString = formatter.format(date);

			} else {

				dateString = "--";
			}

		} catch (Exception e) {

			dateString = "--";
		}

		return dateString;
	}



}
