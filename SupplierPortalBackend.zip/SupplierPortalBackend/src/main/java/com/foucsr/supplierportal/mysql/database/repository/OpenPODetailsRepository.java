package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;

@Repository
public interface OpenPODetailsRepository extends CrudRepository<OpenPODetails, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    List<OpenPODetails> findAll();
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND need_by_date=:date order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> findByFirstNameAndLastName(@Param("date") String firstName);
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND (ACK IS NULL) AND VENDOR_ID =:vendorId and (IS_CHANGED IS NULL OR IS_CHANGED = 'N')  and BUYER_APPROVAL IS NULL and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorIds);
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByFromToDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates );
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND (ACK IS NULL)  and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and VENDOR_ID = :vendorId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByVendorId(@Param("vendorId") String vendorId );
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND ACK = 'Y' AND ( (ASN_RESERVE_QTY > 0 AND PENDING_QTY > 0) OR (SCN_RESERVE_AMOUNT > 0 AND PENDING_AMOUNT > 0) ) AND OU_NAME=:orgNames and VENDOR_ID =:vendorId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') AND LINE_TYPE = :lineType order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getOpenPoDetailsByorgName(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorIds,@Param("orgNames") String orgNames, @Param("lineType") String lineType  );
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND ACK = 'Y' AND ( (ASN_RESERVE_QTY > 0 AND PENDING_QTY > 0) OR (SCN_RESERVE_AMOUNT > 0 AND PENDING_AMOUNT > 0) ) AND OU_NAME=:orgNames and VENDOR_ID =:vendorId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getOpenPoDetailsByorgNameForAsn(@Param("vendorId") String vendorId,@Param("orgNames") String orgNames );
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND ACK = 'Y' AND ( (ASN_RESERVE_QTY > 0 AND PENDING_QTY > 0) OR (SCN_RESERVE_AMOUNT > 0 AND PENDING_AMOUNT > 0) ) AND VENDOR_ID =:vendorId AND LINE_TYPE = :lineType order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getOpenPoDetailsByVendorForAsn(@Param("vendorId") String vendorId , @Param("lineType") String lineType );
    
    
    
	
    @Query(value = "select * from  OPEN_PO_DETAILS where RESCHEDULE IS NULL AND HEADER_ID=:headerId AND PO_LINE_LOCATION_ID=:poLineLocationId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    OpenPODetails findByHeaderIdAndPoLineLocationId(@Param("headerId") long headerId,@Param("poLineLocationId") long poLineLocationId);
    
    
    
    
    
    @Query(value = "select distinct OU_NAME from  OPEN_PO_DETAILS where VENDOR_ID=:vendorID", nativeQuery = true)
    List<String> findDistinctStates(@Param("vendorID") String vendorID );
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND PO_NUMBER =:poNumber and ACK = 'Y' and ASN is null and SCN IS NULL AND  VENDOR_ID = :vendorID order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> searchByPoNumber(@Param("poNumber") String poNumber,@Param("vendorID") String vendorID );
    
    
    
    
	
    @Query(value = "select * from  OPEN_PO_DETAILS where HEADER_ID=:headerId and PO_LINE_LOCATION_ID=:poLineId AND VENDOR_ID=:vendorID AND BUYER_ID =:buyerId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    OpenPODetails findByHeaderIdAndforASNcreations(@Param("headerId") Long headerId,@Param("poLineId") Long poLineLocationId, @Param("vendorID") String vendorId, @Param("buyerId") String buyerId);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') and buyer_id = :buyerId and RESCHEDULE IS NULL order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByFromToDateBuyer(@Param("fromDate") String fromDates,@Param("toDate") String toDates , @Param("buyerId") String buyerId);
    
    
    
    

    @Query(value = "select * from OPEN_PO_DETAILS where (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and buyer_id = :buyerId and RESCHEDULE IS NULL order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByBuyer(@Param("buyerId") String buyerId);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and ITEM = :itemCode and buyer_id = :buyerId and RESCHEDULE IS NULL order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    List<OpenPODetails> getOpenPoDetailsByBuyerWithItem(@Param("buyerId") String buyerId , @Param("itemCode") String itemCode);
    

    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'N' and VENDOR_ID =:vendorId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getRejectedOpenPoDetailsByDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorIds);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'N' and VENDOR_ID =:vendorId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getRejectedOpenPoDetailsByVendorId(@Param("vendorId") String vendorIds);
    
    
    
    

    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y' and VENDOR_ID =:vendorId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getAcceptedOpenPoDetailsByDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y'  and VENDOR_ID =:vendorId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getAcceptedOpenPoDetailsByVendorId(@Param("vendorId") String vendorId);
    
    
    
    
    
    @Query(value = "select count(*) from OPEN_PO_DETAILS where ACK = 'N' and VENDOR_ID =:vendorId", nativeQuery = true)
   	long getRejectedPoCountByVendorId(@Param("vendorId") String vendorIds);
    
    
    
    
    
    
    @Query(value = "select count(*) from OPEN_PO_DETAILS where ACK = 'Y'  and VENDOR_ID =:vendorId", nativeQuery = true)
   	long getAcceptedPoCountByVendorId(@Param("vendorId") String vendorId);
    
    
    
    
    
    @Query(value = "select count(*) from OPEN_PO_DETAILS where RESCHEDULE IS NULL AND (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and VENDOR_ID = :vendorId", nativeQuery = true)
    long getOpenPoCountByVendorId(@Param("vendorId") String vendorId);
    
    
    
    
    
    @Query(value = "select count(*) from OPEN_PO_DETAILS where (ACK IS NULL) and (IS_CHANGED IS NULL OR IS_CHANGED = 'N') and BUYER_APPROVAL IS NULL and BUYER_ID = :buyerId and RESCHEDULE IS NULL", nativeQuery = true)
    long getOpenPoCountByBuyerId(@Param("buyerId") String buyerId);
    
    
    
    
    
//    @Query(value = "select count(*) from OPEN_PO_DETAILS where (ACK IS NULL) and IS_CHANGED = 'Y' and BUYER_APPROVAL IS NULL and BUYER_ID = :buyerId", nativeQuery = true)
//    long getChangeRequestPoCountByBuyerId(@Param("buyerId") String buyerId);
    
    @Query(value = "select count(*) from OPEN_PO_DETAILS where ACK = 'N' and BUYER_ID = :buyerId", nativeQuery = true)
    long getRejectedPoCountByBuyerId(@Param("buyerId") String buyerId);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'N'  and BUYER_ID =:buyerId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getRejectedPoDetailsByBuyerId(@Param("buyerId") String buyerId);
    
    
    
    
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'N' and BUYER_ID =:buyerId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
   	List<OpenPODetails> getRejectedPoDetailsByDate(@Param("fromDate") String fromDate,@Param("toDate") String toDate ,@Param("buyerId") String buyerId);
    
    
    
    
    
    @Query(value = "select * from  OPEN_PO_DETAILS where HEADER_ID=:headerId AND PO_LINE_LOCATION_ID=:poLineLocationId order by PO_NUMBER DESC, PO_LINE_NUM ASC, SHIPMENT_NUM ASC", nativeQuery = true)
    OpenPODetails findPOByHeaderIdAndPoLineLocationId(@Param("headerId") long headerId,@Param("poLineLocationId") long poLineLocationId);
    
    
    
    
    
    @Query(value = "select * from  OPEN_PO_DETAILS where ASN=:asn", nativeQuery = true)
    List<OpenPODetails> findPOByASN(@Param("asn") String asn);
    
    
    
    
    
    
    
    @Query(value = "select * from  OPEN_PO_DETAILS where SCN=:scn", nativeQuery = true)
    List<OpenPODetails> findPOBySCN(@Param("scn") String scn);
    
    
    
    
    
    
    @Query(value = "select * from  OPEN_PO_DETAILS where PO_HEADER_ID=:poHeaderId", nativeQuery = true)
    List<OpenPODetails> findPOBYHeaderId(@Param("poHeaderId") Long poHeaderId);
    
    
    
    // get all services against a supplier
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y' AND IS_SERVICE = 'Y' AND VENDOR_ID =:vendorId AND PO_LINE_NUM = '1' ORDER BY SERVICE_HEADER_ID DESC", nativeQuery = true)
   	List<OpenPODetails> getAllServicesBySupplier(@Param("vendorId") Long vendorId);

    
    
    
    // get all services against a buyer
    @Query(value = "select * from OPEN_PO_DETAILS where SCN IS NOT NULL AND ACK = 'Y' AND IS_SERVICE = 'Y' AND BUYER_ID =:buyerId AND PO_LINE_NUM = '1' ORDER BY SERVICE_HEADER_ID DESC", nativeQuery = true)
   	List<OpenPODetails> getAllServicesByBuyer(@Param("buyerId") String buyerId);
    
    
    
    
    
    // get all services against a supplier
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y' AND IS_SERVICE = 'Y' AND SERVICE_HEADER_ID =:serviceHeaderId ORDER BY PO_LINE_NUM", nativeQuery = true)
   	List<OpenPODetails> getServiceLinesToView(@Param("serviceHeaderId") Long serviceHeaderId);

    
    
    
 // get all services against a supplier to move from portal to oracle
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y' AND PO_PROCESS_STATUS = 'I' AND IS_SERVICE = 'Y' order by PO_LINE_NUM, SHIPMENT_NUM", nativeQuery = true)
   	List<OpenPODetails> getAllServicesBySupplierToMove();
    
        
        
    
    @Query(value = "select * from  OPEN_PO_DETAILS where ID=:id", nativeQuery = true)
    OpenPODetails findByCustomId(@Param("id") long id);
    
    
    
    
    @Query(value = "select max(ID) from OPEN_PO_DETAILS", nativeQuery = true)
    Long findMaxId();
    
    
    
    
    @Query(value = "select max(SERVICE_HEADER_ID) from OPEN_PO_DETAILS", nativeQuery = true)
    Long findMaxServiceHeaderId();
    
    
    
    
    @Query(value = "select COUNT(SERVICE_HEADER_ID) from OPEN_PO_DETAILS WHERE SERVICE_HEADER_ID = :serviceHeaderId", nativeQuery = true)
    Long findServiceLinesCount(@Param("serviceHeaderId") Long serviceHeaderId);
    
    
    

    @Query(value = "select * from  OPEN_PO_DETAILS where SERVICE_HEADER_ID=:serviceHeaderId AND PO_LINE_NUM = '1'", nativeQuery = true)
    OpenPODetails findByServiceHeaderId(@Param("serviceHeaderId") long serviceHeaderId);
    
    
    
    
    
    
    
    @Query(value = "select * from  OPEN_PO_DETAILS where SERVICE_HEADER_ID=:serviceHeaderId order by PO_LINE_NUM", nativeQuery = true)
    List<OpenPODetails> findAllServiceByHeaderId(@Param("serviceHeaderId") long serviceHeaderId);
    
   // OpenPODetails findByHeaderIdAndPoLineLocationId(Integer headerId,Integer poLineLocationId);
    
}