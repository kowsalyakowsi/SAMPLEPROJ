package com.foucsr.supplierportal.mysql.database.repository;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.payload.VendorInvDOStatusResponse;

@Repository
public interface ShipMentStatusRepository extends CrudRepository<ShipMentStatus, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<ShipMentStatus> findAll();
    
    
    @Query(value = "select * from  SHIPMENT_STATUS where HEADER_ID=:headerId AND PO_LINE_LOCATION_ID=:poLineLocationId AND ASN =:asn order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    ShipMentStatus findByHeaderIdAndPoLineLocationId(@Param("headerId") long headerId,@Param("poLineLocationId") long poLineLocationId , @Param("asn") String asn);
    
    @Query(value = "select * from SHIPMENT_STATUS where LINE_TYPE != :lineType AND vendor_id = :vendorId order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusByVendorId(@Param("vendorId") String vendorId , @Param("lineType") String lineType  );
    
    @Query(value = "select * from SHIPMENT_STATUS where LINE_TYPE != :lineType AND VENDOR_ID =:vendorId and ASN_CREATION_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId , @Param("lineType") String lineType);
    
//    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE != :lineType AND VENDOR_ID =:vendorId and ASN =:asn and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
//    List<ShipMentStatus> getShipMentStatusByASNAndDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId, @Param("asn") String asn , @Param("lineType") String lineType );
    
//    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE != :lineType AND VENDOR_ID =:vendorId and ASN =:asn order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
//    List<ShipMentStatus> getShipMentStatusByASN(@Param("vendorId") String vendorId, @Param("asn") String asn , @Param("lineType") String lineType );

    
    @Query(value = "select * from  SHIPMENT_STATUS where ASN =:asn and PO_LINE_NUM = :poLineNo order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    ShipMentStatus findBySCNAndLineNo(@Param("poLineNo") long poLineNo , @Param("asn") String asn);
    
    
    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE = :lineType AND VENDOR_ID =:vendorId and ASN =:asn and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusBySCnAndDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId, @Param("asn") String asn , @Param("lineType") String lineType );
    
    
    
    @Query(value = "select * from SHIPMENT_STATUS where LINE_TYPE = :lineType AND VENDOR_ID =:vendorId and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusScnByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId, @Param("lineType") String lineType );
 
    
    
    
    
    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE = :lineType AND VENDOR_ID =:vendorId and ASN =:asn order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusBySCN(@Param("vendorId") String vendorId, @Param("asn") String asn , @Param("lineType") String lineType );
    
    
    
    
    @Query(value = "select * from SHIPMENT_STATUS where LINE_TYPE = :lineType AND vendor_id = :vendorId order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusSCNByVendorId(@Param("vendorId") String vendorId , @Param("lineType") String lineType );
    
    
    @Query(value = "select * from SHIPMENT_STATUS where  ASN =:asn order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusByOnlyASN(@Param("asn") String asn );
    
    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE != :lineType AND VENDOR_ID =:vendorId and DO_NUM =:do_num and ASN_CREATION_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusByASNAndDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId, @Param("do_num") String do_num , @Param("lineType") String lineType );
    
    
    @Query(value = "select * from SHIPMENT_STATUS where  LINE_TYPE != :lineType AND VENDOR_ID =:vendorId and DO_NUM =:do_num order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentStatus> getShipMentStatusByASN(@Param("vendorId") String vendorId, @Param("do_num") String do_num , @Param("lineType") String lineType );
    
    
    @Query(value = "select VENDOR_NAME , ASN , IS_INV_UPLOADED , IS_DO_DOC_UPLOADED , INV_UPLOAD_DATE , DO_UPLOAD_DATE from SHIPMENT_STATUS where ASN_CREATION_DATE between STR_TO_DATE(:p_from_date , '%Y-%M-%d') and STR_TO_DATE(:p_to_date , '%Y-%M-%d') "
    		+ " and IS_DO_DOC_UPLOADED = :is_do_upload and IS_INV_UPLOADED = :is_inv_upload group by VENDOR_NAME , ASN , IS_INV_UPLOADED , IS_DO_DOC_UPLOADED , INV_UPLOAD_DATE, DO_UPLOAD_DATE order by ASN DESC", nativeQuery = true)
    List<VendorInvDOStatusResponse> getVendorInvDOStatus(@Param("p_from_date") String p_from_date,@Param("p_to_date") String p_to_date , @Param("is_inv_upload") String is_inv_upload , @Param("is_do_upload") String is_do_upload );
    
    
    @Query(value = "select MIN(ASN_CREATION_DATE) from SHIPMENT_STATUS ", nativeQuery = true)
    Date getMinimumASNCreationDate();
    
    
    @Query(value = "select MAX(ASN_CREATION_DATE) from SHIPMENT_STATUS ", nativeQuery = true)
    Date getMaximumASNCreationDate();
    
    
}