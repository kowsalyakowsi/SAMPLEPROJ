package com.foucsr.supplierportal.mysql.database.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "DEBIT_INVOICES")
public class DebitNote {
	
	@Id	
	@SequenceGenerator(name="DEBIT_INVOICES_SEQ", sequenceName="DEBIT_INVOICES_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DEBIT_INVOICES_SEQ")	
	@Column(name = "DEBIT_INVOICE_ID")
	private Long id;
	
	@Column(name="INVOICE_NUMBER")
	private String invoiceNumber;	
	
	
	@Column(name="SUPPLIER_NAME")
	private String supplierName;
	
	@Column(name="SUPPLIER_SITE")
	private String supplierSite;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="INVOICE_DATE")
	private Date invoiceDate;
	
	@Column(name="INVOICE_AMOUNT")
	private Double invoiceAmount;	
	
	@Column(name="RTS_QUANTITY")
	private Double rtsQty;
	
	
	@Column(name="PO_NUMBER")
	private String poNumber;
	
	@Column(name="PO_ITEM_UOM")
	private String uom;
	
	@Column(name="PO_QUANTITY")
	private Double poQty;
	
	@Column(name="PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@Column(name="VENDOR_ID")
	private long vendorId;

	public DebitNote() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierSite() {
		return supplierSite;
	}

	public void setSupplierSite(String supplierSite) {
		this.supplierSite = supplierSite;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Double getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(Double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public Double getRtsQty() {
		return rtsQty;
	}

	public void setRtsQty(Double rtsQty) {
		this.rtsQty = rtsQty;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getPoQty() {
		return poQty;
	}

	public void setPoQty(Double poQty) {
		this.poQty = poQty;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}
	
}