package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.MasterItems;

@Repository
public interface MasterItemsRepository extends CrudRepository<MasterItems, Long> {
	   
	
    @Override
    Iterable<MasterItems> findAll();
    
    @Query(value = "select * from MASTER_ITEMS where END_DATE_ACTIVE IS NULL order by SEGMENT1 , DESCRIPTION", nativeQuery = true)
    List<MasterItems> findAllValid();

}