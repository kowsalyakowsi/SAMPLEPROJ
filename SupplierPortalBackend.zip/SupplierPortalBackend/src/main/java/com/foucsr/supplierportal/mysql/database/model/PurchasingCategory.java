package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PURCHASING_CATEGORIES")
public class PurchasingCategory {

	@Id
	@Column(name = "CATEGORY_ID")
	private Long category_id;
	
	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "SEGMENT1")
	private String segment1;
	
	@Column(name = "SEGMENT2")
	private String segment2;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE_ACTIVE")
	private Date end_date_active;

	@Column(name = "PO_PROCESS_STATUS")
	private String po_process_status;

	public Long getCategory_id() {
		return category_id;
	}

	public void setCategory_id(Long category_id) {
		this.category_id = category_id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getSegment2() {
		return segment2;
	}

	public void setSegment2(String segment2) {
		this.segment2 = segment2;
	}

	public Date getEnd_date_active() {
		return end_date_active;
	}

	public void setEnd_date_active(Date end_date_active) {
		this.end_date_active = end_date_active;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

	
}