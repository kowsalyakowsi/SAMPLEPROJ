package com.foucsr.supplierportal.oracle.database.repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.oracle.database.model.POAgentsOracle;
import com.foucsr.supplierportal.util.AppConstants;

@Component
public class POAgentsOracleRepository  {
	
	Logger log = LoggerFactory.getLogger(POAgentsOracleRepository.class);
	
//    @Query(value = "select * from XX_PO_AGENTS where PO_PROCESS_STATUS='I' OR PO_PROCESS_STATUS='U'", nativeQuery = true)
//    List<POAgentsOracle> findByFirstNameAndLastName();
//    
//    @Query(value = "select SYSDATE from  DUAL ", nativeQuery = true)
//    java.util.Date  findDateFromServer();
	
	public List<POAgentsOracle> findByFirstNameAndLastName() {

		RestTemplate restTemplate = new RestTemplate();

//		ResponseEntity<POAgentsOracle[]> response = restTemplate.getForEntity(
//				"http://192.168.1.37:8000//sap/bc/zapi_buyer?sap-client=200", POAgentsOracle[].class);
		
		String agentURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_buyer?sap-client=800";
		
		ResponseEntity<POAgentsOracle[]> response = restTemplate.getForEntity(
				agentURL , POAgentsOracle[].class);


		POAgentsOracle[] buyers = response.getBody();

		List<POAgentsOracle> buyerrList = Arrays.asList(buyers);
		
		if(buyerrList == null) {
			
			buyerrList = new ArrayList<POAgentsOracle>();
		}
		
		return buyerrList;
	}
	
	 public void ackAgentbySOAPService(List<PoAgents> savedAgentList) {
			
		    String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zser_buyer_ack/800/zser_buyer_ack/zbind1?sap-client=800";
			
			String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zser_buyer_ack/800/zser_buyer_ack/zbind1";
			
			
			try {
				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();

				// Send SOAP Message to SOAP Server
				SOAPMessage soapResponse = soapConnection.call(createAckAgentSOAPRequest(soapAction , savedAgentList), soapEndpointUrl);

				// Print the SOAP Response
//				System.out.println("Response SOAP Message:");
//				soapResponse.writeTo(System.out);
//				System.out.println();

				soapConnection.close();
			} catch (Exception e) {
				log.info("***************** Error occurred while sending ACK agent SOAP Request to Server!\\nMake sure you have the correct endpoint URL and SOAPAction!  *********************\n" + e);
			}
		}
	    
	    private SOAPMessage createAckAgentSOAPRequest(String soapAction , List<PoAgents> savedAgentList) throws Exception {
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();

			createAckAgentSoapEnvelope(soapMessage ,  savedAgentList);

			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", soapAction);
			
			String loginPassword = "developer:saphana2";
			
			soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


			soapMessage.saveChanges();

			/* Print the request message, just for debugging purposes */
//			System.out.println("Request SOAP Message:");
//			soapMessage.writeTo(System.out);
//			System.out.println("\n");

			return soapMessage;
		}

	    
	    private void createAckAgentSoapEnvelope(SOAPMessage soapMessage , List<PoAgents> savedAgentList) throws SOAPException {

			SOAPPart soapPart = soapMessage.getSOAPPart();
			String serverURI = "urn:sap-com:document:sap:rfc:functions";
			SOAPEnvelope envelope = soapPart.getEnvelope();

			envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

			SOAPBody soapBody = envelope.getBody();
			SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZVEN_BUYER_ACK", "urn", ""));
//			 bodyElement.addChildElement("INPUT").addTextNode("ACKOPENPO");
			 SOAPElement it_ven_element = bodyElement.addChildElement("IT_PORTAL");

			 addBuyerItems(it_ven_element ,  savedAgentList);
			 
			soapMessage.saveChanges();
		}

	    private void addBuyerItems(SOAPElement it_ven_element , List<PoAgents> savedAgentList) throws SOAPException {
	    	    	
	    	
	    	for(PoAgents agent : savedAgentList) {
	    		
	    		QName itemQ = new QName("item");
	    		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);
	    		
	    		itemQ = new QName("EKGRP");
	    		SOAPElement vendorIdElement = itemElement.addChildElement(itemQ);
	    		vendorIdElement.addTextNode(Long.toString(agent.getAgentId()));    	
	    		
	    		itemQ = new QName("PROCESSSTATUS");
	    		SOAPElement processStatus = itemElement.addChildElement(itemQ);
	    		processStatus.addTextNode(agent.getPoProcessStatus());
	    		
	    	}


		}

   
}