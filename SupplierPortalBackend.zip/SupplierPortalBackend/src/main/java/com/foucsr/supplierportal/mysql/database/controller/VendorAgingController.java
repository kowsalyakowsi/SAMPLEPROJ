package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.VendorAgingService;
import com.foucsr.supplierportal.payload.ReportFilterRequest;

@RestController
@RequestMapping("/VendorAging/Service")
@CrossOrigin
public class VendorAgingController {

	@Autowired
	private VendorAgingService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	@PostMapping("/getAgingReport")
	public ResponseEntity<?> getPaymentAdviceList(@Valid @RequestBody ReportFilterRequest byDateRequest,
			Principal principal) {
		
		ResponseEntity<?> message = projectService.getAgingReport(byDateRequest);
		
		return message;

	}
}
