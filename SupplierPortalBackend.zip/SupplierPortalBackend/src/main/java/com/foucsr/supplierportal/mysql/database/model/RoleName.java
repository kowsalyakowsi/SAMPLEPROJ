package com.foucsr.supplierportal.mysql.database.model;

/**
 * Created by FocusR on 07/12/17.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
    
}
