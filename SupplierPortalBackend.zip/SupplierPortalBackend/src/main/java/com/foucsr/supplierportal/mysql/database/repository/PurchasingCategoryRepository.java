package com.foucsr.supplierportal.mysql.database.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PurchasingCategory;

@Repository
public interface PurchasingCategoryRepository extends CrudRepository<PurchasingCategory, Long> {

	@Query(value = "select * from PURCHASING_CATEGORIES", nativeQuery = true)
	List<PurchasingCategory> findAllPurchasingCategories();

}