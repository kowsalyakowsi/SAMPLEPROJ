package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.PendingInvoice;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PendingInvoiceService;
import com.foucsr.supplierportal.payload.ReportFilterRequest;

@RestController
@RequestMapping("/PendingInvoice/Service")
@CrossOrigin
public class PendingInvoiceController {

	@Autowired
	private PendingInvoiceService pendingInvoiceService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	
	@PostMapping("/getPendingInvoiceByDate")
	public List<PendingInvoice> getPendingInvoicesByDate(@Valid @RequestBody ReportFilterRequest byDateRequest,
			Principal principal) {
		return pendingInvoiceService.getPendingInvoiceByDate(byDateRequest);

	}
	
	
	@GetMapping("/getOrgList")
	public ResponseEntity<?> getOrgList(@RequestParam String vendorID) {
		
		List<String> listOfOuName = pendingInvoiceService.getDistinctShipToOrg(vendorID);
		return new ResponseEntity<List<String>>(listOfOuName, HttpStatus.OK);
	}
	
}
