package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "RFQ_PRICE_BREAKS")
public class RFQPriceBreaks {

	@Id
	@SequenceGenerator(name = "RFQ_PRICE_BREAKS_SEQ", sequenceName = "RFQ_PRICE_BREAKS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RFQ_PRICE_BREAKS_SEQ")
	@Column(name = "RFQ_LINE_LOCATION_ID")
	private Long rfq_line_location_id;

	@Column(name = "RFQ_HEADER_ID")
	private Long rfq_header_id;

	@Column(name = "RFQ_LINE_ID")
	private Long rfq_line_id;

	@Column(name = "SHIPMENT_NUM")
	private long shipment_num;

	@Column(name = "QUANTITY")
	private double quantity;

	@Column(name = "UNIT_MEAS_LOOKUP_CODE")
	private String unit_meas_lookup_code;

	@Column(name = "SHIP_TO_LOCATION_ID")
	private long ship_to_location_id;

	@Column(name = "PRICE_OVERRIDE")
	private double price_override;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE")
	private Date start_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE")
	private Date end_date;

	@Column(name = "PRICE_DISCOUNT")
	private double price_discount;

	@Column(name = "SHIP_TO_ORGANIZATION_ID")
	private long ship_to_organization_id;

	@Column(name = "ORG_ID")
	private long org_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "USER_NAME")
	private String user_name;
	
	@Column(name = "ORGANIZATION")
	private String organization;
	
	@Column(name = "SHIP_TO_LOCATION")
	private String ship_to_location;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "RFQ_LINE_ID" , insertable = false, updatable = false)
	private RFQLines rfqLine;

	public RFQPriceBreaks() {

	}

	public Long getRfq_line_location_id() {
		return rfq_line_location_id;
	}

	public void setRfq_line_location_id(Long rfq_line_location_id) {
		this.rfq_line_location_id = rfq_line_location_id;
	}

	public Long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(Long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	public Long getRfq_line_id() {
		return rfq_line_id;
	}

	public void setRfq_line_id(Long rfq_line_id) {
		this.rfq_line_id = rfq_line_id;
	}

	public long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getUnit_meas_lookup_code() {
		return unit_meas_lookup_code;
	}

	public void setUnit_meas_lookup_code(String unit_meas_lookup_code) {
		this.unit_meas_lookup_code = unit_meas_lookup_code;
	}

	public long getShip_to_location_id() {
		return ship_to_location_id;
	}

	public void setShip_to_location_id(long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}

	public double getPrice_override() {
		return price_override;
	}

	public void setPrice_override(double price_override) {
		this.price_override = price_override;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public double getPrice_discount() {
		return price_discount;
	}

	public void setPrice_discount(double price_discount) {
		this.price_discount = price_discount;
	}

	public long getShip_to_organization_id() {
		return ship_to_organization_id;
	}

	public void setShip_to_organization_id(long ship_to_organization_id) {
		this.ship_to_organization_id = ship_to_organization_id;
	}

	public long getOrg_id() {
		return org_id;
	}

	public void setOrg_id(long org_id) {
		this.org_id = org_id;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Long getLast_update_login() {
		return last_update_login;
	}

	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	@JsonIgnore
	public RFQLines getRfqLine() {
		return rfqLine;
	}

	public void setRfqLine(RFQLines rfqLine) {
		this.rfqLine = rfqLine;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getShip_to_location() {
		return ship_to_location;
	}

	public void setShip_to_location(String ship_to_location) {
		this.ship_to_location = ship_to_location;
	}

}