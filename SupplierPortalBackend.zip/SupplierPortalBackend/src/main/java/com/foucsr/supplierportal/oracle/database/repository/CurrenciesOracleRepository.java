package com.foucsr.supplierportal.oracle.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.oracle.database.model.CurrenciesOracle;


@Repository
public interface CurrenciesOracleRepository extends CrudRepository<CurrenciesOracle, Long> {	  
	
    
//    @Query(value = "select * from XX_CURRENCIES where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<CurrenciesOracle> findByFirstNameAndLastName();

   
}