package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "CHANGE_REQUEST_DETAILS", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "po_line_location_id"
            })
    })
public class OpenPoChangeDetails {
	
	@Id
	@SequenceGenerator(name = "CHANGE_REQUEST_DETAILS_SEQ", sequenceName = "CHANGE_REQUEST_DETAILS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CHANGE_REQUEST_DETAILS_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name="OU_NAME")
	private String ou_name;
	
	@Column(name="PO_HEADER_ID")
	private Long po_header_id;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="PO_DATE")
	private Date po_date;
	
	@Column(name="PO_NUMBER")
	private String po_num;
	
	@Column(name="VENDOR_NAME")
	private String vendor_name;
	
	@Column(name="VENDOR_SITE_CODE")
	private String vendor_site_code;
	
	@Column(name="BUYER")
	private String buyer;
	
	@Column(name="BUYER_ID")
	private String buyer_id;
	
	@Column(name="PO_LINE_NUM")
	@JsonProperty("line_num")
	private Long po_line_num;
	
	@Column(name="ITEM")
	@JsonProperty("item_code")
	private String item;
	
	@Column(name="ITEM_DESCRIPTION")
	@JsonProperty("item_desc")
	private String item_description;
	
	@Column(name="PO_UOM")
	@JsonProperty("uom")
	private String po_uom;
	
	@Column(name="UNIT_PRICE")
	@JsonProperty("unit_price")
	private Double unit_price;
	
	@Column(name="QTY_ORDERED")
	@JsonProperty("ordered_qty")
	private Double qty_ordered;
	
	@Column(name="ORGANIZATION_NAME")
	@JsonProperty("org")
	private String organization_name;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("nbd")
	@Column(name="NEED_BY_DATE")
	private Date need_by_date;
	
	@Column(name="ACK")
	private String ack;
	
	@Column(name="RESCHEDULE")
	private String reschedule;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="RESCHEDULE_DATE")
	private Date reschedule_date;
	
	@Column(name="PROCESS_FLAG")
	private String process_flag;
	
	@Column(name="ASN")
	private String asn;
	
	@Column(name="SHIPMENT_NUM")
	private Long shipment_num;
	
	@Column(name="RECEIPT_CREATED_FLAG")
	private String receipt_created_flag;
	
	@Column(name="PO_LINE_ID")
	private Long po_line_id;
	
	@Column(name="PO_LINE_LOCATION_ID")
	@JsonProperty("po_line_location_id")
	private long poLineLocationId;
	
	@Column(name="RECEIPT_NUMBER")
	private Long receipt_number;
	
	@Column(name="VENDOR_ID")
	private Long vendor_id;
	
	@Column(name="SHIPMENT_QTY")
	private Double shipment_qty;
	
	@Column(name="RECEIVING_QUANTITY")
	private Double receiving_quantity;
	
	@Column(name="HEADER_ID")
	@JsonProperty("unique_id")
	private long headerId;

	@Column(name="PENDING_QTY")
	private Double pending_qty;
	
	@Column(name="BUYER_APPROVAL")
	private String buyer_approval;
	
	@Column(name="CHANGED_QTY")
	private Double changed_qty;
	
	@Column(name="NEW_QTY")
	private Double new_qty;
	
	@Column(name="RELEASE_ID")
	private Long release_id;
	
	@Column(name="RELEASE_NUMBER")
	private Long release_number;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="RELEASE_DATE")
	private Date release_date;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@Column(name = "IS_CHANGED")
	private String isChanged;
	 
	@Column(name = "IS_REJECTED")
	private String isRejected;
	
	@Column(name = "REASON_FOR_REJECTED")
	@Size(max = 2080)
	private String reaasonForRejected;
	
	@Column(name="SUPPLIER_CHANGE_PRICE")
	private Double supplierChangePrice;
	
	@Column(name="NBD")
	private String nBd;
	
	@Column(name="ORG")
	private String oRg;
	
	@Column(name="REVISION_NO")
	private Long revisionNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public Long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public Date getNeed_by_date() {
		return need_by_date;
	}

	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}

	public String getReschedule() {
		return reschedule;
	}

	public void setReschedule(String reschedule) {
		this.reschedule = reschedule;
	}

	public Date getReschedule_date() {
		return reschedule_date;
	}

	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}

	public String getProcess_flag() {
		return process_flag;
	}

	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}

	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public Long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public String getReceipt_created_flag() {
		return receipt_created_flag;
	}

	public void setReceipt_created_flag(String receipt_created_flag) {
		this.receipt_created_flag = receipt_created_flag;
	}

	public Long getPo_line_id() {
		return po_line_id;
	}

	public void setPo_line_id(Long po_line_id) {
		this.po_line_id = po_line_id;
	}

	public long getPoLineLocationId() {
		return poLineLocationId;
	}

	public void setPoLineLocationId(long poLineLocationId) {
		this.poLineLocationId = poLineLocationId;
	}

	public Long getReceipt_number() {
		return receipt_number;
	}

	public void setReceipt_number(Long receipt_number) {
		this.receipt_number = receipt_number;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Double getShipment_qty() {
		return shipment_qty;
	}

	public void setShipment_qty(Double shipment_qty) {
		this.shipment_qty = shipment_qty;
	}

	public Double getReceiving_quantity() {
		return receiving_quantity;
	}

	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}

	public long getHeaderId() {
		return headerId;
	}

	public void setHeaderId(long headerId) {
		this.headerId = headerId;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getBuyer_approval() {
		return buyer_approval;
	}

	public void setBuyer_approval(String buyer_approval) {
		this.buyer_approval = buyer_approval;
	}

	public Double getChanged_qty() {
		return changed_qty;
	}

	public void setChanged_qty(Double changed_qty) {
		this.changed_qty = changed_qty;
	}

	public Double getNew_qty() {
		return new_qty;
	}

	public void setNew_qty(Double new_qty) {
		this.new_qty = new_qty;
	}

	public Long getRelease_id() {
		return release_id;
	}

	public void setRelease_id(Long release_id) {
		this.release_id = release_id;
	}

	public Long getRelease_number() {
		return release_number;
	}

	public void setRelease_number(Long release_number) {
		this.release_number = release_number;
	}

	public Date getRelease_date() {
		return release_date;
	}

	public void setRelease_date(Date release_date) {
		this.release_date = release_date;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getIsChanged() {
		return isChanged;
	}

	public void setIsChanged(String isChanged) {
		this.isChanged = isChanged;
	}

	public String getIsRejected() {
		return isRejected;
	}

	public void setIsRejected(String isRejected) {
		this.isRejected = isRejected;
	}

	public String getReaasonForRejected() {
		return reaasonForRejected;
	}

	public void setReaasonForRejected(String reaasonForRejected) {
		this.reaasonForRejected = reaasonForRejected;
	}

	public Double getSupplierChangePrice() {
		return supplierChangePrice;
	}

	public void setSupplierChangePrice(Double supplierChangePrice) {
		this.supplierChangePrice = supplierChangePrice;
	}

	public String getnBd() {
		return nBd;
	}

	public void setnBd(String nBd) {
		this.nBd = nBd;
	}

	public String getoRg() {
		return oRg;
	}

	public void setoRg(String oRg) {
		this.oRg = oRg;
	}

	public Long getRevisionNo() {
		return revisionNo;
	}

	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}
	
	

}