package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.RegisteredListAndOUObjects;
import com.foucsr.supplierportal.mysql.database.model.SuppliersRegister;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.RegistrationService;
import com.foucsr.supplierportal.payload.SupplierCreationRequest;
import com.foucsr.supplierportal.payload.SupplierRegistrationRequest;

@RestController
@RequestMapping("/Registration/Service")
@CrossOrigin
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("/sendRegistrationRequest")
	public ResponseEntity<?> sendRegistrationRequest(@Valid @RequestBody List<SupplierRegistrationRequest> requests,
			Principal principal) {

		String res = registrationService.sendRegistrationRequest(requests);
		
		if("Success".equals(res)) {
			
			return new ResponseEntity<String>("Success", HttpStatus.OK);
			
		}  else if("Duplicate".equals(res)) {
			
			return new ResponseEntity<String>("DuplicateEmail", HttpStatus.BAD_REQUEST);
		}
		
		else {
			
			return new ResponseEntity<String>("BadRequest", HttpStatus.BAD_REQUEST);
		}

	}
	
	
	@GetMapping("/getAllRegisteredList")
	public RegisteredListAndOUObjects getAllRegisteredList(@RequestParam Map<String, String> requestParams,
			Principal principal) {

		Long buyerId = null;

		if (requestParams.get("buyerId") != null) {

			buyerId = Long.parseLong(requestParams.get("buyerId"));
		}

		return registrationService.getAllRegisterList(buyerId);

	}
	
	
	@PutMapping("/submitToCreateSupplier")
	public ResponseEntity<?> submitToCreateSupplier(@Valid @RequestBody List<SupplierCreationRequest> requests,
			Principal principal) {

		String message = registrationService.submitToCreateSupplier(requests);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	
	@PutMapping("/saveSiteOperatingUnit")
	public ResponseEntity<?> saveSiteOperatingUnit(@Valid @RequestBody SuppliersRegister request,
			Principal principal) {

		SuppliersRegister res = registrationService.saveSiteOperatingUnit(request);

		return new ResponseEntity<SuppliersRegister>(res, HttpStatus.CREATED);
	}

}
