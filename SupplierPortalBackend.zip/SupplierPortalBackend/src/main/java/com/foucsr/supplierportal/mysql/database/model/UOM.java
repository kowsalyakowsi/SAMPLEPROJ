package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "UNITS_OF_MEASURE")
public class UOM {

	@Id
	@SequenceGenerator(name = "UNITS_OF_MEASURE_SEQ", sequenceName = "UNITS_OF_MEASURE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "UNITS_OF_MEASURE_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "UNIT_OF_MEASURE")
	private String unit_of_measure;

	@Column(name = "UOM_CODE")
	private String uom_code;

	@Column(name = "UOM_CLASS")
	private String uom_class;

	@Column(name = "BASE_UOM_FLAG")
	private String base_uom_flag;

	@Column(name = "UNIT_OF_MEASURE_TL")
	private String unit_of_measure_tl;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "DISABLE_DATE")
	private Date disable_date;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "LANGUAGE")
	private String language;

	@Column(name = "SOURCE_LANG")
	private String source_lang;

	@Column(name = "PO_PROCESS_STATUS")
	private String poProcessStatus;

	public UOM() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUnit_of_measure() {
		return unit_of_measure;
	}

	public void setUnit_of_measure(String unit_of_measure) {
		this.unit_of_measure = unit_of_measure;
	}

	public String getUom_code() {
		return uom_code;
	}

	public void setUom_code(String uom_code) {
		this.uom_code = uom_code;
	}

	public String getUom_class() {
		return uom_class;
	}

	public void setUom_class(String uom_class) {
		this.uom_class = uom_class;
	}

	public String getBase_uom_flag() {
		return base_uom_flag;
	}

	public void setBase_uom_flag(String base_uom_flag) {
		this.base_uom_flag = base_uom_flag;
	}

	public String getUnit_of_measure_tl() {
		return unit_of_measure_tl;
	}

	public void setUnit_of_measure_tl(String unit_of_measure_tl) {
		this.unit_of_measure_tl = unit_of_measure_tl;
	}

	public Date getDisable_date() {
		return disable_date;
	}

	public void setDisable_date(Date disable_date) {
		this.disable_date = disable_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getSource_lang() {
		return source_lang;
	}

	public void setSource_lang(String source_lang) {
		this.source_lang = source_lang;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

}