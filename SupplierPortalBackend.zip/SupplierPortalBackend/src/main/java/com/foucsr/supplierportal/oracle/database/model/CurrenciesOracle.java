package com.foucsr.supplierportal.oracle.database.model;

public class CurrenciesOracle {

	private Long id;

	private String currency_code;
	
	private String po_process_status;

	public CurrenciesOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

	}