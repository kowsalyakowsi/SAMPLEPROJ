package com.foucsr.supplierportal.oracle.database.model;

public class PartialReceiptOracle {
	
	private Long id;
		
	private Long xx_shipment_id;
	
	private Long receipt_number;
	
	private Double receiving_quantity;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getXx_shipment_id() {
		return xx_shipment_id;
	}

	public void setXx_shipment_id(Long xx_shipment_id) {
		this.xx_shipment_id = xx_shipment_id;
	}

	public Long getReceipt_number() {
		return receipt_number;
	}

	public void setReceipt_number(Long receipt_number) {
		this.receipt_number = receipt_number;
	}

	public Double getReceiving_quantity() {
		return receiving_quantity;
	}

	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}
	
}