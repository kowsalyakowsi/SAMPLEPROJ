package com.foucsr.supplierportal.payload;


public class SupplierRegistrationRequest {

	private String email;

	private String supplierRegistrationUrl;
	
	private String token;
	
	private String user_name;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSupplierRegistrationUrl() {
		return supplierRegistrationUrl;
	}

	public void setSupplierRegistrationUrl(String supplierRegistrationUrl) {
		this.supplierRegistrationUrl = supplierRegistrationUrl;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

}
