package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "RFQ_HEADERS_ALL")
public class RFQHeader {

	@Id
	@SequenceGenerator(name = "RFQ_HEADERS_ALL_SEQ", sequenceName = "RFQ_HEADERS_ALL_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RFQ_HEADERS_ALL_SEQ")
	@Column(name = "RFQ_HEADER_ID")
	private Long rfq_header_id;

	@Column(name = "AGENT_ID")
	private long agent_id;
	
	
	@Column(name = "AGENT_NAME")
	private String agent_name;

	@Column(name = "RFQ_NUMBER")
	private String rfq_number;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "SHIP_TO_LOCATION_ID")
	private long ship_to_location_id;
	
	@Column(name = "SHIP_TO_LOCATION_CODE")
	private String ship_to_location_code;

	@Column(name = "BILL_TO_LOCATION_ID")
	private long bill_to_location_id;
	
	@Column(name = "BILL_TO_LOCATION_CODE")
	private String bill_to_location_code;

	@Column(name = "APPROVED_FLAG")
	private String approved_flag;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "RFQ_CLOSE_DATE")
	private Date rfq_close_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "APPROVED_DATE")
	private Date approved_date;

	@Column(name = "QUOTE_TYPE_LOOKUP_CODE")
	private String quote_type_lookup_code;

	@Column(name = "ORG_ID")
	private long org_id;
	
	@Column(name = "OPERATING_UNIT_NAME")
	private String operating_unit_name;

	@Column(name = "PURCHASE_BASIS")
	private String purchase_basis;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "USER_NAME")
	private String user_name;
	
	@Column(name = "INVENTORY_ORGANIZATION_ID")
	private Long inventory_organization_id;
	
	@OneToMany(cascade = CascadeType.REFRESH , mappedBy = "rfqHeader" )
	private List<RFQLines> rfqLines;
	
	@OneToMany(cascade = CascadeType.REFRESH , mappedBy = "rfqHeader" )
	private List<RFQVendors> rfqVendors;

	public RFQHeader() {

	}

	public Long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(Long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	public long getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(long agent_id) {
		this.agent_id = agent_id;
	}

	public String getRfq_number() {
		return rfq_number;
	}

	public void setRfq_number(String rfq_number) {
		this.rfq_number = rfq_number;
	}

	public long getShip_to_location_id() {
		return ship_to_location_id;
	}

	public void setShip_to_location_id(long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}

	public long getBill_to_location_id() {
		return bill_to_location_id;
	}

	public void setBill_to_location_id(long bill_to_location_id) {
		this.bill_to_location_id = bill_to_location_id;
	}

	public String getApproved_flag() {
		return approved_flag;
	}

	public void setApproved_flag(String approved_flag) {
		this.approved_flag = approved_flag;
	}

	public Date getRfq_close_date() {
		return rfq_close_date;
	}

	public void setRfq_close_date(Date rfq_close_date) {
		this.rfq_close_date = rfq_close_date;
	}

	public Date getApproved_date() {
		return approved_date;
	}

	public void setApproved_date(Date approved_date) {
		this.approved_date = approved_date;
	}

	public String getQuote_type_lookup_code() {
		return quote_type_lookup_code;
	}

	public void setQuote_type_lookup_code(String quote_type_lookup_code) {
		this.quote_type_lookup_code = quote_type_lookup_code;
	}

	public long getOrg_id() {
		return org_id;
	}

	public void setOrg_id(long org_id) {
		this.org_id = org_id;
	}

	public String getPurchase_basis() {
		return purchase_basis;
	}

	public void setPurchase_basis(String purchase_basis) {
		this.purchase_basis = purchase_basis;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Long getLast_update_login() {
		return last_update_login;
	}

	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	@JsonIgnore
	public List<RFQLines> getRfqLines() {
		return rfqLines;
	}

	public void setRfqLines(List<RFQLines> rfqLines) {
		this.rfqLines = rfqLines;
	}

	public String getAgent_name() {
		return agent_name;
	}

	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}

	public String getShip_to_location_code() {
		return ship_to_location_code;
	}

	public void setShip_to_location_code(String ship_to_location_code) {
		this.ship_to_location_code = ship_to_location_code;
	}

	public String getBill_to_location_code() {
		return bill_to_location_code;
	}

	public void setBill_to_location_code(String bill_to_location_code) {
		this.bill_to_location_code = bill_to_location_code;
	}

	public String getOperating_unit_name() {
		return operating_unit_name;
	}

	public void setOperating_unit_name(String operating_unit_name) {
		this.operating_unit_name = operating_unit_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public Long getInventory_organization_id() {
		return inventory_organization_id;
	}

	public void setInventory_organization_id(Long inventory_organization_id) {
		this.inventory_organization_id = inventory_organization_id;
	}

	@JsonIgnore
	public List<RFQVendors> getRfqVendors() {
		return rfqVendors;
	}

	public void setRfqVendors(List<RFQVendors> rfqVendors) {
		this.rfqVendors = rfqVendors;
	}

}