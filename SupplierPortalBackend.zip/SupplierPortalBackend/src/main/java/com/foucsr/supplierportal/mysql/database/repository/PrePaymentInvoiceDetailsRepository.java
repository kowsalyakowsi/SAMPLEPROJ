package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PrePaymentInvoice;

@Repository
public interface PrePaymentInvoiceDetailsRepository extends CrudRepository<PrePaymentInvoice, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<PrePaymentInvoice> findAll();
    
    @Query(value = "select * from PREPAYMENT_INVOICE where vendor_id = :vendorId order by INVOICE_NUMBER", nativeQuery = true)
    List<PrePaymentInvoice> getPrepaymentsByVendorId(@Param("vendorId") String vendorId );
    
    @Query(value = "select * from PREPAYMENT_INVOICE where  VENDOR_ID =:vendorId and INVOICE_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by INVOICE_NUMBER", nativeQuery = true)
    List<PrePaymentInvoice> getPrepaymentsByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId);
    

}