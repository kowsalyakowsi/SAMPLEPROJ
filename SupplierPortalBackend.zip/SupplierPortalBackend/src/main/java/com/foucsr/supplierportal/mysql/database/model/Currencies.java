package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CURRENCIES")
public class Currencies {
	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "CURRENCY_CODE")
	private String currency_code;

	@Column(name = "PO_PROCESS_STATUS")
	private String po_process_status;

	public Currencies() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

	}