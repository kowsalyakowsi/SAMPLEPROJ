package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PLANT_TBL")
public class PlantMysql {

	@Id	
	@Column(name = "PLANT")
	private String plant;
	
	@Column(name = "PLANT_DESP")
	private String plant_desp;
	
	@Column(name = "PSTAT")
	private String pstat;

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlant_desp() {
		return plant_desp;
	}

	public void setPlant_desp(String plant_desp) {
		this.plant_desp = plant_desp;
	}

	public String getPstat() {
		return pstat;
	}

	public void setPstat(String pstat) {
		this.pstat = pstat;
	}

	
			
}