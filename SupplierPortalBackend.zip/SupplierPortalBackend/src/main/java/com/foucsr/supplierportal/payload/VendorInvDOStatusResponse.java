package com.foucsr.supplierportal.payload;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public interface  VendorInvDOStatusResponse {

	 String getVENDOR_NAME();
	
     String getASN();
     
     String getIS_INV_UPLOADED();
     
     String getIS_DO_DOC_UPLOADED();
     
     @JsonFormat(pattern = "yyyy-MMM-dd")
     Date getINV_UPLOAD_DATE();
     
     @JsonFormat(pattern = "yyyy-MMM-dd")
     Date getDO_UPLOAD_DATE();
	

}