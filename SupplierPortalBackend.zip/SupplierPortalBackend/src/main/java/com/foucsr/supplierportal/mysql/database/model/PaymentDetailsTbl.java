package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PAYMENTS_DETAILS_TBL")
public class PaymentDetailsTbl {

	@Id
	// commented to fix ack service issue
//	@SequenceGenerator(name = "PAYMENTS_DETAILS_TBL_SEQ", sequenceName = "PAYMENTS_DETAILS_TBL_SEQ", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAYMENTS_DETAILS_TBL_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "ORG_ID")
	private String org_id;
	
	@Column(name = "INVOICE_PAYMENT_ID")
	private String invoice_payment_id;
	
	@Column(name = "PAYMENT_NUMBER")
	private long payment_number;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "PAYMENT_DATE")
	private Date payment_date;
	
	@Column(name = "CURRENCY_CODE")
	private String currency_code;
	
	@Column(name = "PAYMENT_AMOUNT")
	private Double payment_amount;
	
	@Column(name = "INVOICE_PAYMENT_TYPE")
	private String invoice_payment_type;
	
	@Column(name = "PAYMENT_METHODS")
	private String payment_methods;
	
	@Column(name = "BANK_ACCOUNT_NAME")
	private String bank_account_name;
	
	@Column(name = "BANK_ACCOUNT_NUM")
	private String bank_account_num;
	
	@Column(name = "INVOICE_ID")
	private String invoice_id;
	
	@Column(name = "AP_INV_NUMER")
	private String ap_inv_numer;
	
	@Column(name = "AP_INV_DATE")
	private Date ap_inv_date;
	
	@Column(name = "INVOICE_TYPE")
	private String invoice_type;
	
	@Column(name = "INVOICE_SOURCE")
	private String invoice_source;
	
	@Column(name = "LINE_DESCRIPTION")
	private String line_description;
	
	@Column(name = "PO_NUMBER")	
	private String po_number;
	
	@Column(name = "PAYMENT_STATUS")
	private String payment_status;
	
	@Column(name = "PERIOD_NAME")
	private String period_name;
	
	@Column(name = "LINE_TYPE_LOOKUP_CODE")
	private String line_type_lookup_code;
	
	@Column(name = "PO_HEADER_ID")
	private String po_header_id;
	
	@Column(name = "PO_LINE_ID")
	private String po_line_id;
	
	@Column(name = "PO_LINE_LOCATION_ID")
	private String po_line_location_id;
	
	@Column(name = "AP_DIST_CODE_COMBINATION")	
	private String ap_dist_code_combination;
	
	@Column(name = "GL_JE_HEADER_NAME")
	private String gl_je_header_name;
	
	@Column(name = "CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "AP_INV_DISTRIBUTION_AMOUNT")
	private Double ap_inv_distribution_amount;
	
	@Column(name = "VENDOR_ID")
	private long vendor_id;
	
	@Column(name = "PO_DATE")
	private Date po_date;
	
	@Column(name = "RECEIPT_NO")
	private String receipt_no;

	public long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public PaymentDetailsTbl() {

	}

	public PaymentDetailsTbl(Long id, String org_id, String invoice_payment_id, long payment_number,
			Date payment_date, String currency_code, Double payment_amount, String invoice_payment_type,
			String payment_methods, String bank_account_name, String bank_account_num, String invoice_id,
			String ap_inv_numer, Date ap_inv_date, String invoice_type, String invoice_source, String line_description,
			String po_number, String payment_status, String period_name, String line_type_lookup_code,
			String po_header_id, String po_line_id, String po_line_location_id, String ap_dist_code_combination,
			String gl_je_header_name, Date creation_date, Double ap_inv_distribution_amount,
			long vendor_id , Date po_date) {
		this.id = id;
		this.org_id = org_id;
		this.invoice_payment_id = invoice_payment_id;
		this.payment_number = payment_number;
		this.payment_date = payment_date;
		this.currency_code = currency_code;
		this.payment_amount = payment_amount;
		this.invoice_payment_type = invoice_payment_type;
		this.payment_methods = payment_methods;
		this.bank_account_name = bank_account_name;
		this.bank_account_num = bank_account_num;
		this.invoice_id = invoice_id;
		this.ap_inv_numer = ap_inv_numer;
		this.ap_inv_date = ap_inv_date;
		this.invoice_type = invoice_type;
		this.invoice_source = invoice_source;
		this.line_description = line_description;
		this.po_number = po_number;
		this.payment_status = payment_status;
		this.period_name = period_name;
		this.line_type_lookup_code = line_type_lookup_code;
		this.po_header_id = po_header_id;
		this.po_line_id = po_line_id;
		this.po_line_location_id = po_line_location_id;
		this.ap_dist_code_combination = ap_dist_code_combination;
		this.gl_je_header_name = gl_je_header_name;
		this.creation_date = creation_date;
		this.ap_inv_distribution_amount = ap_inv_distribution_amount;
		this.vendor_id  = vendor_id;
		this.po_date  = po_date;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrg_id() {
		return org_id;
	}

	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}

	public String getInvoice_payment_id() {
		return invoice_payment_id;
	}

	public void setInvoice_payment_id(String invoice_payment_id) {
		this.invoice_payment_id = invoice_payment_id;
	}

	public long getPayment_number() {
		return payment_number;
	}

	public void setPayment_number(long payment_number) {
		this.payment_number = payment_number;
	}

	public Date getPayment_date() {
		return payment_date;
	}

	public void setPayment_date(Date payment_date) {
		this.payment_date = payment_date;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public Double getPayment_amount() {
		return payment_amount;
	}

	public void setPayment_amount(Double payment_amount) {
		this.payment_amount = payment_amount;
	}

	public String getInvoice_payment_type() {
		return invoice_payment_type;
	}

	public void setInvoice_payment_type(String invoice_payment_type) {
		this.invoice_payment_type = invoice_payment_type;
	}

	public String getPayment_methods() {
		return payment_methods;
	}

	public void setPayment_methods(String payment_methods) {
		this.payment_methods = payment_methods;
	}

	public String getBank_account_name() {
		return bank_account_name;
	}

	public void setBank_account_name(String bank_account_name) {
		this.bank_account_name = bank_account_name;
	}

	public String getBank_account_num() {
		return bank_account_num;
	}

	public void setBank_account_num(String bank_account_num) {
		this.bank_account_num = bank_account_num;
	}

	public String getInvoice_id() {
		return invoice_id;
	}

	public void setInvoice_id(String invoice_id) {
		this.invoice_id = invoice_id;
	}

	public String getAp_inv_numer() {
		return ap_inv_numer;
	}

	public void setAp_inv_numer(String ap_inv_numer) {
		this.ap_inv_numer = ap_inv_numer;
	}

	public Date getAp_inv_date() {
		return ap_inv_date;
	}

	public void setAp_inv_date(Date ap_inv_date) {
		this.ap_inv_date = ap_inv_date;
	}

	public String getInvoice_type() {
		return invoice_type;
	}

	public void setInvoice_type(String invoice_type) {
		this.invoice_type = invoice_type;
	}

	public String getInvoice_source() {
		return invoice_source;
	}

	public void setInvoice_source(String invoice_source) {
		this.invoice_source = invoice_source;
	}

	public String getLine_description() {
		return line_description;
	}

	public void setLine_description(String line_description) {
		this.line_description = line_description;
	}

	public String getPo_number() {
		return po_number;
	}

	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public String getPeriod_name() {
		return period_name;
	}

	public void setPeriod_name(String period_name) {
		this.period_name = period_name;
	}

	public String getLine_type_lookup_code() {
		return line_type_lookup_code;
	}

	public void setLine_type_lookup_code(String line_type_lookup_code) {
		this.line_type_lookup_code = line_type_lookup_code;
	}

	public String getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(String po_header_id) {
		this.po_header_id = po_header_id;
	}

	public String getPo_line_id() {
		return po_line_id;
	}

	public void setPo_line_id(String po_line_id) {
		this.po_line_id = po_line_id;
	}

	public String getPo_line_location_id() {
		return po_line_location_id;
	}

	public void setPo_line_location_id(String po_line_location_id) {
		this.po_line_location_id = po_line_location_id;
	}

	public String getAp_dist_code_combination() {
		return ap_dist_code_combination;
	}

	public void setAp_dist_code_combination(String ap_dist_code_combination) {
		this.ap_dist_code_combination = ap_dist_code_combination;
	}

	public String getGl_je_header_name() {
		return gl_je_header_name;
	}

	public void setGl_je_header_name(String gl_je_header_name) {
		this.gl_je_header_name = gl_je_header_name;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public Double getAp_inv_distribution_amount() {
		return ap_inv_distribution_amount;
	}

	public void setAp_inv_distribution_amount(Double ap_inv_distribution_amount) {
		this.ap_inv_distribution_amount = ap_inv_distribution_amount;
	}

	public String getReceipt_no() {
		return receipt_no;
	}

	public void setReceipt_no(String receipt_no) {
		this.receipt_no = receipt_no;
	}
	
}