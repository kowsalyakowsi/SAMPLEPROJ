package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "INVOICE_DETAILS_TBL")
public class InvoiceDetailsTbl {

	@Id
	@SequenceGenerator(name = "INVOICE_DETAILS_TB_SEQ", sequenceName = "INVOICE_DETAILS_TB_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INVOICE_DETAILS_TB_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "ORG_ID")
	private Long org_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "GL_DATE")
	private Date gl_date;

	@Column(name = "PERIOD_NAME")
	private String period_name;

	@Column(name = "INVOICE_ID")
	private Long invoice_id;

	@Column(name = "AP_INV_NUMER")
	private String ap_inv_numer;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "AP_INV_DATE")
	private Date ap_inv_date;

	@Column(name = "INVOICE_TYPE")
	private String invoice_type;

	@Column(name = "INVOICE_SOURCE")
	private String invoice_source;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "INVOICE_CURRENCY_CODE")
	private String invoice_currency_code;

	@Column(name = "PO_NUMBER")
	private String po_number;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "PO_DATE")
	private Date po_date;

	@Column(name = "TRANSACTION_ID")
	private Long transaction_id;

	@Column(name = "RECEIPT_NUM")
	private String receipt_num;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "RECEIPT_DATE")
	private Date receipt_date;

	@Column(name = "VENDOR_ID")
	private Long vendor_id;

	@Column(name = "VENDOR_NAME")
	private String vendor_name;

	@Column(name = "AP_TERM_NAME")
	private String ap_term_name;

	@Column(name = "AP_INV_AMOUNT")
	private Double ap_inv_amount;

	@Column(name = "AP_INV_AMT_PAID")
	private Double ap_inv_amt_paid;

	@Column(name = "ACCTS_PAY_CODE_COMBINATION_ID")
	private Long accts_pay_code_combination_id;

	@Column(name = "AP_LINE_AMOUNT")
	private Double ap_line_amount;

	@Column(name = "AP_LINE_TYPE")
	private String ap_line_type;

	@Column(name = "LINE_DESCRIPTION")
	private String line_description;

	@Column(name = "INVENTORY_ITEM_ID")
	private Long inventory_item_id;

	@Column(name = "PO_HEADER_ID")
	private Long po_header_id;

	@Column(name = "PO_LINE_ID")
	private Long po_line_id;

	@Column(name = "PO_LINE_LOCATION_ID")
	private Long po_line_location_id;

	@Column(name = "AP_INV_DISTRIBUTION_AMT")
	private Double ap_inv_distribution_amt;

	@Column(name = "AP_INV_DIST_CODE_COMBIN")
	private String ap_inv_dist_code_combin;

	@Column(name = "OPERATING_UNITS")
	private String operating_units;

	@Column(name = "LEDGER_NAME")
	private String ledger_name;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;

	@Column(name = "BUYER_ID")
	private Long buyer_id;
	
	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;

	

	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getOrg_id() {
		return org_id;
	}



	public void setOrg_id(Long org_id) {
		this.org_id = org_id;
	}



	public Date getGl_date() {
		return gl_date;
	}



	public void setGl_date(Date gl_date) {
		this.gl_date = gl_date;
	}



	public String getPeriod_name() {
		return period_name;
	}



	public void setPeriod_name(String period_name) {
		this.period_name = period_name;
	}



	public Long getInvoice_id() {
		return invoice_id;
	}



	public void setInvoice_id(Long invoice_id) {
		this.invoice_id = invoice_id;
	}



	public String getAp_inv_numer() {
		return ap_inv_numer;
	}



	public void setAp_inv_numer(String ap_inv_numer) {
		this.ap_inv_numer = ap_inv_numer;
	}



	public Date getAp_inv_date() {
		return ap_inv_date;
	}



	public void setAp_inv_date(Date ap_inv_date) {
		this.ap_inv_date = ap_inv_date;
	}



	public String getInvoice_type() {
		return invoice_type;
	}



	public void setInvoice_type(String invoice_type) {
		this.invoice_type = invoice_type;
	}



	public String getInvoice_source() {
		return invoice_source;
	}



	public void setInvoice_source(String invoice_source) {
		this.invoice_source = invoice_source;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getInvoice_currency_code() {
		return invoice_currency_code;
	}



	public void setInvoice_currency_code(String invoice_currency_code) {
		this.invoice_currency_code = invoice_currency_code;
	}



	public String getPo_number() {
		return po_number;
	}



	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}



	public Date getPo_date() {
		return po_date;
	}



	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}



	public Long getTransaction_id() {
		return transaction_id;
	}



	public void setTransaction_id(Long transaction_id) {
		this.transaction_id = transaction_id;
	}



	public String getReceipt_num() {
		return receipt_num;
	}



	public void setReceipt_num(String receipt_num) {
		this.receipt_num = receipt_num;
	}



	public Date getReceipt_date() {
		return receipt_date;
	}



	public void setReceipt_date(Date receipt_date) {
		this.receipt_date = receipt_date;
	}



	public Long getVendor_id() {
		return vendor_id;
	}



	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}



	public String getVendor_name() {
		return vendor_name;
	}



	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}



	public String getAp_term_name() {
		return ap_term_name;
	}



	public void setAp_term_name(String ap_term_name) {
		this.ap_term_name = ap_term_name;
	}



	public Double getAp_inv_amount() {
		return ap_inv_amount;
	}



	public void setAp_inv_amount(Double ap_inv_amount) {
		this.ap_inv_amount = ap_inv_amount;
	}



	public Double getAp_inv_amt_paid() {
		return ap_inv_amt_paid;
	}



	public void setAp_inv_amt_paid(Double ap_inv_amt_paid) {
		this.ap_inv_amt_paid = ap_inv_amt_paid;
	}



	public Long getAccts_pay_code_combination_id() {
		return accts_pay_code_combination_id;
	}



	public void setAccts_pay_code_combination_id(Long accts_pay_code_combination_id) {
		this.accts_pay_code_combination_id = accts_pay_code_combination_id;
	}



	public Double getAp_line_amount() {
		return ap_line_amount;
	}



	public void setAp_line_amount(Double ap_line_amount) {
		this.ap_line_amount = ap_line_amount;
	}



	public String getAp_line_type() {
		return ap_line_type;
	}



	public void setAp_line_type(String ap_line_type) {
		this.ap_line_type = ap_line_type;
	}



	public String getLine_description() {
		return line_description;
	}



	public void setLine_description(String line_description) {
		this.line_description = line_description;
	}



	public Long getInventory_item_id() {
		return inventory_item_id;
	}



	public void setInventory_item_id(Long inventory_item_id) {
		this.inventory_item_id = inventory_item_id;
	}



	public Long getPo_header_id() {
		return po_header_id;
	}



	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}



	public Long getPo_line_id() {
		return po_line_id;
	}



	public void setPo_line_id(Long po_line_id) {
		this.po_line_id = po_line_id;
	}



	public Long getPo_line_location_id() {
		return po_line_location_id;
	}



	public void setPo_line_location_id(Long po_line_location_id) {
		this.po_line_location_id = po_line_location_id;
	}



	public Double getAp_inv_distribution_amt() {
		return ap_inv_distribution_amt;
	}



	public void setAp_inv_distribution_amt(Double ap_inv_distribution_amt) {
		this.ap_inv_distribution_amt = ap_inv_distribution_amt;
	}



	public String getAp_inv_dist_code_combin() {
		return ap_inv_dist_code_combin;
	}



	public void setAp_inv_dist_code_combin(String ap_inv_dist_code_combin) {
		this.ap_inv_dist_code_combin = ap_inv_dist_code_combin;
	}



	public String getOperating_units() {
		return operating_units;
	}



	public void setOperating_units(String operating_units) {
		this.operating_units = operating_units;
	}



	public String getLedger_name() {
		return ledger_name;
	}



	public void setLedger_name(String ledger_name) {
		this.ledger_name = ledger_name;
	}



	public Date getCreation_date() {
		return creation_date;
	}



	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}



	public Long getBuyer_id() {
		return buyer_id;
	}



	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}



	public String getProcessStatus() {
		return processStatus;
	}



	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}



	public InvoiceDetailsTbl() {
		
	}

	
}