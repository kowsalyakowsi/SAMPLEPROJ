package com.foucsr.supplierportal.mysql.database.controller;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;
import com.foucsr.supplierportal.mysql.database.model.POCountDetails;
import com.foucsr.supplierportal.mysql.database.model.POLineTypes;
import com.foucsr.supplierportal.mysql.database.model.ServiceRelatedObjects;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.OpenPODetailsService;
import com.foucsr.supplierportal.payload.AsnRequest;
import com.foucsr.supplierportal.payload.AsnResponse;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;
import com.foucsr.supplierportal.util.EmailHtmlLoader;

@RestController
@RequestMapping("/OpenPODetails/Service")
@CrossOrigin
public class OpenPODetailsController {
	
	Logger logger = LoggerFactory.getLogger(OpenPODetailsController.class);

	@Autowired
	private OpenPODetailsService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	@Autowired
	private EmailHtmlLoader emailHtmlSender;
	
	@Autowired
	ServletContext context;
	
	@PostMapping("/createServiceHeader")
	public ResponseEntity<?> createServiceHeader(@Valid @RequestBody OpenPODetails project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails list = projectService.saveServiceHeader(project);
		
		return new ResponseEntity<OpenPODetails>(list, HttpStatus.CREATED);
	}

	@PostMapping("/createServiceLine")
	public ResponseEntity<?> createNewService(@Valid @RequestBody OpenPODetails project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails savePO = projectService.saveServiceLine(project, principal.getName());
		
		return new ResponseEntity<OpenPODetails>(savePO, HttpStatus.CREATED);
	}

	@GetMapping("/{projectId}")
	public ResponseEntity<?> getProjectById(@PathVariable long projectId, Principal principal) {

		Optional<OpenPODetails> project = projectService.findProjectByIdentifier(projectId, principal.getName());
		List<Optional<OpenPODetails>> list = Arrays.asList(project);

		return new ResponseEntity<List<Optional<OpenPODetails>>>(list, HttpStatus.OK);
	}

	@GetMapping("/all")
	public List<OpenPODetails> getAllProjects(Principal principal) {
		
		return projectService.findAllProjects(principal.getName());
	}

	@DeleteMapping("/{projectId}")
	public ResponseEntity<?> deleteProject(@PathVariable long projectId, Principal principal) {
		projectService.deleteProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<String>("Project with ID: '" + projectId + "' was deleted", HttpStatus.OK);
	}

	@PostMapping("/getOpenPoByDate")
	public List<OpenPODetails> getOpenPoByDate(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		System.out.println(byDateRequest.getFromDate());
		System.out.println(byDateRequest.getToDate());
		return projectService.getOpenPoByDate(byDateRequest);

	}
	
	@PostMapping("/getOpenPoBuyer")
	public List<OpenPODetails> getOpenPoBuyer(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getOpenPoByDateBuyer(byDateRequest);

	}
	
	@PostMapping("/getOpenPoBuyerAck")
	public List<OpenPoChangeDetails> getOpenPoBuyerAck(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getOpenPoByDateBuyerAck(byDateRequest);

	}

	/*@PutMapping("/updateAcknowledge")
	public ResponseEntity<?> updateAcknowledge(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			BindingResult result, Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails project1 = projectService.updateAcknowledge(byDateRequest);
		List<OpenPODetails> list = Arrays.asList(project1);
		return new ResponseEntity<List<OpenPODetails>>(list, HttpStatus.CREATED);
	}*/

   @PutMapping("/updateAcknowledgeBySupplier")
    public ResponseEntity<?> updateAcknowledge(HttpServletRequest request , @Valid @RequestBody List<GetOpenPoByDateRequest> byDateRequest, BindingResult result, Principal principal){

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if(errorMap!=null) return errorMap;
        
        List<OpenPODetails> list = projectService.updateAcknowledge(byDateRequest ,  request);
//        List<OpenPODetails> list =  Arrays.asList(project1);
        return new ResponseEntity<List<OpenPODetails>>(list, HttpStatus.CREATED);
    }

   @PutMapping("/updateAcknowledgeByBuyer")
    public ResponseEntity<?> rejectPo(HttpServletRequest request , @Valid @RequestBody List<GetOpenPoByDateRequest> byDateRequest, BindingResult result, Principal principal){

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if(errorMap!=null) return errorMap;

        List<OpenPoChangeDetails> list = projectService.rejectPo(byDateRequest ,  request);
//        List<OpenPoChangeDetails> list =  Arrays.asList(project1);
        return new ResponseEntity<List<OpenPoChangeDetails>>(list, HttpStatus.CREATED);
    }

	@PutMapping("/changeRequestPo")
	public ResponseEntity<?> changeRequestPo(HttpServletRequest request , @Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			BindingResult result, Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails project1 = projectService.updateChangeRequestPo(byDateRequest ,  request);
		List<OpenPODetails> list = Arrays.asList(project1);
		return new ResponseEntity<List<OpenPODetails>>(list, HttpStatus.CREATED);
	}

	/*@PutMapping("/rejectPo")
	public ResponseEntity<?> rejectPo(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails project1 = projectService.rejectPo(byDateRequest);
		List<OpenPODetails> list = Arrays.asList(project1);
		return new ResponseEntity<List<OpenPODetails>>(list, HttpStatus.CREATED);
	}*/

	@GetMapping("/getDistinctOuName")
	public ResponseEntity<?> getDistinctOuName(@RequestParam String vendorID) {

		/*
		 * Optional<OpenPODetails> project =
		 * projectService.findProjectByIdentifier(projectId, principal.getName());
		 * List<Optional<OpenPODetails>> list = Arrays.asList(project);
		 */
		List<String> listOfOuName = projectService.getDistinctOuName(vendorID);
		return new ResponseEntity<List<String>>(listOfOuName, HttpStatus.OK);
	}

	@PostMapping("/searchByPoNumber")
	public List<OpenPODetails> searchByPoNumber(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {

		return projectService.searchByPoNumber(byDateRequest);

	}

	@PostMapping("/generateAsnNumber")
	public ResponseEntity<?> generateAsnNumber(@Valid @RequestBody List<AsnRequest> asnRequest,
			BindingResult result, Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		ResponseEntity<?> asnResponse = projectService.generateAsnNumber(asnRequest);
		
		return asnResponse;

//		return new ResponseEntity<AsnResponse>(asnResponse, HttpStatus.CREATED);
	}
	
	@PostMapping("/getRejectedPo")
	public List<OpenPODetails> getRejectedPOSupplier(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getRejectedPoByDate(byDateRequest);

	}
	
	@PostMapping("/getAcceptedPoSupplier")
	public List<OpenPODetails> getAcceptedPOSupplier(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getAcceptedPoByDateSupplier(byDateRequest);

	}
	
	@PostMapping("/getChangedPoSupplier")
	public List<OpenPoChangeDetails> getChangedPOSupplier(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getChangedPoByDateSupplier(byDateRequest);

	}
	
	@PostMapping("/getPoCountSupplier")
	public POCountDetails getPOCountSupplier(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getPoCountBySupplier(byDateRequest);

	}
	
	@PostMapping("/getPoCountBuyer")
	public POCountDetails getPoCountBuyer(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getPoCountByBuyer(byDateRequest);

	}
	
	@PostMapping("/invoiceUpload")
	public ResponseEntity<?> invoiceUpload(HttpServletRequest request , @RequestParam("file") MultipartFile file, @RequestParam Map<String, String> requestParams) {
		
		    String asn = requestParams.get("asn") != null ? requestParams.get("asn") : null;
		    
		    String scn =  requestParams.get("scn") != null ? requestParams.get("scn") : null;
		    
		    Long asnLong = Long.valueOf(asn != null ? asn : scn);
		    
		    // to handle SAP side added prefix zero and INV for for invoice and DO for do doc 
		    String formattedASN = String.format("%010d", asnLong);		    
		    formattedASN = "INV-" + formattedASN;

			File uploadFile = null;
			
			String orgName = "";

			try {

//				String uploadsDir = "/uploads/";

//				String realPathtoUploads = context.getRealPath(uploadsDir);
//				String realPathtoUploads = "F://Development/";
				String realPathtoUploads = "K://supplier/";
				

				if (!new File(realPathtoUploads).exists()) {
					new File(realPathtoUploads).mkdir();
				}

				orgName = file.getOriginalFilename();
				int startIndex = orgName.lastIndexOf(".");
				String fileFormatStr = orgName.substring(startIndex);
//				orgName = asn != null ? asn + fileFormatStr : scn + fileFormatStr ;
				orgName = formattedASN + fileFormatStr ;
				
				String filePath = realPathtoUploads + orgName;
				uploadFile = new File(filePath);
				file.transferTo(uploadFile);
				
                ResponseEntity<?> resp = projectService.updateINVUploadToShipment(asn);
				
				HttpStatus statusCode = resp.getStatusCode();

 				if (statusCode != HttpStatus.OK) {
 					
 					return resp;

 				}

			} catch (IllegalStateException | IOException e) {
				logger.info("***************** Invoice write error  *********************\n" + e);
				return new ResponseEntity<String>("File: '" + file.getOriginalFilename() + "' was unable to write",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

			logger.info("***************** Upload file path  *********************\n" + uploadFile.getAbsolutePath());

//			projectService.sendUploadedInvoice(asn, uploadFile , scn , orgName ,  request);
			
		
		return new ResponseEntity<String>("File: '" + file.getOriginalFilename() + "' was uploaded", HttpStatus.OK);
	}
	
	
	@PutMapping("/sendReminder")
	public ResponseEntity<?> sendReminder(HttpServletRequest request , @Valid @RequestBody List<OpenPODetails> openPOS, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		projectService.sendReminder(openPOS , 'R' ,  request);

		return new ResponseEntity<String>("Notification sent", HttpStatus.OK);
	}
	
	 @PutMapping("/updateRejectionByBuyer")
	    public ResponseEntity<?> updateRejectionByBuyer(HttpServletRequest request , @Valid @RequestBody List<GetOpenPoByDateRequest> byDateRequest, BindingResult result, Principal principal){

	        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
	        if(errorMap!=null) return errorMap;

	        List<OpenPODetails> list = projectService.updateRejectionByBuyer(byDateRequest ,  request);

	        return new ResponseEntity<List<OpenPODetails>>(list, HttpStatus.CREATED);
	    }
	
	 
	@GetMapping("/getServiceCreationObjects")
	public ResponseEntity<?> getServiceObjects(@RequestParam Map<String, String> requestParams, Principal principal) {		
				
		Long vendorId = Long.parseLong(requestParams.get("vendorId"));

		ServiceRelatedObjects rfqObj = projectService.getAllServiceRelatedObjects(vendorId);

		return new ResponseEntity<ServiceRelatedObjects>(rfqObj, HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllServices")
	public List<OpenPODetails> getAllServices(@RequestParam Map<String, String> requestParams, Principal principal) {
		
		Long vendorId = null;
		
		Long buyerId = null;
		
		if(requestParams.get("vendorId") != null) {
			
			 vendorId = Long.parseLong(requestParams.get("vendorId"));
		}
		
		if(requestParams.get("buyerId") != null) {			
			
			buyerId = Long.parseLong(requestParams.get("buyerId"));
		}
		
		
		return projectService.getAllServices(vendorId , buyerId);

	}
	
	
	@GetMapping("/viewService")
	public List<OpenPODetails> viewService(@RequestParam Map<String, String> requestParams, Principal principal) {
		
		Long serviceHeaderId = Long.parseLong(requestParams.get("serviceHeaderId"));					
		
		return projectService.getServiceLinesToView(serviceHeaderId);

	}
	
	
	@PostMapping("/generateScnNumber")
	public ResponseEntity<?> generateScnNumber(@Valid @RequestBody List<AsnRequest> asnRequest,
			BindingResult result, Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		AsnResponse asnResponse = projectService.generateScnNumber(asnRequest);

		return new ResponseEntity<AsnResponse>(asnResponse, HttpStatus.CREATED);
	}
	
	
	@GetMapping("/getAsnFilterList")
	public ResponseEntity<?> getAsnFilterList(Principal principal) {

		List<POLineTypes> list = projectService.getAsnFilterList();

		return new ResponseEntity<List<POLineTypes>>(list, HttpStatus.OK);
	}
	
	@PutMapping("/updateHeaderServiceByByer")
	public ResponseEntity<?> updateHeaderServiceByByer(@Valid @RequestBody OpenPODetails openPO, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails updatedPO = projectService.updateHeaderServiceByByer(openPO);

		return new ResponseEntity<OpenPODetails>(updatedPO, HttpStatus.CREATED);
	}
	
	@PutMapping("/updateServiceLineByByer")
	public ResponseEntity<?> updateServiceLineByByer(@Valid @RequestBody OpenPODetails openPO, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		OpenPODetails updatedPO = projectService.updateServiceLineByByer(openPO);

		return new ResponseEntity<OpenPODetails>(updatedPO, HttpStatus.CREATED);
	}
	 
	
	@PutMapping("/submitRequisitionByByer")
	public ResponseEntity<?> submitRequisitionByByer(@RequestParam Map<String, String> requestParams, 
			Principal principal) {

		
		Long serviceHeaderId = Long.parseLong(requestParams.get("serviceHeaderId"));

		projectService.submitRequisitionByByer(serviceHeaderId);

		return new ResponseEntity<String>("Submitted", HttpStatus.OK);
	}
	
	@PutMapping("/generateScnWithoutPO")
	public ResponseEntity<?> generateScnWithoutPO(HttpServletRequest request , @RequestParam Map<String, String> requestParams, Principal principal) {

		
		Long serviceHeaderId = Long.parseLong(requestParams.get("serviceHeaderId"));

		AsnResponse asnResponse = projectService.generateScnNumberWithoutPO(serviceHeaderId ,  request);

		return new ResponseEntity<AsnResponse>(asnResponse, HttpStatus.CREATED);
	}
	
//	@GetMapping("/test")
//	public String getTest(Principal principal) {
//		
//		return projectService.callInvoiceAttachmentProc("10145.pdf","10145");
//	}
	
//	@PostMapping("/getOpenPoByDateBuyer")
//	public List<OpenPODetails> getOpenPoByDate(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
//			Principal principal) {
//		return projectService.getOpenPoByDate(byDateRequest);
//
//	}

	
/*	@PostMapping("/doDOcUpload")
	public ResponseEntity<?> doDOcUpload(HttpServletRequest request , @RequestParam("file") MultipartFile file, @RequestParam Map<String, String> requestParams) {
		
		  
		    String asn = requestParams.get("asn") ;
		    
		    Long asnLong = Long.valueOf(asn);
		    
		    // to handle SAP side added prefix zero and INV for for invoice and DO for do doc 
		    String formattedASN = String.format("%010d", asnLong );		    
		    formattedASN = "DO-" + formattedASN;

			File uploadFile = null;
			
			String orgName = "";

			try {

//				String uploadsDir = "/uploads/";

//				String realPathtoUploads = context.getRealPath(uploadsDir);
				
//				String realPathtoUploads = "F://Development/";
				
				String realPathtoUploads = "K://supplier/";

				if (!new File(realPathtoUploads).exists()) {
					new File(realPathtoUploads).mkdir();
				}

				orgName = file.getOriginalFilename();
				int startIndex = orgName.lastIndexOf(".");
				String fileFormatStr = orgName.substring(startIndex);
				// do word added to identify the difference between invoice docs and do docs 
				orgName = formattedASN + fileFormatStr ;
				String filePath = realPathtoUploads + orgName;
				uploadFile = new File(filePath);
				file.transferTo(uploadFile);
				
				ResponseEntity<?> resp = projectService.updateDOUploadToShipment(asn , true);
				
				HttpStatus statusCode = resp.getStatusCode();

 				if (statusCode != HttpStatus.OK) {
 					
 					return resp;

 				}
 				

			} catch (IllegalStateException | IOException e) {
				logger.info("***************** Invoice write error  *********************\n" + e);
				return new ResponseEntity<String>("File: '" + file.getOriginalFilename() + "' was unable to write",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

			logger.info("***************** Upload file path  *********************\n" + uploadFile.getAbsolutePath());
		
		return new ResponseEntity<String>("File: '" + file.getOriginalFilename() + "' was uploaded", HttpStatus.OK);
	}*/

}

