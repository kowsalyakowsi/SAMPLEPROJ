package com.foucsr.supplierportal.payload;

public class AsnUploadRequest {
   
	private String asn_no;

	public String getAsn_no() {
		return asn_no;
	}

	public void setAsn_no(String asn_no) {
		this.asn_no = asn_no;
	}
	
	
	
	
}