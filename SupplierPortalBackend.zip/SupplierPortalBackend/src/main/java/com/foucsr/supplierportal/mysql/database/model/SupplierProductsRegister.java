package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SUPPLIER_PRODUCTS_REGISTER")

public class SupplierProductsRegister {

	@Id
	@SequenceGenerator(name = "SUPPLIER_PRODUCTS_REGISTER_SEQ", sequenceName = "SUPPLIER_PRODUCTS_REGISTER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SUPPLIER_PRODUCTS_REGISTER_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name="INVENTORY_ITEM_ID")
	private Long inv_item_id;		
	
	@Column(name="ORGANIZATION_ID")
	private Long organization_id;
	
	@Column(name="DESCRIPTION")
	private String description;	
	
	@Column(name="SEGMENT1")
	private String segment1;
	
	@Column(name="HSN_CODE")
	private String hsn_code;

	@Column(name="PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@Column(name = "SUPPLIER_REGISTER_ID")
	private Long supplier_register_id;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "SUPPLIER_REGISTER_ID" , insertable = false, updatable = false)
	private SuppliersRegister supplierRegistration;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getInv_item_id() {
		return inv_item_id;
	}

	public void setInv_item_id(Long inv_item_id) {
		this.inv_item_id = inv_item_id;
	}

	public Long getOrganization_id() {
		return organization_id;
	}

	public void setOrganization_id(Long organization_id) {
		this.organization_id = organization_id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public Long getSupplier_register_id() {
		return supplier_register_id;
	}

	public void setSupplier_register_id(Long supplier_register_id) {
		this.supplier_register_id = supplier_register_id;
	}

	@JsonIgnore
	public SuppliersRegister getSupplierRegistration() {
		return supplierRegistration;
	}

	public void setSupplierRegistration(SuppliersRegister supplierRegistration) {
		this.supplierRegistration = supplierRegistration;
	}

	public String getHsn_code() {
		return hsn_code;
	}

	public void setHsn_code(String hsn_code) {
		this.hsn_code = hsn_code;
	}
		
}