package com.foucsr.supplierportal.mysql.database.model;

import java.util.List;

public class RegisteredListAndOUObjects {

	private List<SuppliersRegister> suppliers;
	
	private List<OperatingUnits> operatingUnits;

	public List<SuppliersRegister> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<SuppliersRegister> suppliers) {
		this.suppliers = suppliers;
	}

	public List<OperatingUnits> getOperatingUnits() {
		return operatingUnits;
	}

	public void setOperatingUnits(List<OperatingUnits> operatingUnits) {
		this.operatingUnits = operatingUnits;
	} 

	}
