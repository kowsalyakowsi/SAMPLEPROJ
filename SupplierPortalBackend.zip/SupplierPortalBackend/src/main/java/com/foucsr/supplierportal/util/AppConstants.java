package com.foucsr.supplierportal.util;

public interface AppConstants {
    String DEFAULT_PAGE_NUMBER = "0";
    String DEFAULT_PAGE_SIZE = "30";

    int MAX_PAGE_SIZE = 50;
    
    long ASN_ID = 1;       
    
    String forgetPasswordSubject = "Password change Link";
    
    String supplierRegistrationSubject = "Supplier Registration Link";
    
    String supplierRegistrationSubbmitSubject = "Supplier Registration Submitted";
    
    String forgetPasswordText = "To reset your password, click the link below.\n"
    		                     + "This change password link will become invalid after 7 days.\n\n";
    
    String forgetPasswordTemplate = "email/forgetpassword_template";
    
    String supplierAckSubject = "PO Acknowledgement from ???";
    
    String supplierRejectionSubject = "PO Rejection details from ???";
    
    String supplierChangeReqSubject = "PO Change request from ???";
    
    String supplierAckReplaceText = "has acknowledged the below purchase detail(s).";
    
    String supplierRejectionReplaceText = "has rejected the below purchase detail(s).";
    
    String newPOText = "has sent the below new purchase detail(s).";
    
    String reminderPOText = "has sent reminder against the below purchase detail(s).";
    
    String rejectionActionText = "has sent again to acknowledge the below purchase detail(s).";
    
    String buyerAckSubject = "Buyer Acceptance against the change PO";
    
    String buyerReminderSubject = "Reminder for PO";
    
    String buyerActionAginstRejectoionSubject = "Buyer action against rejection";
    
    String buyerNewPOSubject = "New PO";
    
    String buyerRejectSubject = "Buyer rejection against the change PO";
    
    String buyerASNUploadSubject = "PO Shipment details from ???";
    
    String  supplierChangeReqText= "has changed the below purchase detail(s).";
    
    String  buyerChangeReqAccptText= "has accepted the below change PO detail(s).";
    
    String  buyerChangeReqRejectText= "has rejected the below change PO detail(s).";
    
    String  buyerASNUploadText= "has shipped the below PO detail(s).\n"
    		+ "Please find the attached invoice.";
    
    String supplierBodyContent = "<!DOCTYPE html>\n" + 
    		"<html>\n" + 
    		"<head>\n" + 
    		"<style>\n" + 
    		"table {\n" + 
    		"  font-family: arial, sans-serif;\n" + 
    		"  border-collapse: collapse;\n" + 
    		"  width: 100%;\n" + 
    		"}\n" + 
    		"\n" + 
    		"td, th {\n" + 
    		"  border: 1px solid #dddddd;\n" + 
    		"  text-align: left;\n" + 
    		"  padding: 8px;\n" + 
    		"}\n" + 
    		"\n" + 
    		"tr:nth-child(even) {\n" + 
    		"  background-color: #dddddd;\n" + 
    		"}\n" + 
    		"</style>\n" + 
    		"</head>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h3 style=\" color: #7c795d; font-family: 'Trocchi', serif; font-size: 30px; font-weight: normal; line-height: 48px; margin: 0;\">?supplier_ack</h3>\n" + 
    		"\n" + 
    		"<table>\n" + 
    		"  <tr>\n" + 
    		"    <th>PoNo </th>\n" + 
    		"    <th>Line&Shipment </th>\n" + 
    		"    <th>ItemCode</th>\n" + 
    		"    <th>ItemDescription</th>\n" +
    		"    <th>Qty/Amount</th>\n" + 
    		"    <th>Price </th>\n" + 
    		"  </tr>";
    
    String supplierBottomContent  = "</table>\n" + 
    		"\n" + 
    		"</body>\n" + 
    		"</html>\n";
    
    String supplierChangeReqContent = "<!DOCTYPE html>\n" + 
    		"<html>\n" + 
    		"<head>\n" + 
    		"<style>\n" + 
    		"table {\n" + 
    		"  font-family: arial, sans-serif;\n" + 
    		"  border-collapse: collapse;\n" + 
    		"  width: 100%;\n" + 
    		"}\n" + 
    		"\n" + 
    		"td, th {\n" + 
    		"  border: 1px solid #dddddd;\n" + 
    		"  text-align: left;\n" + 
    		"  padding: 8px;\n" + 
    		"}\n" + 
    		"\n" + 
    		"tr:nth-child(even) {\n" + 
    		"  background-color: #dddddd;\n" + 
    		"}\n" + 
    		"</style>\n" + 
    		"</head>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h3 style=\" color: #7c795d; font-family: 'Trocchi', serif; font-size: 30px; font-weight: normal; line-height: 48px; margin: 0;\">?replace_text </h3>\n" + 
    		"\n" + 
    		"<table>\n" + 
    		"  <tr>\n" + 
    		"    <th>PoNo </th>\n" + 
    		"    <th>ShipmentNo </th>\n" + 
    		"    <th>ItemCode  </th>\n" + 
    		"    <th>ItemDescription         </th>\n" +
    		"    <th>Ordered Qty</th>\n" + 
    		"    <th>Price </th>\n" + 
    		"    <th>NeedByDate </th>\n" + 
    		"    <th>ChangedQty </th>\n" +
    		"    <th>ChangedPrice </th>\n" + 
    		"    <th>RescheduleDate</th>\n" + 
    		"  </tr>";

    String Success_Message = "Success";
    
    String buyerRFQSubject = "RFQ from ??";
    
    String quotationSubject = "Quotation from ??";

    String  buyerRFQText= "has sent the below RFQ detail(s).\n";
    
    String  quotationText= "has sent the below Quotation detail(s).\n";
    
    String rfqBuyerBodyContent = "<!DOCTYPE html>\n" + 
    		"<html>\n" + 
    		"<head>\n" + 
    		"<style>\n" + 
    		"table {\n" + 
    		"  font-family: arial, sans-serif;\n" + 
    		"  border-collapse: collapse;\n" + 
    		"  width: 100%;\n" + 
    		"}\n" + 
    		"\n" + 
    		"td, th {\n" + 
    		"  border: 1px solid #dddddd;\n" + 
    		"  text-align: left;\n" + 
    		"  padding: 8px;\n" + 
    		"}\n" + 
    		"\n" + 
    		"tr:nth-child(even) {\n" + 
    		"  background-color: #dddddd;\n" + 
    		"}\n" + 
    		"</style>\n" + 
    		"</head>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h3 style=\" color: #7c795d; font-family: 'Trocchi', serif; font-size: 30px; font-weight: normal; line-height: 48px; margin: 0;\">?buyer_rfq</h3>\n" + 
    		"\n" + 
    		"<table>\n" + 
    		"  <tr>\n" + 
    		"    <th>RFQNo </th>\n" + 
    		"    <th>BuyerName</th>\n" + 
    		"    <th>UserName</th>\n" +
    		"    <th>Item </th>\n" +
    		"    <th>ItemDescription</th>\n" +
    		"    <th>Qty</th>\n" + 
    		"    <th>Price </th>\n" + 
    		"    <th>Discount</th>\n" +
    		"    <th>RFQClosingDate</th>\n" +
    		"    <th>Organization</th>\n" +
    		"    <th>ShipToLocation</th>\n" +
    		"  </tr>";    
        
    
    String quotationBodyContent = "<!DOCTYPE html>\n" + 
    		"<html>\n" + 
    		"<head>\n" + 
    		"<style>\n" + 
    		"table {\n" + 
    		"  font-family: arial, sans-serif;\n" + 
    		"  border-collapse: collapse;\n" + 
    		"  width: 100%;\n" + 
    		"}\n" + 
    		"\n" + 
    		"td, th {\n" + 
    		"  border: 1px solid #dddddd;\n" + 
    		"  text-align: left;\n" + 
    		"  padding: 8px;\n" + 
    		"}\n" + 
    		"\n" + 
    		"tr:nth-child(even) {\n" + 
    		"  background-color: #dddddd;\n" + 
    		"}\n" + 
    		"</style>\n" + 
    		"</head>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h3 style=\" color: #7c795d; font-family: 'Trocchi', serif; font-size: 30px; font-weight: normal; line-height: 48px; margin: 0;\">?vendor_quotation</h3>\n" + 
    		"\n" + 
    		"<table>\n" + 
    		"  <tr>\n" + 
    		"    <th>RFQNo </th>\n" + 
    		"    <th>Item </th>\n" +
    		"    <th>ItemDescription</th>\n" +
    		"    <th>PricePerUnit</th>\n" +
    		"    <th>FreightCharge</th>\n" +
    		"    <th>FromQty</th>\n" + 
    		"    <th>ToQty</th>\n" +
    		"    <th>Discount(%)</th>\n" +
    		"  </tr>";
    
    String rfq_Active_Status = "Active";

    String RFQ_IN_PROCESS = "In Process";
    
    String LInE_TYPE_FIXEDPRICE = "Fixed Price Services";
    
    String LINE_TYPE_GOODS = "Goods";
    
    String LINE_TYPE_AMOUNT_BASED = "Amount Based";
    
    String INTERFACE_SOURCE_CODE = "IMPORT_EXP";
    
    String DESTINATION_TYPE_CODE = "EXPENSE";
    
    String AUTHORIZATION_STATUS = "INCOMPLETE";
    
    Long CODE_COMBINATION_ID = 78064L;
    
//    Long CATEGORY_ID = 9128L;
    
    String LIE_TYPE_IGC = "IGC CONTRACT COMMITMENT";
    
    String supplierNewServiceSubject = "New Service from ?vendor_name";
    
    String supplierNewServiceText = "has sent the below new service detail(s).";
    
    String supplierNewServiceBodyContent = "<!DOCTYPE html>\n" + 
    		"<html>\n" + 
    		"<head>\n" + 
    		"<style>\n" + 
    		"table {\n" + 
    		"  font-family: arial, sans-serif;\n" + 
    		"  border-collapse: collapse;\n" + 
    		"  width: 100%;\n" + 
    		"}\n" + 
    		"\n" + 
    		"td, th {\n" + 
    		"  border: 1px solid #dddddd;\n" + 
    		"  text-align: left;\n" + 
    		"  padding: 8px;\n" + 
    		"}\n" + 
    		"\n" + 
    		"tr:nth-child(even) {\n" + 
    		"  background-color: #dddddd;\n" + 
    		"}\n" + 
    		"</style>\n" + 
    		"</head>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h3 style=\" color: #7c795d; font-family: 'Trocchi', serif; font-size: 30px; font-weight: normal; line-height: 48px; margin: 0;\">?supplier_new_service</h3>\n" + 
    		"\n" + 
    		"<table>\n" + 
    		"  <tr>\n" +
    		"    <th>LineType </th>\n" + 
    		"    <th>LineNo </th>\n" + 
    		"    <th>ItemDescription </th>\n" + 
    		"    <th>Qty/Amount</th>\n" + 
    		"    <th>OuName</th>\n" +
    		"    <th>OrgName</th>\n" + 
    		"    <th>ShipLocation </th>\n" +
    		"    <th>Tax(%) </th>\n" +
    		"    <th>VendorSite </th>\n" +
    		"    <th>SCN </th>\n" +
    		"  </tr>";

    
	String supplierRegistrationBody = "<!DOCTYPE html>\n" + "<html\n"
			+ "<body>\n" + "\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">Hi, </p>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">Welcome to the Supplier Collaboration Application</p>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">As a registered business partner at DFC, you are hereby invited to provide us with some more information about your company.</p>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">This way we can ensure a successful cooperation.</p>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">Please use the Link at the end of this mail to provide the information.</p>\n"
			+ "<a href=\"${register_link}\" style=\" color: #d63031; transition: .5s; -moz-transition: .5s; -webkit-transition: .5s; -o-transition: .5s; font-family: 'Muli', sans-serif;\">Click the link</a>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \"></p>\n"
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">Thank you for your Participation</p>\n"
			+ "\n" + "</body>\n" + "</html>";
	
	
	String supplierRegistrationSubmissionBody = "<!DOCTYPE html>\n" + "<html\n"
			+ "<body>\n" + "\n"		
			+ "<p style=\" color: #4c4a37; font-family: 'Source Sans Pro', sans-serif; font-size: 15px; line-height: 32px; margin: 0 0 24px; \">Supplier , ?supplier_name? has registered newly. Id : ?id?.</p>\n"
			+ "\n" + "</body>\n" + "</html>";

//	String SAP_GENERIC_URL_PREFIX = "http://192.168.1.7:8002/sap/bc/";
	
	String SAP_GENERIC_URL_PREFIX = "http://ataitd01.ataind.local:8000/sap/bc/";
}
