package com.foucsr.supplierportal.mysql.database.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.model.ShipMentTbl;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentStatusRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentTblRepository;

@Service
public class ShipMentTblRepositoryService {

	@Autowired
	private ShipMentTblRepository shipMentTblRepository;

	public ShipMentTbl saveOrUpdateShipment(ShipMentTbl shipMentTbl, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return shipMentTblRepository.save(shipMentTbl);

	}

	public Optional<ShipMentTbl> findShipmentByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<ShipMentTbl> shipMentTbl = shipMentTblRepository.findById(id);

		return shipMentTbl;
	}

	public Iterable<ShipMentTbl> findAllShipments(String username) {
		return shipMentTblRepository.findAll();
	}


}
