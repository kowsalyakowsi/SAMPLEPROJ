package com.foucsr.supplierportal.mysql.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.PaymentDetailsTbl;
import com.foucsr.supplierportal.mysql.database.repository.PaymentDetailsTblRepository;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@Service
public class PaymentDetailsTblService {

	@Autowired
	private PaymentDetailsTblRepository paymentDetailsTblRepository;

	public PaymentDetailsTbl saveOrUpdateProject(PaymentDetailsTbl paymentDetailsTbl, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return paymentDetailsTblRepository.save(paymentDetailsTbl);

	}

	public Optional<PaymentDetailsTbl> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<PaymentDetailsTbl> paymentDetailsTbl = paymentDetailsTblRepository.findById(id);

		return paymentDetailsTbl;
	}

	public Iterable<PaymentDetailsTbl> findAllProjects(String username) {
		return paymentDetailsTblRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		paymentDetailsTblRepository.deleteById(id);
	}
	
    public List<PaymentDetailsTbl> getPaymentDetailsByDate(GetOpenPoByDateRequest byDateRequest) {
		
		List<PaymentDetailsTbl> list = null;
		
		try {
			if (byDateRequest.getVendorId() != null && byDateRequest.getFilter_for_payment_details() != null
					&& byDateRequest.getPo_num() != null && !"".equals(byDateRequest.getPo_num()) ) {
				list = paymentDetailsTblRepository.getPaymentDetailsByPONum(
						byDateRequest.getPo_num(),byDateRequest.getVendorId());
			} 
			else if (byDateRequest.getVendorId() != null && byDateRequest.getFilter_for_payment_details() != null
					&& byDateRequest.getInvoice_num() != null && !"".equals(byDateRequest.getInvoice_num()) ) {
				list = paymentDetailsTblRepository.getPaymentDetailsByInvNum(
						byDateRequest.getInvoice_num(),byDateRequest.getVendorId());
			}
			else if (byDateRequest.getVendorId() != null && byDateRequest.getFilter_for_payment_details() != null
					&& byDateRequest.getPayment_num() != null && !"".equals(byDateRequest.getPayment_num()) ) {
				list = paymentDetailsTblRepository.getPaymentDetailsByPayNum(
						byDateRequest.getPayment_num(),byDateRequest.getVendorId());
			}
			else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null 
					         && byDateRequest.getVendorId() != null) {
				list = paymentDetailsTblRepository.getPaymentDetailsByAllParm(byDateRequest.getFromDate(),
						         byDateRequest.getToDate(),byDateRequest.getVendorId());
			}
			else if (byDateRequest.getVendorId() != null) {
				list = paymentDetailsTblRepository.getPaymentDetailsByVendorId(byDateRequest.getVendorId());
			}

		} catch (Exception e) {
			throw new AppException("Unable to get payment details");
		}

		return list;

	}

}
