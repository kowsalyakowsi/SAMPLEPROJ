package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;

@Repository
public interface OpenPoChangeDetailsRepository extends CrudRepository<OpenPoChangeDetails, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<OpenPoChangeDetails> findAll();
    @Query(value = "select * from OPEN_PO_DETAILS where need_by_date=:date", nativeQuery = true)
    List<OpenPoChangeDetails> findByFirstNameAndLastName(@Param("date") String firstName);
    
    @Query(value = "select * from OPEN_PO_DETAILS where (COALESCE(ACK,'N')  = 'N') AND (RESCHEDULE IS NULL OR RESCHEDULE = 'N') and VENDOR_ID =:vendorId and IS_CHANGED = 'N' and IS_REJECTED = 'N' and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d')", nativeQuery = true)
   	Iterable<OpenPoChangeDetails> getOpenPoDetailsByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorIds);
    
    @Query(value = "select * from OPEN_PO_DETAILS where (COALESCE(ACK,'N')  = 'N') AND (RESCHEDULE IS NULL OR RESCHEDULE = 'N')  and IS_CHANGED = 'N' and IS_REJECTED = 'N' and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d')", nativeQuery = true)
   	Iterable<OpenPoChangeDetails> getOpenPoDetailsByFromToDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates );
    
    @Query(value = "select * from OPEN_PO_DETAILS where ACK = 'Y' AND PENDING_QTY > 0 AND ASN IS NULL AND OU_NAME=:orgNames and VENDOR_ID =:vendorId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d')", nativeQuery = true)
   	Iterable<OpenPoChangeDetails> getOpenPoDetailsByorgName(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorIds,@Param("orgNames") String orgNames );
	
    @Query(value = "select * from  CHANGE_REQUEST_DETAILS where HEADER_ID=:headerId AND PO_LINE_LOCATION_ID=:poLineLocationId order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    OpenPoChangeDetails findByHeaderIdAndPoLineLocationId(@Param("headerId") long headerId,@Param("poLineLocationId") long poLineLocationId);
    
    @Query(value = "select * from CHANGE_REQUEST_DETAILS where IS_CHANGED  = 'Y' and (BUYER_APPROVAL is null or BUYER_APPROVAL not in ('Y','N')) and (IS_REJECTED is null or IS_REJECTED not in ('Y','N')) and PO_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') and buyer_id = :buyerId order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<OpenPoChangeDetails> getOpenPoDetailsByFromToDateBuyer(@Param("fromDate") String fromDates,@Param("toDate") String toDates , @Param("buyerId") String buyerId);

    @Query(value = "select * from CHANGE_REQUEST_DETAILS where IS_CHANGED  = 'Y' and (BUYER_APPROVAL is null or BUYER_APPROVAL not in ('Y','N')) and (IS_REJECTED is null or IS_REJECTED not in ('Y','N')) and buyer_id = :buyerId order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<OpenPoChangeDetails> getOpenPoDetailsByBuyer(@Param("buyerId") String buyerId);
    
    @Query(value = "select * from CHANGE_REQUEST_DETAILS where IS_CHANGED  = 'Y' and VENDOR_ID =:vendorId and PO_DATE BETWEEN STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
   	List<OpenPoChangeDetails> getChangedPoDetailsByDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId);
    
    @Query(value = "select * from CHANGE_REQUEST_DETAILS where IS_CHANGED  = 'Y' and VENDOR_ID =:vendorId order by PO_NUMBER , PO_LINE_NUM", nativeQuery = true)
   	List<OpenPoChangeDetails> getChangedPoDetailsByVendorId(@Param("vendorId") String vendorId);
    
    @Query(value = "select count(*) from CHANGE_REQUEST_DETAILS where IS_CHANGED  = 'Y' and (BUYER_APPROVAL is null or BUYER_APPROVAL not in ('Y','N')) and buyer_id = :buyerId", nativeQuery = true)
    long getChangeRequestPoCountByBuyerId(@Param("buyerId") String buyerId);
	
   // OpenPODetails findByHeaderIdAndPoLineLocationId(Integer headerId,Integer poLineLocationId);
    
}