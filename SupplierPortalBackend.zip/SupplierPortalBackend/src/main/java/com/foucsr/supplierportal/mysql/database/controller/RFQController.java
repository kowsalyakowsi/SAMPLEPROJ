package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.QuotationLines;
import com.foucsr.supplierportal.mysql.database.model.QuotationPriceBreaks;
import com.foucsr.supplierportal.mysql.database.model.RFQHeader;
import com.foucsr.supplierportal.mysql.database.model.RFQLines;
import com.foucsr.supplierportal.mysql.database.model.RFQPriceBreaks;
import com.foucsr.supplierportal.mysql.database.model.RFQRelatedObjects;
import com.foucsr.supplierportal.mysql.database.model.RFQVendors;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.RFQService;

@RestController
@RequestMapping("/RFQ/Service")
@CrossOrigin
public class RFQController {

	@Autowired
	private RFQService rFQService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	@GetMapping("/getRFQObjects")
	public ResponseEntity<?> changeRequestPo(@RequestParam Map<String, String> requestParams , Principal principal) {
		
		long buyerId = Long.parseLong(requestParams.get("buyerId"));

		RFQRelatedObjects rfqObj = rFQService.getAllRFQRelatedObjects(buyerId);

		return new ResponseEntity<RFQRelatedObjects>(rfqObj, HttpStatus.CREATED);
	}

	@PostMapping("/createHeader")
	public ResponseEntity<?> createHeader(@Valid @RequestBody RFQHeader header, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		RFQHeader rfq = rFQService.saveOrUpdateHeader(header, principal.getName());

		return new ResponseEntity<RFQHeader>(rfq, HttpStatus.CREATED);
	}

	@PostMapping("/createLines")
	public ResponseEntity<?> createLines(@Valid @RequestBody Iterable<RFQLines> lines, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		Iterable<RFQLines> rfqLines = rFQService.saveOrUpdateLines(lines);

		return new ResponseEntity<Iterable<RFQLines>>(rfqLines, HttpStatus.CREATED);
	}

	@PostMapping("/addVendors")
	public ResponseEntity<?> addVendors(@Valid @RequestBody Iterable<RFQVendors> vendors, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		Iterable<RFQVendors> rfqVendors = rFQService.saveOrUpdateVendors(vendors, principal.getName());

		return new ResponseEntity<Iterable<RFQVendors>>(rfqVendors, HttpStatus.CREATED);
	}

	@GetMapping("/getAll")
	public ResponseEntity<?> getAll(@RequestParam Map<String, String> requestParams, Principal principal) {

		long buyerId = Long.parseLong(requestParams.get("buyerId"));

		List<RFQHeader> rfqHeaders = rFQService.getAll(buyerId);

		return new ResponseEntity<List<RFQHeader>>(rfqHeaders, HttpStatus.CREATED);
	}

	@GetMapping("/getAllLines")
	public ResponseEntity<?> getAllLines(@RequestParam long rfqHeaderId, Principal principal) {

		List<RFQLines> rfqHeaders = rFQService.getAllLines(rfqHeaderId);

		return new ResponseEntity<Iterable<RFQLines>>(rfqHeaders, HttpStatus.OK);
	}

	@DeleteMapping("/deleteLine")
	public ResponseEntity<?> deleteLine(@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		long rfq_line_id = Long.parseLong(requestParams.get("rfq_line_id"));

		String message = rFQService.deleteLine(rfq_header_id, rfq_line_id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

	@GetMapping("/getAllPriceBreaks")
	public ResponseEntity<?> getAllPriceBreaks(@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		long rfq_line_id = Long.parseLong(requestParams.get("rfq_line_id"));

		List<RFQPriceBreaks> rfqHeaders = rFQService.getAllPriceBreaks(rfq_header_id, rfq_line_id);

		return new ResponseEntity<Iterable<RFQPriceBreaks>>(rfqHeaders, HttpStatus.OK);
	}

	@PostMapping("/createPriceBreaks")
	public ResponseEntity<?> createPriceBreaks(@Valid @RequestBody Iterable<RFQPriceBreaks> lines, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		Iterable<RFQPriceBreaks> rfqLines = rFQService.saveOrUpdatePriceBreaks(lines);

		return new ResponseEntity<Iterable<RFQPriceBreaks>>(rfqLines, HttpStatus.CREATED);
	}

	@PutMapping("/updatePriceBreaks")
	public ResponseEntity<?> updatePriceBreaks(@Valid @RequestBody RFQPriceBreaks line, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		RFQPriceBreaks rfqLine = rFQService.updatePriceBreaks(line);

		return new ResponseEntity<RFQPriceBreaks>(rfqLine, HttpStatus.CREATED);
	}

	@DeleteMapping("/deletePriceBreak")
	public ResponseEntity<?> deletePriceBreak(@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		long rfq_line_id = Long.parseLong(requestParams.get("rfq_line_id"));

		long rfq_line_location_id = Long.parseLong(requestParams.get("rfq_line_location_id"));

		String message = rFQService.deletePriceBreak(rfq_header_id, rfq_line_id, rfq_line_location_id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

	@GetMapping("/getAllVendors")
	public ResponseEntity<?> getAllSuppliers(@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		List<RFQVendors> rfqHeaders = rFQService.getAllSuppliers(rfq_header_id);

		return new ResponseEntity<Iterable<RFQVendors>>(rfqHeaders, HttpStatus.OK);
	}

	@PostMapping("/createVendors")
	public ResponseEntity<?> createVendors(@Valid @RequestBody Iterable<RFQVendors> vendors, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		Iterable<RFQVendors> rfqLines = rFQService.saveOrUpdateVendors(vendors);

		return new ResponseEntity<Iterable<RFQVendors>>(rfqLines, HttpStatus.CREATED);
	}

	@DeleteMapping("/deleteVendor")
	public ResponseEntity<?> deleteVendor(@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		long vendor_id = Long.parseLong(requestParams.get("vendor_id"));

		String message = rFQService.deleteVendor(rfq_header_id, vendor_id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

	@PutMapping("/updateActive")
	public ResponseEntity<?> updateActive(HttpServletRequest request ,@RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));

		String message = rFQService.updateActive(rfq_header_id ,  request);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

	@GetMapping("/getAllByVendor")
	public ResponseEntity<?> getAllByVendor(@RequestParam Map<String, String> requestParams, Principal principal) {

		long vendorId = Long.parseLong(requestParams.get("vendorId"));

		List<QuotationLines> rfqHeaders = rFQService.getQuotationByVendor(vendorId);

		return new ResponseEntity<List<QuotationLines>>(rfqHeaders, HttpStatus.OK);
	}
	
	@PutMapping("/updateUnitPrice")
	public ResponseEntity<?> updateUnitPrice(@RequestParam Map<String, String> requestParams, Principal principal) {

		long quotation_line_id = Long.parseLong(requestParams.get("id"));
		
		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));
		
		long rfq_line_id = Long.parseLong(requestParams.get("rfq_line_id"));

		long rfq_line_location_id = Long.parseLong(requestParams.get("rfq_line_location_id"));
		
		double updateUnitPrice = 0;
		
		String include_freight = "N";
		
		double freight_charge = 0;
		
		double tax = 0;
		
		String user_name = requestParams.get("user_name");
		
		if( requestParams.get("updated_price_by_supplier") != null && !"null".equals(requestParams.get("updated_price_by_supplier"))) {
		
			updateUnitPrice = Double.parseDouble(requestParams.get("updated_price_by_supplier"));
		}
		
		
		if( requestParams.get("freight_charge_include") != null && !"null".equals(requestParams.get("freight_charge_include"))) {
		
			include_freight = requestParams.get("freight_charge_include");
		}
		
		if( requestParams.get("freight_charge") != null && !"null".equals(requestParams.get("freight_charge"))) {
			
			freight_charge = Double.parseDouble(requestParams.get("freight_charge"));
		}
		
        if( requestParams.get("tax" ) != null && !"null".equals(requestParams.get("tax"))) {
			
			tax = Double.parseDouble(requestParams.get("tax"));
		}
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String price_end_date_str = requestParams.get("price_end_date");

        Date price_end_date = null;
        
        if(price_end_date_str != null && !"null".equals(requestParams.get("price_end_date"))) {
        	
        	
        	try {
        		price_end_date = formatter.parse(price_end_date_str);
        	} catch (ParseException e) {
        		
        	}       
        }               

		String message = rFQService.updateQuotUnitPrice(rfq_header_id, rfq_line_id, rfq_line_location_id, updateUnitPrice,
				include_freight , freight_charge , tax , user_name ,price_end_date , quotation_line_id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	@PostMapping("/addPriceBreaksByVendor")
    public ResponseEntity<?> addPriceBreaksByVendor(@Valid @RequestBody List<QuotationPriceBreaks> request, BindingResult result, Principal principal){

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if(errorMap!=null) return errorMap;
        
        List<QuotationPriceBreaks> list = rFQService.addQuotPriceBreaks(request);
        
        return new ResponseEntity<List<QuotationPriceBreaks>>(list, HttpStatus.CREATED);
    }
	
	@DeleteMapping("/deleteQuotationPriceBreak")
	public ResponseEntity<?> deleteQuotationPriceBreak(@RequestParam Map<String, String> requestParams, Principal principal) {

		long id = Long.parseLong(requestParams.get("id"));

		String message = rFQService.deleteQuotationPriceBreak(id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	@GetMapping("/getQuotationByAgent")
	public ResponseEntity<?> getQuotationByAgent(@RequestParam Map<String, String> requestParams, Principal principal) {

		long agent_id = Long.parseLong(requestParams.get("agent_id"));
		
		String rfq_number = requestParams.get("rfq_number");

		List<QuotationLines> rfqHeaders = rFQService.getQuotationByAgent(agent_id , rfq_number);

		return new ResponseEntity<List<QuotationLines>>(rfqHeaders, HttpStatus.OK);
	}
	
	@PutMapping("/sendQuotNotification")
	public ResponseEntity<?> sendQuotNotification(HttpServletRequest request , @RequestParam Map<String, String> requestParams, Principal principal) {

		long rfq_header_id = Long.parseLong(requestParams.get("rfq_header_id"));
		
		String user_name = requestParams.get("user_name");
			

		String message = rFQService.sendQuotNotification(rfq_header_id , user_name ,  request);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}


}
