package com.foucsr.supplierportal.util;

public class MailObjects {

	private String SMTP_HOST = "smtp.gmail.com";
    private String USERNAME = "muthuganesh200591@gmail.com";
    private String PASSWORD = "ssrytm32";

    private String EMAIL_FROM = "muthuganesh200591@gmail.com";
    private String EMAIL_TO = "prabhakarancrazy20@gmail.com";
    private String EMAIL_TO_CC = "";

    private String EMAIL_SUBJECT = "Test Send Email via SMTP (ATTACHMENT)";
    private String EMAIL_TEXT = "Hello Java Mail \n ABC123";
    
}
