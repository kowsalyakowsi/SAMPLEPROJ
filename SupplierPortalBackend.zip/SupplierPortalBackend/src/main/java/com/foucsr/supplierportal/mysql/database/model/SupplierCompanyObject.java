package com.foucsr.supplierportal.mysql.database.model;

import java.util.List;

public class SupplierCompanyObject {

	private SuppliersRegister supplierRegister;

	private List<TaxCountry> countries;	

	public SuppliersRegister getSupplierRegister() {
		return supplierRegister;
	}

	public void setSupplierRegister(SuppliersRegister supplierRegister) {
		this.supplierRegister = supplierRegister;
	}

	public List<TaxCountry> getCountries() {
		return countries;
	}

	public void setCountries(List<TaxCountry> countries) {
		this.countries = countries;
	}

}
