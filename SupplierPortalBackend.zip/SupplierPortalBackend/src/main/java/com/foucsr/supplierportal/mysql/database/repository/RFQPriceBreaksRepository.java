package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQPriceBreaks;

@Repository
public interface RFQPriceBreaksRepository extends CrudRepository<RFQPriceBreaks, Long> {

	
    @Override
    Iterable<RFQPriceBreaks> findAll();    

    @Query(value = "SELECT * FROM RFQ_PRICE_BREAKS  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId", nativeQuery = true)
    List<RFQPriceBreaks> findAllPriceBreaks(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId);
    
    @Query(value = "SELECT MAX(SHIPMENT_NUM) FROM RFQ_PRICE_BREAKS  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId", nativeQuery = true)
    Long findMaxLineCount(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId);
    
    @Query(value = "SELECT * FROM RFQ_PRICE_BREAKS  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId and RFQ_LINE_LOCATION_ID = :rfq_line_location_id", nativeQuery = true)
    RFQPriceBreaks findPriceBreak(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId , @Param("rfq_line_location_id") Long rfq_line_location_id);
    
}