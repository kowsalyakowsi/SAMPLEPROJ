package com.foucsr.supplierportal.mysql.database.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.RTVDetails;
import com.foucsr.supplierportal.mysql.database.repository.RTVDetailsRepository;

@Service
public class RTVDetailsService {

	@Autowired
	private RTVDetailsRepository rtvDetailsRepository;

	public RTVDetails saveOrUpdateProject(RTVDetails rtvDetails, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return rtvDetailsRepository.save(rtvDetails);

	}

	public Optional<RTVDetails> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<RTVDetails> rtvDetails = rtvDetailsRepository.findById(id);

		return rtvDetails;
	}

	public Iterable<RTVDetails> findAllProjects(String username) {
		return rtvDetailsRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		rtvDetailsRepository.deleteById(id);
	}

}
