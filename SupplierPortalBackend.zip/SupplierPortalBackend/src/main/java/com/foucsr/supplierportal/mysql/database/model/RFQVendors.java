package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "RFQ_VENDORS" , uniqueConstraints=
@UniqueConstraint(columnNames={"RFQ_HEADER_ID", "VENDOR_ID"}))
public class RFQVendors {

	@Id
	@SequenceGenerator(name = "RFQ_VENDORS_SEQ", sequenceName = "RFQ_VENDORS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RFQ_VENDORS_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "RFQ_HEADER_ID")
	private long rfq_header_id;

	@Column(name = "SEQUENCE_NUM")
	private int sequence_num;

	@Column(name = "VENDOR_ID")
	private long vendor_id;
	
	@Column(name = "VENDOR_NAME")
	private String vendor_name;
	
	@Column(name = "SITE_NAME")
	private String site_name;

	@Column(name = "VENDOR_SITE_ID")
	private long vendor_site_id;

	@Column(name = "VENDOR_CONTACT_ID")
	private long vendor_contact_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "USER_NAME")
	private String user_name;
	
	@Column(name = "IS_MAIL_SENT")
	private String is_mail_sent;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "RFQ_HEADER_ID" , insertable = false, updatable = false)
	private RFQHeader rfqHeader;

	public RFQVendors() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public int getSequence_num() {
		return sequence_num;
	}

	public void setSequence_num(int sequence_num) {
		this.sequence_num = sequence_num;
	}

	public long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public long getVendor_site_id() {
		return vendor_site_id;
	}

	public void setVendor_site_id(long vendor_site_id) {
		this.vendor_site_id = vendor_site_id;
	}

	public long getVendor_contact_id() {
		return vendor_contact_id;
	}

	public void setVendor_contact_id(long vendor_contact_id) {
		this.vendor_contact_id = vendor_contact_id;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Long getLast_update_login() {
		return last_update_login;
	}

	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	@JsonIgnore
	public RFQHeader getRfqHeader() {
		return rfqHeader;
	}

	public void setRfqHeader(RFQHeader rfqHeader) {
		this.rfqHeader = rfqHeader;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getSite_name() {
		return site_name;
	}

	public void setSite_name(String site_name) {
		this.site_name = site_name;
	}

	public String getIs_mail_sent() {
		return is_mail_sent;
	}

	public void setIs_mail_sent(String is_mail_sent) {
		this.is_mail_sent = is_mail_sent;
	}

}