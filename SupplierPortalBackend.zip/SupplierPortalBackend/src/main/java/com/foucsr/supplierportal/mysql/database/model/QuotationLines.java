package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "QUOTATION_LINES")
public class QuotationLines {

	@Id
	@SequenceGenerator(name = "QUOTATION_LINES_SEQ", sequenceName = "QUOTATION_LINES_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QUOTATION_LINES_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "AGENT_ID")
	private long agent_id;

	@Column(name = "AGENT_NAME")
	private String agent_name;

	@Column(name = "RFQ_NUMBER")
	private String rfq_number;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "SHIP_TO_LOCATION_CODE")
	private String ship_to_location_code;

	@Column(name = "BILL_TO_LOCATION_ID")
	private long bill_to_location_id;

	@Column(name = "BILL_TO_LOCATION_CODE")
	private String bill_to_location_code;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "RFQ_CLOSE_DATE")
	private Date rfq_close_date;

	@Column(name = "RFQ_LINE_LOCATION_ID")
	private Long rfq_line_location_id;

	@Column(name = "RFQ_LINE_ID")
	private Long rfq_line_id;

	@Column(name = "RFQ_HEADER_ID")
	private Long rfq_header_id;

	@Column(name = "LINE_NUM")
	private long line_num;

	@Column(name = "SHIPMENT_NUM")
	private long shipment_num;

	@Column(name = "ITEM_ID")
	private long item_id;

	@Column(name = "ITEM_NAME")
	private String item_name;

	@Column(name = "ITEM_DESCRIPTION")
	private String item_description;	

	@Column(name = "QUANTITY")
	private double quantity;

	@Column(name = "UNIT_MEAS_LOOKUP_CODE")
	private String unit_meas_lookup_code;

	@Column(name = "SHIP_TO_LOCATION_ID")
	private long ship_to_location_id;

	@Column(name = "PRICE_OVERRIDE")
	private double price_override;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE")
	private Date start_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE")
	private Date end_date;

	@Column(name = "PRICE_DISCOUNT")
	private double price_discount;

	@Column(name = "SHIP_TO_ORGANIZATION_ID")
	private long ship_to_organization_id;

	@Column(name = "ORGANIZATION")
	private String organization;

	@Column(name = "SHIP_TO_LOCATION")
	private String ship_to_location;
	
	@Column(name = "LINE_TYPE_ID")
	private Long line_type_id;
	
	@Column(name = "LINE_TYPE")
	private String line_type;

	@OneToMany(cascade = CascadeType.REFRESH, mappedBy = "quotationLines")
	private List<QuotationPriceBreaks> rfqPriceBreaksVendor;	

	@OneToMany(cascade = CascadeType.REFRESH, mappedBy = "quotationLines")
	private List<QuotationLineDetails> quotationLineDetails;  
	
    private String freight_charge_include;
	
	private Double freight_charge;
	
	private Double tax;
	
	private Double updated_price_by_supplier;
	
	private Long vendor_id;
	
	private String vendor_name;
	
	private String notification_sent;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date price_end_date;
	
	@Column(name = "QUOTE_TYPE_LOOKUP_CODE")
	private String quote_type_lookup_code;
	
	private String vendor_site_code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRfq_line_location_id() {
		return rfq_line_location_id;
	}

	public void setRfq_line_location_id(Long rfq_line_location_id) {
		this.rfq_line_location_id = rfq_line_location_id;
	}

	public Long getRfq_line_id() {
		return rfq_line_id;
	}

	public void setRfq_line_id(Long rfq_line_id) {
		this.rfq_line_id = rfq_line_id;
	}

	public Long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(Long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	public long getLine_num() {
		return line_num;
	}

	public void setLine_num(long line_num) {
		this.line_num = line_num;
	}

	public long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public long getItem_id() {
		return item_id;
	}

	public void setItem_id(long item_id) {
		this.item_id = item_id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getUnit_meas_lookup_code() {
		return unit_meas_lookup_code;
	}

	public void setUnit_meas_lookup_code(String unit_meas_lookup_code) {
		this.unit_meas_lookup_code = unit_meas_lookup_code;
	}

	public long getShip_to_location_id() {
		return ship_to_location_id;
	}

	public void setShip_to_location_id(long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}

	public double getPrice_override() {
		return price_override;
	}

	public void setPrice_override(double price_override) {
		this.price_override = price_override;
	}	

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public double getPrice_discount() {
		return price_discount;
	}

	public void setPrice_discount(double price_discount) {
		this.price_discount = price_discount;
	}

	public long getShip_to_organization_id() {
		return ship_to_organization_id;
	}

	public void setShip_to_organization_id(long ship_to_organization_id) {
		this.ship_to_organization_id = ship_to_organization_id;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getShip_to_location() {
		return ship_to_location;
	}

	public void setShip_to_location(String ship_to_location) {
		this.ship_to_location = ship_to_location;
	}

	public List<QuotationPriceBreaks> getRfqPriceBreaksVendor() {
		return rfqPriceBreaksVendor;
	}

	public void setRfqPriceBreaksVendor(List<QuotationPriceBreaks> rfqPriceBreaksVendor) {
		this.rfqPriceBreaksVendor = rfqPriceBreaksVendor;
	}

	public long getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(long agent_id) {
		this.agent_id = agent_id;
	}

	public String getAgent_name() {
		return agent_name;
	}

	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}

	public String getRfq_number() {
		return rfq_number;
	}

	public void setRfq_number(String rfq_number) {
		this.rfq_number = rfq_number;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getShip_to_location_code() {
		return ship_to_location_code;
	}

	public void setShip_to_location_code(String ship_to_location_code) {
		this.ship_to_location_code = ship_to_location_code;
	}

	public long getBill_to_location_id() {
		return bill_to_location_id;
	}

	public void setBill_to_location_id(long bill_to_location_id) {
		this.bill_to_location_id = bill_to_location_id;
	}

	public String getBill_to_location_code() {
		return bill_to_location_code;
	}

	public void setBill_to_location_code(String bill_to_location_code) {
		this.bill_to_location_code = bill_to_location_code;
	}

	public Date getRfq_close_date() {
		return rfq_close_date;
	}

	public void setRfq_close_date(Date rfq_close_date) {
		this.rfq_close_date = rfq_close_date;
	}
	
	@JsonIgnore
	public List<QuotationLineDetails> getQuotationLineDetails() {
		return quotationLineDetails;
	}

	public void setQuotationLineDetails(List<QuotationLineDetails> quotationLineDetails) {
		this.quotationLineDetails = quotationLineDetails;
	}
	
	public String getFreight_charge_include() {
		return freight_charge_include;
	}

	public void setFreight_charge_include(String freight_charge_include) {
		this.freight_charge_include = freight_charge_include;
	}

	public Double getFreight_charge() {
		return freight_charge;
	}

	public void setFreight_charge(Double freight_charge) {
		this.freight_charge = freight_charge;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public Date getPrice_end_date() {
		return price_end_date;
	}

	public void setPrice_end_date(Date price_end_date) {
		this.price_end_date = price_end_date;
	}


	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getNotification_sent() {
		return notification_sent;
	}

	public void setNotification_sent(String notification_sent) {
		this.notification_sent = notification_sent;
	}
	
	public Double getUpdated_price_by_supplier() {
		return updated_price_by_supplier;
	}

	public void setUpdated_price_by_supplier(Double updated_price_by_supplier) {
		this.updated_price_by_supplier = updated_price_by_supplier;
	}

	public String getQuote_type_lookup_code() {
		return quote_type_lookup_code;
	}

	public void setQuote_type_lookup_code(String quote_type_lookup_code) {
		this.quote_type_lookup_code = quote_type_lookup_code;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

	
	
}
