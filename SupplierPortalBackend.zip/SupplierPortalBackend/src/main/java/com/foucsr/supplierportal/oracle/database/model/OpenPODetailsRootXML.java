package com.foucsr.supplierportal.oracle.database.model;

public class OpenPODetailsRootXML {

	
}