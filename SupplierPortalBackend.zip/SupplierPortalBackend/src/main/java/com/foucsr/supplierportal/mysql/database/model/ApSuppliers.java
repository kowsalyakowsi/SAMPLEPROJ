package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "AP_SUPPLIERS" , uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "VENDOR_ID"
            })
    })

public class ApSuppliers {

	@Id
	/*@SequenceGenerator(name = "AP_SUPPLIERS_SEQ", sequenceName = "AP_SUPPLIERS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AP_SUPPLIERS_SEQ")
	@Column(name = "ID")
	private Long id;*/
	@Column(name = "VENDOR_ID")
	private Long vendor_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;
	
	@Column(name = "VENDOR_NAME")
	private String vendor_name;

	@Column(name = "VENDOR_CODE")
	private String vendor_code;

	@Column(name = "VENDOR_NAME_ALT")
	private String vendor_name_alt;

	@Column(name = "SEGMENT1")
	private String segment1;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;

	@Column(name = "PARENT_VENDOR_ID")
	private Long parent_vendor_id;

	@Column(name = "MIN_ORDER_AMOUNT")
	private Double min_order_amount;

	@Column(name = "SHIP_TO_LOCATION_ID")
	private Long ship_to_location_id;

	@Column(name = "BILL_TO_LOCATION_ID")
	private Long bill_to_location_id;

	@Column(name = "CREDIT_LIMIT")
	private Double credit_limit;

	@Column(name = "INVOICE_CURRENCY_CODE")
	private String invoice_currency_code;

	@Column(name = "PAYMENT_CURRENCY_CODE")
	private String payment_currency_code;

	@Column(name = "ORGANIZATION_TYPE_LOOKUP_CODE")
	private String organization_type_lookup_code;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE_ACTIVE")
	private Date start_date_active;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE_ACTIVE")
	private Date end_date_active;

	@Column(name = "PARTY_ID")
	private Long party_id;

	@Column(name = "PARENT_PARTY_ID")
	private Long parent_party_id;

	@Column(name = "COMPANY_REGISTRATION_NUMBER")
	private String company_registration_number;

	@Column(name = "PO_PROCESS_STATUS")
	private String processStatus;
	
	@OneToMany(cascade = CascadeType.REFRESH , mappedBy = "supplier" )
	//@JoinColumn(name = "VENDOR_ID", referencedColumnName = "VENDOR_ID" , insertable = false, updatable = false)
	private List<SupplierSites> sites;


	/*public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}*/


	public Long getVendor_id() {
		return vendor_id;
	}


	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}


	public Date getLast_update_date() {
		return last_update_date;
	}


	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}


	public Long getLast_updated_by() {
		return last_updated_by;
	}


	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}


	public String getVendor_name() {
		return vendor_name;
	}


	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}


	public String getVendor_name_alt() {
		return vendor_name_alt;
	}


	public void setVendor_name_alt(String vendor_name_alt) {
		this.vendor_name_alt = vendor_name_alt;
	}


	public String getSegment1() {
		return segment1;
	}


	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}


	public Long getLast_update_login() {
		return last_update_login;
	}


	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}


	public Long getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreation_date() {
		return creation_date;
	}


	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}


	public Long getParent_vendor_id() {
		return parent_vendor_id;
	}


	public void setParent_vendor_id(Long parent_vendor_id) {
		this.parent_vendor_id = parent_vendor_id;
	}


	public Double getMin_order_amount() {
		return min_order_amount;
	}


	public void setMin_order_amount(Double min_order_amount) {
		this.min_order_amount = min_order_amount;
	}


	public Long getShip_to_location_id() {
		return ship_to_location_id;
	}


	public void setShip_to_location_id(Long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}


	public Long getBill_to_location_id() {
		return bill_to_location_id;
	}


	public void setBill_to_location_id(Long bill_to_location_id) {
		this.bill_to_location_id = bill_to_location_id;
	}


	public Double getCredit_limit() {
		return credit_limit;
	}


	public void setCredit_limit(Double credit_limit) {
		this.credit_limit = credit_limit;
	}


	public String getInvoice_currency_code() {
		return invoice_currency_code;
	}


	public void setInvoice_currency_code(String invoice_currency_code) {
		this.invoice_currency_code = invoice_currency_code;
	}


	public String getPayment_currency_code() {
		return payment_currency_code;
	}


	public void setPayment_currency_code(String payment_currency_code) {
		this.payment_currency_code = payment_currency_code;
	}


	public String getOrganization_type_lookup_code() {
		return organization_type_lookup_code;
	}


	public void setOrganization_type_lookup_code(String organization_type_lookup_code) {
		this.organization_type_lookup_code = organization_type_lookup_code;
	}


	public Date getStart_date_active() {
		return start_date_active;
	}


	public void setStart_date_active(Date start_date_active) {
		this.start_date_active = start_date_active;
	}


	public Date getEnd_date_active() {
		return end_date_active;
	}


	public void setEnd_date_active(Date end_date_active) {
		this.end_date_active = end_date_active;
	}


	public Long getParty_id() {
		return party_id;
	}


	public void setParty_id(Long party_id) {
		this.party_id = party_id;
	}


	public Long getParent_party_id() {
		return parent_party_id;
	}


	public void setParent_party_id(Long parent_party_id) {
		this.parent_party_id = parent_party_id;
	}


	public String getCompany_registration_number() {
		return company_registration_number;
	}


	public void setCompany_registration_number(String company_registration_number) {
		this.company_registration_number = company_registration_number;
	}


	public String getProcessStatus() {
		return processStatus;
	}


	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}


	public ApSuppliers() {
	}


	public List<SupplierSites> getSites() {
		return sites;
	}


	public void setSites(List<SupplierSites> sites) {
		this.sites = sites;
	}


	public String getVendor_code() {
		return vendor_code;
	}


	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}

}