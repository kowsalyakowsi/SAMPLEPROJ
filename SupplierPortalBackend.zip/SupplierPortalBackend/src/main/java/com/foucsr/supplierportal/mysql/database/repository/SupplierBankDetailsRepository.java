package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.SupplierBankDetailsRegister;

@Repository
public interface SupplierBankDetailsRepository extends CrudRepository<SupplierBankDetailsRegister, Long> {
	  
    
    @Query(value = "select * from SUPPLIER_BANK_DETAILS_REGISTER where SUPPLIER_REGISTER_ID = :supplier_register_id", nativeQuery = true)
    List<SupplierBankDetailsRegister> getSupplierBankDetails(@Param("supplier_register_id") Long supplier_register_id );
    
  
    @Query(value = "select * from SUPPLIER_BANK_DETAILS_REGISTER where SUPPLIER_REGISTER_ID = :supplier_register_id AND ID = :id", nativeQuery = true)
    SupplierBankDetailsRegister findBankById(@Param("supplier_register_id") Long supplier_register_id , @Param("id") Long id );
    
    
    @Query(value = "select * from SUPPLIER_BANK_DETAILS_REGISTER where IS_SEND_TO_SUPPLIER_CREATION = 'Y' AND PO_PROCESS_STATUS = 'I'", nativeQuery = true)
    List<SupplierBankDetailsRegister> findAllBankDetailsToSupplierCreation();

    
}