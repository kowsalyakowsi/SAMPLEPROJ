package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.Currencies;


@Repository
public interface CurrenciesRepository extends CrudRepository<Currencies, Long> {	  

    
    @Query(value = "select * from CURRENCIES ", nativeQuery = true)
    List<Currencies> findAllCurrencies();

   
}