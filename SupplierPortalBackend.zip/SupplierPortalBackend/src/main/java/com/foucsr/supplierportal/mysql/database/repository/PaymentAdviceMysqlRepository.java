package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PaymentAdviceMysql;

@Repository
public interface PaymentAdviceMysqlRepository extends CrudRepository<PaymentAdviceMysql, Long> {
	   
	
    @Override
    Iterable<PaymentAdviceMysql> findAll();
   

    @Query(value = "select * from PAYMENT_ADVICE where HEADER_ID =:header_id ", nativeQuery = true)
    PaymentAdviceMysql getpaymentAdviceById(@Param("header_id") Long header_id);
    
    @Query(value = "select * from PAYMENT_ADVICE WHERE VENDOR_ID = :vendor_id", nativeQuery = true)
    List<PaymentAdviceMysql> getpaymentAdviceByVendor(@Param("vendor_id") String vendor_id);


}