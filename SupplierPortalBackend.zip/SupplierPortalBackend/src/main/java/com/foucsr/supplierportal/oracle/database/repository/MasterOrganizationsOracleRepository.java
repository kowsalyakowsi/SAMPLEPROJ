package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class MasterOrganizationsOracleRepository  {
	   
//
//    @Query(value = "select * from XX_MASTER_ORGANIZATIONS where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<MasterOrganizationsOracle> findAllOrganizations();
   
}