package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.AgentListProjection;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;

@Repository
public interface PoAgentsRepository extends CrudRepository<PoAgents, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<PoAgents> findAll();
    
    @Query(value = "select * from  PO_AGENTS where AGENT_ID=:agentID ", nativeQuery = true)
    PoAgents findByAgentId(@Param("agentID") String agentID);

    @Query(value = "select AGENT_ID,AGENT_NAME from  PO_AGENTS ", nativeQuery = true)
    List<AgentListProjection> findDistinctByAgents();
    
    @Query(value = "select AGENT_ID,AGENT_NAME from  PO_AGENTS WHERE BUSINESS_GROUP_ID IN (:bgIds)", nativeQuery = true)
    List<AgentListProjection> findBuyersWithBusinessGroup(@Param("bgIds") Set<Long> bgIds);
   
}
