package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PlantService;

@RestController
@RequestMapping("/Plant/Service")
@CrossOrigin
public class PlantController {

	@Autowired
	private PlantService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	
	@GetMapping("/getPlantList")
	public ResponseEntity<?> getPaymentAdviceList(Principal principal) {
		
		ResponseEntity<?> message = projectService.getPlantList();
		
		return message;

	}
}
