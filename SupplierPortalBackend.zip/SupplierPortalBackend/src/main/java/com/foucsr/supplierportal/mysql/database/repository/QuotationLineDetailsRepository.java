package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.QuotationLineDetails;

@Repository
public interface QuotationLineDetailsRepository extends CrudRepository<QuotationLineDetails, Long> {

	
    @Override
    Iterable<QuotationLineDetails> findAll();    
 
    @Query(value = "SELECT * FROM QUOTATION_LINE_DETAILS  WHERE RFQ_HEADER_ID = :rfqHeaderId and RFQ_LINE_ID = :rfqLineId and RFQ_LINE_LOCATION_ID = :rfq_line_location_id and VENDOR_ID = :vendorId", nativeQuery = true)
    QuotationLineDetails findLineDetail(@Param("rfqHeaderId") Long rfqHeaderId , @Param("rfqLineId") Long rfqLineId , @Param("rfq_line_location_id") Long rfq_line_location_id , @Param("vendorId") Long vendorId);       

    @Query(value = "SELECT * FROM QUOTATION_LINE_DETAILS  WHERE RFQ_HEADER_ID = :rfqHeaderId and VENDOR_ID = :vendorId", nativeQuery = true)
    List<QuotationLineDetails> findLineDetailsByHeaderId(@Param("rfqHeaderId") Long rfqHeaderId , @Param("vendorId") Long vendorId );
    
    @Query(value = "SELECT * FROM QUOTATION_LINE_DETAILS  where VENDOR_ID = :vendorId and QUOTATION_LINE_ID = :quotationLineId", nativeQuery = true)
    List<QuotationLineDetails> findAllLinesFilterByQuotationId(@Param("vendorId") Long vendorId , @Param("quotationLineId") Long quotationLineId);
    
    @Query(value = "SELECT * FROM QUOTATION_LINE_DETAILS  where RFQ_HEADER_ID = :rfqHeaderId and QUOTATION_LINE_ID = :quotationLineId AND NOTIFICATION_SENT = 'Y'", nativeQuery = true)
    List<QuotationLineDetails> findAllQuotationLInesByBuyer(@Param("rfqHeaderId") Long rfqHeaderId , @Param("quotationLineId") Long quotationLineId);
}