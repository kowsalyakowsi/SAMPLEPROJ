package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.UOM;

@Repository
public interface UOMRepository extends CrudRepository<UOM, Long> {
	
    @Override
    Iterable<UOM> findAll();
    
    @Query(value = "select * from UNITS_OF_MEASURE", nativeQuery = true)
    List<UOM> findAllValid();

}