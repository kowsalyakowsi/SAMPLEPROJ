package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQStatus;

@Repository
public interface RFQStatusRepository extends CrudRepository<RFQStatus, Long> {

	
    @Override
    Iterable<RFQStatus> findAll();
    
    @Query(value = "select * from RFQ_STATUS order by STATUS", nativeQuery = true)
    List<RFQStatus> findAllValid();

}