package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.oracle.database.model.VendorAgingOracle;
import com.foucsr.supplierportal.oracle.database.repository.VendorAgingOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.util.SCAUtil;

@Service
public class VendorAgingService {

	Logger logger = LoggerFactory.getLogger(VendorAgingService.class);
	
	
	@Autowired
   	private VendorAgingOracleRepository vendorAgingOracleRepository;

	

	public ResponseEntity<?> getAgingReport(ReportFilterRequest byDateRequest) {
		
		if(byDateRequest.getPlant() == null) {
			
			return new ResponseEntity(new ApiResponse(false, "Plant is mandatory! Please choose" ),
					HttpStatus.BAD_REQUEST);
		}
		
       /* if(byDateRequest.getVendor_code() == null) {
			
			return new ResponseEntity(new ApiResponse(false, "Vendor is mandatory! Please choose vendor" ),
					HttpStatus.BAD_REQUEST);
		}*/

		List<VendorAgingOracle> list = null;
		SCAUtil scaUtil = new SCAUtil() ;
		
		try {
			
		String fromDate = byDateRequest.getFromDate() != null ? byDateRequest.getFromDate().replaceAll("-", "") : "";
		String toDate = byDateRequest.getToDate() != null ? byDateRequest.getToDate().replaceAll("-", "") : "";
		String plant = byDateRequest.getPlant();
		String vendor_code = byDateRequest.getVendor_code();
			
			list = vendorAgingOracleRepository.findLatestAging(fromDate, vendor_code, plant , toDate);

		} catch (Exception e) {
			
			logger.info("***************** Unable to get vendor aging details *********************\n" + e);
			
			String msg = scaUtil.getErrorMessage(e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable get vendor aging  details!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<VendorAgingOracle>();
			
		}

		return new ResponseEntity(list, HttpStatus.OK);

	}

}
