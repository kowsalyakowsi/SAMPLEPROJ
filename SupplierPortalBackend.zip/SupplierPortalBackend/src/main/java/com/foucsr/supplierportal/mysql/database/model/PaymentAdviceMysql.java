package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PAYMENT_ADVICE")
public class PaymentAdviceMysql {

	@Id	
	@Column(name = "HEADER_ID")
	private Long header_id;
	
	@Column(name = "PO_NUM")
	private String po_num;
	
	@Column(name = "INV_ID")
	private String inv_id;
	
	@Column(name = "CLR_DOC_NO")
	private String clr_doc_no;	
	
	@Column(name = "VENDOR_ID")
	private String vendor_id;
	
	@Column(name = "COM_CODE")
	private String com_code;
	
	@Column(name = "PYMT_DOC_NO")
	private String pymt_doc_no;
	
	@Column(name = "PYMT_DATE")
	private String pymt_date;
	
	@Column(name = "PYMT_AMNT")
	private Double pymt_amnt;
	
	@Column(name = "PYMT_ADV_NO")
	private String pymt_adv_no;
	
	@Column(name = "PYMT_ADV_DATE")
	private String pymt_adv_date;
	
	@Column(name = "PYMNT_ADV_LINE")
	private Long pymnt_adv_line;
	
	@Column(name = "ACC_DOC_NO")
	private String acc_doc_no;
	
	@Column(name = "NET_PYMNT_AMNT")
	private Double net_pymnt_amnt;
	
	@Column(name = "PSTAT")
	private String pstat;

	public Long getHeader_id() {
		return header_id;
	}

	public void setHeader_id(Long header_id) {
		this.header_id = header_id;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public String getInv_id() {
		return inv_id;
	}

	public void setInv_id(String inv_id) {
		this.inv_id = inv_id;
	}

	public String getClr_doc_no() {
		return clr_doc_no;
	}

	public void setClr_doc_no(String clr_doc_no) {
		this.clr_doc_no = clr_doc_no;
	}

	public String getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(String vendor_id) {
		this.vendor_id = vendor_id;
	}

	public String getCom_code() {
		return com_code;
	}

	public void setCom_code(String com_code) {
		this.com_code = com_code;
	}

	public String getPymt_doc_no() {
		return pymt_doc_no;
	}

	public void setPymt_doc_no(String pymt_doc_no) {
		this.pymt_doc_no = pymt_doc_no;
	}

	public String getPymt_date() {
		return pymt_date;
	}

	public void setPymt_date(String pymt_date) {
		this.pymt_date = pymt_date;
	}

	public Double getPymt_amnt() {
		return pymt_amnt;
	}

	public void setPymt_amnt(Double pymt_amnt) {
		this.pymt_amnt = pymt_amnt;
	}

	public String getPymt_adv_no() {
		return pymt_adv_no;
	}

	public void setPymt_adv_no(String pymt_adv_no) {
		this.pymt_adv_no = pymt_adv_no;
	}

	public String getPymt_adv_date() {
		return pymt_adv_date;
	}

	public void setPymt_adv_date(String pymt_adv_date) {
		this.pymt_adv_date = pymt_adv_date;
	}

	public Long getPymnt_adv_line() {
		return pymnt_adv_line;
	}

	public void setPymnt_adv_line(Long pymnt_adv_line) {
		this.pymnt_adv_line = pymnt_adv_line;
	}

	public String getAcc_doc_no() {
		return acc_doc_no;
	}

	public void setAcc_doc_no(String acc_doc_no) {
		this.acc_doc_no = acc_doc_no;
	}

	public Double getNet_pymnt_amnt() {
		return net_pymnt_amnt;
	}

	public void setNet_pymnt_amnt(Double net_pymnt_amnt) {
		this.net_pymnt_amnt = net_pymnt_amnt;
	}

	public String getPstat() {
		return pstat;
	}

	public void setPstat(String pstat) {
		this.pstat = pstat;
	}
	
		
}