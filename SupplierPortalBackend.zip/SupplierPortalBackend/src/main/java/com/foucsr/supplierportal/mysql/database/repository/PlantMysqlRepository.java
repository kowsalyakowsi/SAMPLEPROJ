package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PlantMysql;

@Repository
public interface PlantMysqlRepository extends CrudRepository<PlantMysql, String> {
	   


    @Query(value = "select * from PLANT_TBL where PLANT =:plant ", nativeQuery = true)
    PlantMysql getPlantByPlant(@Param("plant") String plant);
    
    @Query(value = "select * from PLANT_TBL", nativeQuery = true)
    List<PlantMysql> getAllPlants();


}