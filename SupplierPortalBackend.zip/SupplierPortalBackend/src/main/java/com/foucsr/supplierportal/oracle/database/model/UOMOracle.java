package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class UOMOracle {

	private Long id;

	private String unit_of_measure;

	private String uom_code;

	private String uom_class;

	private String base_uom_flag;

	private String unit_of_measure_tl;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date disable_date;

	private String description;

	private String language;

	private String source_lang;

	private String poProcessStatus;

	public UOMOracle() {

	}

	public String getUnit_of_measure() {
		return unit_of_measure;
	}

	public void setUnit_of_measure(String unit_of_measure) {
		this.unit_of_measure = unit_of_measure;
	}

	public String getUom_code() {
		return uom_code;
	}

	public void setUom_code(String uom_code) {
		this.uom_code = uom_code;
	}

	public String getUom_class() {
		return uom_class;
	}

	public void setUom_class(String uom_class) {
		this.uom_class = uom_class;
	}

	public String getBase_uom_flag() {
		return base_uom_flag;
	}

	public void setBase_uom_flag(String base_uom_flag) {
		this.base_uom_flag = base_uom_flag;
	}

	public String getUnit_of_measure_tl() {
		return unit_of_measure_tl;
	}

	public void setUnit_of_measure_tl(String unit_of_measure_tl) {
		this.unit_of_measure_tl = unit_of_measure_tl;
	}

	public Date getDisable_date() {
		return disable_date;
	}

	public void setDisable_date(Date disable_date) {
		this.disable_date = disable_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getSource_lang() {
		return source_lang;
	}

	public void setSource_lang(String source_lang) {
		this.source_lang = source_lang;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}