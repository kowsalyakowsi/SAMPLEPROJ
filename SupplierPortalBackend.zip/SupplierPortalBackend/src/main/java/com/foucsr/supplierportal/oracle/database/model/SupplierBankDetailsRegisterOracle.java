package com.foucsr.supplierportal.oracle.database.model;

public class SupplierBankDetailsRegisterOracle {

	private Long stg_hdr_id;

	private String bank_num;

	private String branch_type;

	private String ifsc;

	private String swift_code;

	private String bic;

	private String account_num;

	private String account_name;

	private String check_digits;

	private String currency_code;

	private String notes;

	private Long created_by;

	private Long last_updated_by;

	private String bank_name;

	private String status;
	
	private String branch_name;
	
	private String country_code;

	public String getBank_num() {
		return bank_num;
	}

	public void setBank_num(String bank_num) {
		this.bank_num = bank_num;
	}

	public String getBranch_type() {
		return branch_type;
	}

	public void setBranch_type(String branch_type) {
		this.branch_type = branch_type;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getSwift_code() {
		return swift_code;
	}

	public void setSwift_code(String swift_code) {
		this.swift_code = swift_code;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getAccount_num() {
		return account_num;
	}

	public void setAccount_num(String account_num) {
		this.account_num = account_num;
	}

	public String getAccount_name() {
		return account_name;
	}

	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}

	public String getCheck_digits() {
		return check_digits;
	}

	public void setCheck_digits(String check_digits) {
		this.check_digits = check_digits;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getCreated_by() {
		return created_by;
	}

	public void setCreated_by(Long created_by) {
		this.created_by = created_by;
	}


	public Long getStg_hdr_id() {
		return stg_hdr_id;
	}

	public void setStg_hdr_id(Long stg_hdr_id) {
		this.stg_hdr_id = stg_hdr_id;
	}

	public String getBranch_name() {
		return branch_name;
	}

	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

}
