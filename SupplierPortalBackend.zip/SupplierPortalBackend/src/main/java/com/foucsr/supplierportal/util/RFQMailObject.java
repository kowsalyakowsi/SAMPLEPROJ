package com.foucsr.supplierportal.util;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;



public class RFQMailObject {
	
	private String rfq_number;
	
	private String agent_name;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date rfq_close_date;
	
	private String user_name;
	
	private String item_name;
	
	private String item_description;
	
	private double quantity;
	
	private double price_override;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date start_date;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_date;

	private double price_discount;
	
	private String organization;
	
	private String ship_to_location;

	public String getRfq_number() {
		return rfq_number;
	}

	public void setRfq_number(String rfq_number) {
		this.rfq_number = rfq_number;
	}

	public String getAgent_name() {
		return agent_name;
	}

	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}

	public Date getRfq_close_date() {
		return rfq_close_date;
	}

	public void setRfq_close_date(Date rfq_close_date) {
		this.rfq_close_date = rfq_close_date;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getPrice_override() {
		return price_override;
	}

	public void setPrice_override(double price_override) {
		this.price_override = price_override;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public double getPrice_discount() {
		return price_discount;
	}

	public void setPrice_discount(double price_discount) {
		this.price_discount = price_discount;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getShip_to_location() {
		return ship_to_location;
	}

	public void setShip_to_location(String ship_to_location) {
		this.ship_to_location = ship_to_location;
	}
	

}
