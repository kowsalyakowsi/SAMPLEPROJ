package com.foucsr.supplierportal.payload;

public class DeleteUserRequest {
   
    private Long id;
    
    private char is_Active;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public char getIs_Active() {
		return is_Active;
	}

	public void setIs_Active(char is_Active) {
		this.is_Active = is_Active;
	}

	
    
    
		
}

