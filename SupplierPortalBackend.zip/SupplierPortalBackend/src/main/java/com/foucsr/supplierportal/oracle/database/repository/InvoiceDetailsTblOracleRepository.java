package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class InvoiceDetailsTblOracleRepository  {
	   
//
//    @Query(value = "select * from XXAP_INVOICE_DETAILS_TBL where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<InvoiceDetailsTblOracle> findByFirstNameAndLastName();

   
}