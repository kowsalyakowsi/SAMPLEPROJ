package com.foucsr.supplierportal.payload;

public class AsnResponse {
   
	private String asn;


	public AsnResponse(String asn) {
		super();
		this.asn = asn;

	}
	
	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}
	
}