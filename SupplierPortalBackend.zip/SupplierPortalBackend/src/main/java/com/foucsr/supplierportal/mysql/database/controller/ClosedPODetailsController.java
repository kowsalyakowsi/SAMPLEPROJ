package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.ClosedPODetails;
import com.foucsr.supplierportal.mysql.database.model.ClosedPOStatusListProjection;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;
import com.foucsr.supplierportal.mysql.database.service.ClosedPODetailsService;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@RestController
@RequestMapping("/ClosedPODetails/Service")
@CrossOrigin
public class ClosedPODetailsController {

	@Autowired
	private ClosedPODetailsService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("")
	public ResponseEntity<?> createNewProject(@Valid @RequestBody ClosedPODetails project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		ClosedPODetails project1 = projectService.saveOrUpdateProject(project, principal.getName());
		return new ResponseEntity<ClosedPODetails>(project1, HttpStatus.CREATED);
	}

	@GetMapping("/{projectId}")
	public ResponseEntity<?> getProjectById(@PathVariable long projectId, Principal principal) {

		Optional<ClosedPODetails> project = projectService.findProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<Optional<ClosedPODetails>>(project, HttpStatus.OK);
	}

	@GetMapping("/all")
	public Iterable<ClosedPODetails> getAllProjects(Principal principal) {
		return projectService.findAllProjects(principal.getName());
	}

	@DeleteMapping("/{projectId}")
	public ResponseEntity<?> deleteProject(@PathVariable long projectId, Principal principal) {
		projectService.deleteProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<String>("Project with ID: '" + projectId + "' was deleted", HttpStatus.OK);
	}
	
	@PostMapping("/getClosedPoByDate")
	public List<ClosedPODetails> getClosedPoByDate(@Valid @RequestBody GetOpenPoByDateRequest byDateRequest,
			Principal principal) {
		return projectService.getClosedPoByDate(byDateRequest);

	}
	
	@GetMapping("/getAllDistinctClosedPOStatus")
    public List<ClosedPOStatusListProjection> getDistinctOuName(){

    	return projectService.findDistinctClosedPOStatus();
    }
}
