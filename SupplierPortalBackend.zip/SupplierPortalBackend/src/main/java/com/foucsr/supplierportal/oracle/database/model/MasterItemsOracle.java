package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class MasterItemsOracle {

	private Long id;

	private long inv_item_id;

	private long organization_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date start_date_active;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_date_active;

	private String description;

	private String segment1;

	private String purchase_item_flag;

	private String purchase_enable_flag;

	private String uom_code;

	private String uom_measure;

	private String poProcessStatus;

	public MasterItemsOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getInv_item_id() {
		return inv_item_id;
	}

	public void setInv_item_id(long inv_item_id) {
		this.inv_item_id = inv_item_id;
	}

	public long getOrganization_id() {
		return organization_id;
	}

	public void setOrganization_id(long organization_id) {
		this.organization_id = organization_id;
	}

	public Date getStart_date_active() {
		return start_date_active;
	}

	public void setStart_date_active(Date start_date_active) {
		this.start_date_active = start_date_active;
	}

	public Date getEnd_date_active() {
		return end_date_active;
	}

	public void setEnd_date_active(Date end_date_active) {
		this.end_date_active = end_date_active;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getPurchase_item_flag() {
		return purchase_item_flag;
	}

	public void setPurchase_item_flag(String purchase_item_flag) {
		this.purchase_item_flag = purchase_item_flag;
	}

	public String getPurchase_enable_flag() {
		return purchase_enable_flag;
	}

	public void setPurchase_enable_flag(String purchase_enable_flag) {
		this.purchase_enable_flag = purchase_enable_flag;
	}

	public String getUom_code() {
		return uom_code;
	}

	public void setUom_code(String uom_code) {
		this.uom_code = uom_code;
	}

	public String getUom_measure() {
		return uom_measure;
	}

	public void setUom_measure(String uom_measure) {
		this.uom_measure = uom_measure;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

}