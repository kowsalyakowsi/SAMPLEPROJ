package com.foucsr.supplierportal.mysql.database.model;

import java.util.List;

public class ServiceRelatedObjects {

	private List<AgentListProjection> buyers;

	private List<SupplierSites> supplier_sites;

	private List<MasterOrganizations> organizations;

	private List<OperatingUnits> operatingUnits;

	private List<Locations> locations;

	private List<POLineTypes> lineTypes;
	
	private List<Currencies> currencies;
	
	List<ApSuppliers> suppliers;
	
	List<PurchasingCategory> categories;

	public List<AgentListProjection> getBuyers() {
		return buyers;
	}

	public void setBuyers(List<AgentListProjection> buyers) {
		this.buyers = buyers;
	}

	public List<SupplierSites> getSupplier_sites() {
		return supplier_sites;
	}

	public void setSupplier_sites(List<SupplierSites> supplier_sites) {
		this.supplier_sites = supplier_sites;
	}

	public List<MasterOrganizations> getOrganizations() {
		return organizations;
	}

	public void setOrganizations(List<MasterOrganizations> organizations) {
		this.organizations = organizations;
	}

	public List<OperatingUnits> getOperatingUnits() {
		return operatingUnits;
	}

	public void setOperatingUnits(List<OperatingUnits> operatingUnits) {
		this.operatingUnits = operatingUnits;
	}

	public List<Locations> getLocations() {
		return locations;
	}

	public void setLocations(List<Locations> locations) {
		this.locations = locations;
	}

	public List<POLineTypes> getLineTypes() {
		return lineTypes;
	}

	public void setLineTypes(List<POLineTypes> lineTypes) {
		this.lineTypes = lineTypes;
	}

	public List<Currencies> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(List<Currencies> currencies) {
		this.currencies = currencies;
	}

	public List<ApSuppliers> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<ApSuppliers> suppliers) {
		this.suppliers = suppliers;
	}

	public List<PurchasingCategory> getCategories() {
		return categories;
	}

	public void setCategories(List<PurchasingCategory> categories) {
		this.categories = categories;
	}

}
