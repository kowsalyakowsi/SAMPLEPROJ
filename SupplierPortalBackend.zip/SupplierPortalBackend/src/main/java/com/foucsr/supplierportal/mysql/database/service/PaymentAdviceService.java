package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.PaymentAdviceMysql;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.PaymentAdviceMysqlRepository;
import com.foucsr.supplierportal.oracle.database.model.PaymentAdviceOracle;
import com.foucsr.supplierportal.oracle.database.repository.PaymentAdviceOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.util.SCAUtil;

@Service
public class PaymentAdviceService {

	Logger logger = LoggerFactory.getLogger(PaymentAdviceService.class);
	
	@Autowired
	private PaymentAdviceMysqlRepository paymentAdviceMysqlRepository;
	
	@Autowired
   	private PaymentAdviceOracleRepository paymentAdviceOracleRepository;
	
	@Autowired
	private ApSuppliersRepository apSuppliersMysqlRepository;

	public ResponseEntity<?> getPaymentAdviceList(ReportFilterRequest byDateRequest) {

		List<PaymentAdviceOracle> list = null;
		SCAUtil scaUtil = new SCAUtil() ;
		
		if(byDateRequest.getVendorId() == null) {
			
			return new ResponseEntity(new ApiResponse(false, "Vendor Id is mandatory!" ),
					HttpStatus.BAD_REQUEST);
		}

		String vendor_id = byDateRequest.getVendorId().toString();
		
		try {
			
		ApSuppliers supplier = apSuppliersMysqlRepository.findByVendorIDId(vendor_id);
		
		String vendor_code = supplier.getVendor_code();
		
		String fromDate = byDateRequest.getFromDate() != null ? byDateRequest.getFromDate().replaceAll("-", "") : "";
		String toDate = byDateRequest.getToDate() != null ? byDateRequest.getToDate().replaceAll("-", "") : "";
		
			
//			list =  paymentAdviceMysqlRepository.getpaymentAdviceByVendor(vendor_id);
			
			
			list = paymentAdviceOracleRepository.findLatestPaymentAdvice(fromDate, toDate , vendor_code);

		} catch (Exception e) {
			
			logger.info("***************** Unable to get payment advice details *********************\n" + e);
			
			String msg = scaUtil.getErrorMessage(e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable get payment advice details!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<PaymentAdviceOracle>();
			
		}

		return new ResponseEntity(list, HttpStatus.OK);

	}

}
