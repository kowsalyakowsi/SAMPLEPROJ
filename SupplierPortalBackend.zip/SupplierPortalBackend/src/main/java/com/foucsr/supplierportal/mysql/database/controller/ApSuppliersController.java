package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;
import com.foucsr.supplierportal.mysql.database.service.ApSuppliersService;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;

@RestController
@RequestMapping("/ApSuppliers/Service")
@CrossOrigin
public class ApSuppliersController {

	@Autowired
	private ApSuppliersService projectService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("")
	public ResponseEntity<?> createNewProject(@Valid @RequestBody ApSuppliers project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		ApSuppliers project1 = projectService.saveOrUpdateProject(project, principal.getName());
		return new ResponseEntity<ApSuppliers>(project1, HttpStatus.CREATED);
	}

	@GetMapping("/{projectId}")
	public ResponseEntity<?> getProjectById(@PathVariable long projectId, Principal principal) {

		Optional<ApSuppliers> project = projectService.findProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<Optional<ApSuppliers>>(project, HttpStatus.OK);
	}

	@GetMapping("/all")
	public Iterable<ApSuppliers> getAllProjects(Principal principal) {
		return projectService.findAllProjects(principal.getName());
	}

	@DeleteMapping("/{projectId}")
	public ResponseEntity<?> deleteProject(@PathVariable long projectId, Principal principal) {
		projectService.deleteProjectByIdentifier(projectId, principal.getName());

		return new ResponseEntity<String>("Project with ID: '" + projectId + "' was deleted", HttpStatus.OK);
	}

	/*@GetMapping("/getAllDistinctVendorID")
	public ResponseEntity<?> getDistinctOuName() {

		List<String> listOfOuName = projectService.findAllByVendorID();

		List<ApSuppliersResponse> listOfVendorMap = new ArrayList<ApSuppliersResponse>();
		ApSuppliersResponse vendorMap = null;

		for (Object str : listOfOuName) {
			vendorMap = new ApSuppliersResponse();
			vendorMap.setVendor_id(((Object[]) str)[0].toString());
			vendorMap.setVendor_name(((Object[]) str)[1].toString());
			listOfVendorMap.add(vendorMap);

		}
		return new ResponseEntity<List<ApSuppliersResponse>>(listOfVendorMap, HttpStatus.OK);
	}*/

  @GetMapping("/getAllDistinctVendorID")
    public List<SupplierListProjection> getDistinctOuName(){

    	return projectService.findAllByVendorID();
    }
  
  @GetMapping("/getAll")
  public Iterable<ApSuppliers> getAll(){

  	return projectService.findAllProjects("");
  }
}
