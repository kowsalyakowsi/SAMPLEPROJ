package com.foucsr.supplierportal.payload;

import java.util.List;

/**
 * Created by FocusR on 26-Mar-2020.
 */

public class SendRegistraionRequest {

	private List<String> emails;

	private String registrationUrl;

	public List<String> getEmails() {
		return emails;
	}

	public void setEmails(List<String> emails) {
		this.emails = emails;
	}

	public String getRegistrationUrl() {
		return registrationUrl;
	}

	public void setRegistrationUrl(String registrationUrl) {
		this.registrationUrl = registrationUrl;
	}

}
