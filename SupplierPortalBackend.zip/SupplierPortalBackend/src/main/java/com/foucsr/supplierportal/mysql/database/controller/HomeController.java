package com.foucsr.supplierportal.mysql.database.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@RequestMapping(value = "/")
	public String homeDefault(ModelMap modelMap) {

		return "index";
	}
	

	@RequestMapping(value = "/index")
	public String homePage(ModelMap modelMap) {

		return "index";
	}

	@RequestMapping(value = "/dashboard")
	public String dashBoard(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/openpo")
	public String openpo(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/closedpo")
	public String closedpo(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/rejectedpo")
	public String rejectedpo(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/ack")
	public String ack(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/rescheduledpo")
	public String rescheduledpo(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/asn")
	public String asn(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/asnshipmentstatus")
	public String asnshipmentstatus(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/rtv")
	public String rtv(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/invoicedetails")
	public String invoicedetails(ModelMap modelMap) {

		return "index";
	}
	@RequestMapping(value = "/paymentdetails")
	public String paymentdetails(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/buyer")
	public String buyer(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/uploadinvoice")
	public String uploadInvoice(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/exportdetails")
	public String exportDetails(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/statistics")
	public String statistics(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/buyeropenpo")
	public String buyerOpenpo(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/buyerapproval")
	public String buyerApproval(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/mastercontrol")
	public String masterControl(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/createusers")
	public String createUsers(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/viewerrorlogs")
	public String viewErrorLogs(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/definescreenaccess")
	public String defineScreenAccess(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/resetPwd/{token}")
	public String forgetPassword(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/rfq")
	public String rfq(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/quotation")
	public String quotation(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/register/{register}")
	public String register(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/supplierCreation")
	public String supplierCreation(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/financeDashboard")
	public String financeDashboard(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/shipmentStatus")
	public String shipmentStatus(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/financeCreditorAnalysis")
	public String financeCreditorAnalysis(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/CashflowForecasting")
	public String CashflowForecasting(ModelMap modelMap) {

		return "index";
	}
	
	@RequestMapping(value = "/vendorInvoiceAndDoStatus")
	public String vendorInvoiceAndDoStatus(ModelMap modelMap) {

		return "index";
	}
	
}