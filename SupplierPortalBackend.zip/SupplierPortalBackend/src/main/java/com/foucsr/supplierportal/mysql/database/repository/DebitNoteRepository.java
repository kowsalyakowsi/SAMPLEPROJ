package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.DebitNote;

@Repository
public interface DebitNoteRepository extends CrudRepository<DebitNote, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<DebitNote> findAll();
    
    @Query(value = "select * from DEBIT_INVOICES where vendor_id = :vendorId order by INVOICE_NUMBER", nativeQuery = true)
    List<DebitNote> getDebitInvoicesByVendorId(@Param("vendorId") Long vendorId );
    
    
    
    @Query(value = "select * from DEBIT_INVOICES where  VENDOR_ID =:vendorId and INVOICE_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by INVOICE_NUMBER", nativeQuery = true)
    List<DebitNote> getDebitInvoicesByDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") Long vendorId);
    

    
    @Query(value = "select * from DEBIT_INVOICES where  PO_NUMBER = :poNum  AND VENDOR_ID =:vendorId and INVOICE_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by INVOICE_NUMBER", nativeQuery = true)
    List<DebitNote> getDebitInvoicesByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") Long vendorId , @Param("poNum") String poNum);
    
    
    
    @Query(value = "select * from DEBIT_INVOICES where  PO_NUMBER = :poNum  AND VENDOR_ID =:vendorId order by INVOICE_NUMBER", nativeQuery = true)
    List<DebitNote> getDebitInvoicesByPO(@Param("vendorId") Long vendorId , @Param("poNum") String poNum);
    
    
    
}