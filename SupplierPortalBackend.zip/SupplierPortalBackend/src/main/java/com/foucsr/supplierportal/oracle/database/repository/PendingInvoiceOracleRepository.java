package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class PendingInvoiceOracleRepository  {	  
//    
//    @Query(value = "select * from XX_PARTIAL_RECEIPTS where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<PendingInvoiceOracle> findAllPendingInvoice();
   
}