package com.foucsr.supplierportal.mysql.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;

@Service
public class ApSuppliersService {

	@Autowired
	private ApSuppliersRepository apsuppliersrepository;

	public ApSuppliers saveOrUpdateProject(ApSuppliers apSuppliers, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return apsuppliersrepository.save(apSuppliers);

	}

	public Optional<ApSuppliers> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<ApSuppliers> apSuppliers = apsuppliersrepository.findById(id);

		return apSuppliers;
	}

	public Iterable<ApSuppliers> findAllProjects(String username) {
		return apsuppliersrepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		apsuppliersrepository.deleteById(id);
	}

	public ApSuppliers findByVendorID(String vendorID) {

		ApSuppliers findVendorId = apsuppliersrepository.findByVendorIDId(vendorID);

		return findVendorId;
	}
	public List<SupplierListProjection> findAllByVendorID() {

		return apsuppliersrepository.findDistinctByVendorID(); 
	}
}
