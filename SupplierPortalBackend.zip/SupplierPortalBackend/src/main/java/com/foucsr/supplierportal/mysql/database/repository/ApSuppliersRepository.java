package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;

@Repository
public interface ApSuppliersRepository extends CrudRepository<ApSuppliers, Long> {
	   
	
    @Override
    Iterable<ApSuppliers> findAll();
    
    
    @Query(value = "select * from  AP_SUPPLIERS where VENDOR_ID=:vendorID ", nativeQuery = true)
    ApSuppliers findByVendorIDId(@Param("vendorID") String vendorID);
	
    @Query(value = "select VENDOR_ID,VENDOR_NAME , VENDOR_CODE from  AP_SUPPLIERS order by VENDOR_NAME", nativeQuery = true)
    List<SupplierListProjection> findDistinctByVendorID();

   
}