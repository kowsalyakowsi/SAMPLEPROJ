package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PendingInvoice;

@Repository
public interface PendingInvoiceRepository extends CrudRepository<PendingInvoice, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<PendingInvoice> findAll();
    
    @Query(value = "select * from PARTIAL_RECEIPTS where vendor_id = :vendorId order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByVendorId(@Param("vendorId") Long vendorId );
    
    @Query(value = "select * from PARTIAL_RECEIPTS where  VENDOR_ID =:vendorId and PO_CREATION_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") Long vendorId);
    

    @Query(value = "select * from PARTIAL_RECEIPTS where PO_NUMBER = :poNum AND SHIP_TO_ORG = :orgName AND VENDOR_ID =:vendorId and PO_CREATION_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByAllParam(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") Long vendorId,
    		                  @Param("poNum") String poNum , @Param("orgName") String orgName);
    
    
    
    @Query(value = "select * from PARTIAL_RECEIPTS where PO_NUMBER = :poNum AND SHIP_TO_ORG = :orgName AND VENDOR_ID =:vendorId order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByPOOrg(@Param("vendorId") Long vendorId, @Param("poNum") String poNum , @Param("orgName") String orgName);
    
    
    
    @Query(value = "select * from PARTIAL_RECEIPTS where PO_NUMBER = :poNum AND VENDOR_ID =:vendorId order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByPO(@Param("vendorId") Long vendorId, @Param("poNum") String poNum );
    
    
    
    @Query(value = "select * from PARTIAL_RECEIPTS where SHIP_TO_ORG = :orgName AND VENDOR_ID =:vendorId order by PO_NUMBER , PO_LINE_NUMBER", nativeQuery = true)
    List<PendingInvoice> getPendingInvoicesByOrg(@Param("vendorId") Long vendorId, @Param("orgName") String orgName );
 
    
    
    @Query(value = "select distinct SHIP_TO_ORG from  PARTIAL_RECEIPTS where VENDOR_ID=:vendorID order by SHIP_TO_ORG", nativeQuery = true)
    List<String> findDistinctShipToOrg(@Param("vendorID") String vendorID );
    
}