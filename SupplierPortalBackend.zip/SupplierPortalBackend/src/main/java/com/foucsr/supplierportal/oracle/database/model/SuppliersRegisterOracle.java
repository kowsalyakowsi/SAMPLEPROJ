package com.foucsr.supplierportal.oracle.database.model;

public class SuppliersRegisterOracle {

	private Long id;

	private String vendor_name;

	private String vendor_name_alt;

	private Long buyer_id;

	private Long last_updated_by;

	// tax payer id
	private String num_1099;

	private String vat_registration_num;

	private String territory_short_name;

	private String duns;

	private String org_url;

	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_name_alt() {
		return vendor_name_alt;
	}

	public void setVendor_name_alt(String vendor_name_alt) {
		this.vendor_name_alt = vendor_name_alt;
	}

	public Long getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public String getNum_1099() {
		return num_1099;
	}

	public void setNum_1099(String num_1099) {
		this.num_1099 = num_1099;
	}

	public String getVat_registration_num() {
		return vat_registration_num;
	}

	public void setVat_registration_num(String vat_registration_num) {
		this.vat_registration_num = vat_registration_num;
	}

	public String getTerritory_short_name() {
		return territory_short_name;
	}

	public void setTerritory_short_name(String territory_short_name) {
		this.territory_short_name = territory_short_name;
	}

	public String getDuns() {
		return duns;
	}

	public void setDuns(String duns) {
		this.duns = duns;
	}

	public String getOrg_url() {
		return org_url;
	}

	public void setOrg_url(String org_url) {
		this.org_url = org_url;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}