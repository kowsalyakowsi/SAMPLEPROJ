package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQHeader;

@Repository
public interface RFQHeaderRepository extends CrudRepository<RFQHeader, Long> {

	
    @Override
    Iterable<RFQHeader> findAll();
    
    @Query(value = "SELECT * FROM RFQ_HEADERS_ALL  WHERE RFQ_HEADER_ID = :rfqHeaderId", nativeQuery = true)
    RFQHeader findHeader(@Param("rfqHeaderId") Long rfqHeaderId );
    
    @Query(value = "SELECT * FROM RFQ_HEADERS_ALL  WHERE AGENT_ID = :buyerId", nativeQuery = true)
    List<RFQHeader> findHeaders(@Param("buyerId") Long buyerId );
    

}