package com.foucsr.supplierportal.mysql.database.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "USERS_SUPPLIERS_MAP")
public class UsersSuppliersMap {
	@Id
	@SequenceGenerator(name = "USERS_SUPPLIERS_MAP_SEQ", sequenceName = "USERS_SUPPLIERS_MAP_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USERS_SUPPLIERS_MAP_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "USER_ID")
	private String user_id;
	
	@Column(name = "SUPPLIER_ID")
	private String supplier_id;

	public UsersSuppliersMap() {
		
	}

	public UsersSuppliersMap(Long id, String user_id, String supplier_id) {
		this.id = id;
		this.user_id = user_id;
		this.supplier_id = supplier_id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getSupplier_id() {
		return supplier_id;
	}

	public void setSupplier_id(String supplier_id) {
		this.supplier_id = supplier_id;
	}
}