package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class LocationsOracleRepository  {
    
//    @Query(value = "select * from XX_LOCATIONS where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<LocationsOracle> findAllLocations();
   
}