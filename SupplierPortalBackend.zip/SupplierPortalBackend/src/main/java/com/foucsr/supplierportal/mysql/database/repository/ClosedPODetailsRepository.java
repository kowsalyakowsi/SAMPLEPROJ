package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ClosedPODetails;
import com.foucsr.supplierportal.mysql.database.model.ClosedPOStatusListProjection;

@Repository
public interface ClosedPODetailsRepository extends CrudRepository<ClosedPODetails, Long> {
	   
	//Optional<PoAgents> findById(Long id);
	
    @Override
    Iterable<ClosedPODetails> findAll();
    
    @Query(value = "select * from CLOSED_PO_DETAILS where vendor_id = :vendorId order by PO_NUMBER DESC, PO_LINE_NUM ASC, RECEIPT_NUM ASC, INVOICE_NUM ASC", nativeQuery = true)
    List<ClosedPODetails> getClosedPoDetailsByVendorId(@Param("vendorId") String vendorId );
    
    @Query(value = "select * from CLOSED_PO_DETAILS where  VENDOR_ID =:vendorId and INVOICE_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM , RECEIPT_NUM, INVOICE_NUM", nativeQuery = true)
    List<ClosedPODetails> getClosedPoDetailsByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId);
    
    @Query(value = "select * from CLOSED_PO_DETAILS where  VENDOR_ID =:vendorId and po_status =:status and INVOICE_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PO_NUMBER DESC, PO_LINE_NUM , RECEIPT_NUM, INVOICE_NUM", nativeQuery = true)
    List<ClosedPODetails> getClosedPoDetailsByStatusAndDate(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId, @Param("status") String status);
    
    @Query(value = "select * from CLOSED_PO_DETAILS where  VENDOR_ID =:vendorId and po_status =:status order by PO_NUMBER DESC, PO_LINE_NUM, RECEIPT_NUM, INVOICE_NUM", nativeQuery = true)
    List<ClosedPODetails> getClosedPoDetailsByStatus(@Param("vendorId") String vendorId, @Param("status") String status);

    @Query(value = "select distinct po_status from  CLOSED_PO_DETAILS order by po_status", nativeQuery = true)
    List<ClosedPOStatusListProjection> findDistinctClosedPOStatus();
    
    @Query(value = "select * from CLOSED_PO_DETAILS where  ID =:id ", nativeQuery = true)
    ClosedPODetails getClosedPoDetailsById(@Param("id") Long id);
}