package com.foucsr.supplierportal.mysql.database.service;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.exception.ResourceNotFoundException;
import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.Locations;
import com.foucsr.supplierportal.mysql.database.model.MasterItems;
import com.foucsr.supplierportal.mysql.database.model.MasterOrganizations;
import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;
import com.foucsr.supplierportal.mysql.database.model.POLineTypes;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.QuotationLineDetails;
import com.foucsr.supplierportal.mysql.database.model.QuotationLines;
import com.foucsr.supplierportal.mysql.database.model.QuotationPriceBreaks;
import com.foucsr.supplierportal.mysql.database.model.RFQHeader;
import com.foucsr.supplierportal.mysql.database.model.RFQLines;
import com.foucsr.supplierportal.mysql.database.model.RFQPriceBreaks;
import com.foucsr.supplierportal.mysql.database.model.RFQRelatedObjects;
import com.foucsr.supplierportal.mysql.database.model.RFQStatus;
import com.foucsr.supplierportal.mysql.database.model.RFQTypes;
import com.foucsr.supplierportal.mysql.database.model.RFQVendors;
import com.foucsr.supplierportal.mysql.database.model.SupplierSites;
import com.foucsr.supplierportal.mysql.database.model.UOM;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.EmailDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.LocationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterItemsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterOrganizationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OperatingUnitsRepository;
import com.foucsr.supplierportal.mysql.database.repository.POLineTypesRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.QuotationLineDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.QuotationLinesRepository;
import com.foucsr.supplierportal.mysql.database.repository.QuotationPriceBreaksRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQHeaderRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQLinesRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQPriceBreaksRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQStatusRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQTypeRepository;
import com.foucsr.supplierportal.mysql.database.repository.RFQVendorsRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierSitesRepository;
import com.foucsr.supplierportal.mysql.database.repository.UOMRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.security.JwtTokenProvider;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.EmailHtmlLoader;
import com.foucsr.supplierportal.util.EmailSubject;
import com.foucsr.supplierportal.util.QuotationMailObject;
import com.foucsr.supplierportal.util.RFQMailObject;
import com.foucsr.supplierportal.util.SendMail;

@Service
public class RFQService {
	
	Logger logger = LoggerFactory.getLogger(RFQService.class);

	@Autowired
	private MasterItemsRepository masterItemsRepository;

	@Autowired
	private MasterOrganizationsRepository masterOrganizationsRepository;

	@Autowired
	private OperatingUnitsRepository operatingUnitsRepository;

	@Autowired
	private LocationsRepository locationsRepository;

	@Autowired
	private RFQTypeRepository rFQTypeRepository;

	@Autowired
	private RFQStatusRepository rFQStatusRepository;

	@Autowired
	private ApSuppliersRepository apSuppliersRepository;

	@Autowired
	private UOMRepository uOMRepository;

	@Autowired
	private RFQHeaderRepository rFQHeaderRepository;

	@Autowired
	private RFQLinesRepository rFQLinesRepository;

	@Autowired
	private RFQPriceBreaksRepository rFQPriceBreaksRepository;

	@Autowired
	private RFQVendorsRepository rFQVendorsRepository;

	@Autowired
	private PoAgentsRepository poAgentsRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	EmailDetailsRepository emailDetailsRepository;

	@Autowired
	EmailHtmlLoader emailHtmlLoader;

	@Autowired
	QuotationLinesRepository quotationLinesRepository;
	
	@Autowired
	QuotationLineDetailsRepository quotationLineDetailsRepository;
	
	@Autowired
	QuotationPriceBreaksRepository quotationPriceBreaksRepository;
	
	@Autowired
	SupplierSitesRepository supplierSitesRepository;

	@Autowired
	POLineTypesRepository pOLineTypesRepository;
	
	 @Autowired
	 private JwtTokenProvider tokenProvider;

	   
	public RFQRelatedObjects getAllRFQRelatedObjects(long agentId) {

		RFQRelatedObjects rfqObj = new RFQRelatedObjects();

		try {

			List<MasterItems> masetItems = masterItemsRepository.findAllValid();

			List<MasterOrganizations> organizations = masterOrganizationsRepository.findAllValid();

			List<OperatingUnits> operatingUnits = operatingUnitsRepository.findAllValid(agentId);

			List<Locations> locations = locationsRepository.findAllValid();

			List<RFQTypes> rfqTypes = rFQTypeRepository.findAllValid();

			List<RFQStatus> rfqStatus = rFQStatusRepository.findAllValid();

			List<UOM> uoms = uOMRepository.findAllValid();
			
			List<POLineTypes> pOLineTypes = pOLineTypesRepository.findAllPOLineTypes();

			List<ApSuppliers> suppliers = (List<ApSuppliers>) apSuppliersRepository.findAll();

			rfqObj.setMasterItems(masetItems);
			rfqObj.setOrganizations(organizations);
			rfqObj.setOperatingUnits(operatingUnits);
			rfqObj.setLocations(locations);
			rfqObj.setRfqTypes(rfqTypes);
			rfqObj.setRfqStatus(rfqStatus);
			rfqObj.setSuppliers(suppliers);
			rfqObj.setUoms(uoms);
			rfqObj.setpOLineTypes(pOLineTypes);

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ related objects");
		}

		return rfqObj;

	}

	public RFQHeader saveOrUpdateHeader(RFQHeader rfqHeader, String username) {

		setWhoDetails(rfqHeader);

		String agentId = Long.toString(rfqHeader.getAgent_id());

		PoAgents agent = poAgentsRepository.findByAgentId(agentId);

		Locations location = locationsRepository.findLocation(rfqHeader.getShip_to_location_id());

		if (location.getInventory_organization_id() == null) {

			throw new AppException("No organization mapped to this Ship to location  ");
		}

		rfqHeader.setInventory_organization_id(location.getInventory_organization_id());

		try {

			rfqHeader.setAgent_name(agent.getAgentName());

			User user = userRepository.findByUsername(rfqHeader.getUser_name())
					.orElseThrow(() -> new ResourceNotFoundException("User", "username", rfqHeader.getUser_name()));

			if (rfqHeader.getCreatedBy() == null) {

				rfqHeader.setCreatedBy(user.getId());
			}

			rfqHeader.setLast_update_login(user.getId());
			rfqHeader.setLast_updated_by(user.getId());
			
			rfqHeader.setStatus(AppConstants.RFQ_IN_PROCESS);

			rFQHeaderRepository.save(rfqHeader);

			rfqHeader.setRfq_number(rfqHeader.getRfq_header_id().toString());

			rFQHeaderRepository.save(rfqHeader);

			return rfqHeader;

		} catch (Exception e) {
			throw new AppException("Unable to create RFQ Header");
		}

	}

	public Iterable<RFQLines> saveOrUpdateLines(Iterable<RFQLines> rfqLines) {

		User user = null;

		for (RFQLines line : rfqLines) {

			setUpdationdatesForLines(line);

			if (line.getLine_num() == 0) {

				Long maxLineCount = rFQLinesRepository.findMaxLineCount(line.getRfq_header_id());
				maxLineCount = maxLineCount == null ? 1 : maxLineCount + 1;
				line.setLine_num(maxLineCount);

			}

			if (user == null) {

				user = userRepository.findByUsername(line.getUser_name())
						.orElseThrow(() -> new ResourceNotFoundException("User", "username", line.getUser_name()));
			}

			if (line.getCreatedBy() == null) {

				line.setCreatedBy(user.getId());
			}

			line.setLast_update_login(user.getId());
			line.setLast_updated_by(user.getId());
		}

		try {
			return rFQLinesRepository.saveAll(rfqLines);

		} catch (Exception e) {
			throw new AppException("Unable to create RFQ Lines");
		}

	}

	public Iterable<RFQVendors> saveOrUpdateVendors(Iterable<RFQVendors> rfqVendors, String username) {

		try {

			return rFQVendorsRepository.saveAll(rfqVendors);

		} catch (Exception e) {
			throw new AppException("Unable to add vendors to RFQ");
		}

	}

	public List<RFQHeader> getAll(long buyerId) {

		try {

			return rFQHeaderRepository.findHeaders(buyerId);

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ headers");
		}

	}

	public List<RFQLines> getAllLines(long rfqHeaderId) {

		try {

			return rFQLinesRepository.findAllLines(rfqHeaderId);

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ lines");
		}

	}

	private void setWhoDetails(RFQHeader rfqHeader) {

		if (rfqHeader.getCreation_date() == null) {

			rfqHeader.setCreation_date(new Date());
		}

		rfqHeader.setLast_update_date(new Date());

	}

	private void setUpdationdatesForLines(RFQLines rfqLines) {

		if (rfqLines.getCreation_date() == null) {

			rfqLines.setCreation_date(new Date());
		}

		rfqLines.setLast_update_date(new Date());

	}

	private void setUpdationdatesForVendors(RFQVendors vendor) {

		if (vendor.getCreation_date() == null) {

			vendor.setCreation_date(new Date());
		}

		vendor.setLast_update_date(new Date());

	}

	private void setUpdationdatesForPriceBreaks(RFQPriceBreaks rfqPriceBreaks) {

		if (rfqPriceBreaks.getCreation_date() == null) {

			rfqPriceBreaks.setCreation_date(new Date());
		}

		rfqPriceBreaks.setLast_update_date(new Date());

	}
	
	private void setUpdationdatesForQuotationPriceBreaks(QuotationPriceBreaks quotationPriceBreaks , User user) {

		if (quotationPriceBreaks.getCreation_date() == null) {

			quotationPriceBreaks.setCreation_date(new Date());
		}

		quotationPriceBreaks.setLast_update_date(new Date());
		
		if(user != null) {			
			
			if (quotationPriceBreaks.getCreatedBy() == null) {
				
				quotationPriceBreaks.setCreatedBy(user.getId());
			}
			
			quotationPriceBreaks.setLast_update_login(user.getId());
			quotationPriceBreaks.setLast_updated_by(user.getId());
			quotationPriceBreaks.setUser_name(user.getUsername());
		}
		

	}
	
	private void setUpdationdatesForQuotationLines(QuotationLineDetails lines , User user) {

		if (lines.getCreation_date() == null) {

			lines.setCreation_date(new Date());
		}

		lines.setLast_update_date(new Date());
		
		if(user != null) {
			
        if (lines.getCreatedBy() == null) {
				
        	lines.setCreatedBy(user.getId());
	     }

			lines.setLast_update_login(user.getId());
			lines.setLast_updated_by(user.getId());
			lines.setUser_name(user.getUsername());
		}

	}

	public String deleteLine(long rfqHeaderId, long rfqLineId) {

		try {

			RFQLines line = rFQLinesRepository.findLine(rfqHeaderId, rfqLineId);

			if (line != null) {

				rFQLinesRepository.delete(line);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		return AppConstants.Success_Message;

	}

	public List<RFQPriceBreaks> getAllPriceBreaks(long rfqHeaderId, long rfqLineId) {

		try {

			return rFQPriceBreaksRepository.findAllPriceBreaks(rfqHeaderId, rfqLineId);

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ lines");
		}

	}

	public Iterable<RFQPriceBreaks> saveOrUpdatePriceBreaks(Iterable<RFQPriceBreaks> rfqPriceBreaks) {

		User user = null;

		List<QuotationLines> quotationLinesList = new ArrayList<QuotationLines>();

		for (RFQPriceBreaks priceBreakLine : rfqPriceBreaks) {

			setUpdationdatesForPriceBreaks(priceBreakLine);

			if (priceBreakLine.getShipment_num() == 0) {

				Long maxLineCount = rFQPriceBreaksRepository.findMaxLineCount(priceBreakLine.getRfq_header_id(),
						priceBreakLine.getRfq_line_id());
				maxLineCount = maxLineCount == null ? 1 : maxLineCount + 1;
				priceBreakLine.setShipment_num(maxLineCount);

			}

			if (user == null) {

				user = userRepository.findByUsername(priceBreakLine.getUser_name()).orElseThrow(
						() -> new ResourceNotFoundException("User", "username", priceBreakLine.getUser_name()));
			}

			if (priceBreakLine.getCreatedBy() == null) {

				priceBreakLine.setCreatedBy(user.getId());
			}

			priceBreakLine.setLast_update_login(user.getId());
			priceBreakLine.setLast_updated_by(user.getId());

			MasterOrganizations organization = masterOrganizationsRepository
					.findOrganization(priceBreakLine.getShip_to_organization_id());

			if (organization != null) {

				priceBreakLine.setOrganization(organization.getOrganization_code());
			}

			Locations location = locationsRepository.findLocation(priceBreakLine.getShip_to_location_id());

			if (location != null) {

				priceBreakLine.setShip_to_location(location.getLocation_code());
			}

		}

		try {

			rFQPriceBreaksRepository.saveAll(rfqPriceBreaks);

			for (RFQPriceBreaks priceBreakLine : rfqPriceBreaks) {

				QuotationLines lineVendor = getQuotationLineForCreate(priceBreakLine);

				quotationLinesList.add(lineVendor);

			}

			quotationLinesRepository.saveAll(quotationLinesList);

			return rfqPriceBreaks;

		} catch (Exception e) {
			throw new AppException("Unable to create RFQ Price Breaks");
		}

	}

	private QuotationLines getQuotationLineForCreate(RFQPriceBreaks priceBreakLine) {

		QuotationLines lineVendor = new QuotationLines();

		RFQHeader header = rFQHeaderRepository.findHeader(priceBreakLine.getRfq_header_id());

		RFQLines line = rFQLinesRepository.findLine(priceBreakLine.getRfq_header_id(), priceBreakLine.getRfq_line_id());

		BeanUtils.copyProperties(header, lineVendor);
		BeanUtils.copyProperties(priceBreakLine, lineVendor);

		lineVendor.setRfq_line_id(line.getRfq_line_id());
		lineVendor.setLine_num(line.getLine_num());
		lineVendor.setItem_id(line.getItem_id());
		lineVendor.setItem_name(line.getItem_name());
		lineVendor.setItem_description(line.getItem_description());

		return lineVendor;
	}
	
	private QuotationLines getQuotationLineForUpdate(RFQPriceBreaks priceBreakLine) {

		QuotationLines quotationLine = quotationLinesRepository.findLine(priceBreakLine.getRfq_header_id(),
				priceBreakLine.getRfq_line_id(), priceBreakLine.getRfq_line_location_id());

		if (quotationLine != null) {

			quotationLine.setShip_to_organization_id(priceBreakLine.getShip_to_organization_id());
			quotationLine.setOrganization(priceBreakLine.getOrganization());
			quotationLine.setShip_to_location_id(priceBreakLine.getShip_to_location_id());
			quotationLine.setShip_to_location(priceBreakLine.getShip_to_location());
		}

		return quotationLine;
	}


	public RFQPriceBreaks updatePriceBreaks(RFQPriceBreaks rfqPriceBreak) {

		User user = null;

		setUpdationdatesForPriceBreaks(rfqPriceBreak);

		if (user == null) {

			user = userRepository.findByUsername(rfqPriceBreak.getUser_name())
					.orElseThrow(() -> new ResourceNotFoundException("User", "username", rfqPriceBreak.getUser_name()));
		}

		rfqPriceBreak.setLast_update_login(user.getId());
		rfqPriceBreak.setLast_updated_by(user.getId());

		MasterOrganizations organization = masterOrganizationsRepository
				.findOrganization(rfqPriceBreak.getShip_to_organization_id());

		if (organization != null) {

			rfqPriceBreak.setShip_to_organization_id(organization.getOrganization_Id());
			rfqPriceBreak.setOrganization(organization.getOrganization_code());
		}

		Locations location = locationsRepository.findLocation(rfqPriceBreak.getShip_to_location_id());

		if (location != null) {

			rfqPriceBreak.setShip_to_location_id(location.getLocation_Id());
			rfqPriceBreak.setShip_to_location(location.getLocation_code());
		}

		try {
			RFQPriceBreaks rfqPriceBreakSave = rFQPriceBreaksRepository.save(rfqPriceBreak);
			
			QuotationLines quotationLines = getQuotationLineForUpdate(rfqPriceBreak);
			
			if(quotationLines != null) {
				
				quotationLinesRepository.save(quotationLines);
			}

			return rfqPriceBreakSave;
			
		} catch (Exception e) {
			throw new AppException("Unable to create RFQ Price Breaks");
		}		

	}

	public String deletePriceBreak(long rfqHeaderId, long rfqLineId, long rfq_line_location_id) {

		try {

			RFQPriceBreaks line = rFQPriceBreaksRepository.findPriceBreak(rfqHeaderId, rfqLineId, rfq_line_location_id);

			if (line != null) {

				rFQPriceBreaksRepository.delete(line);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		return AppConstants.Success_Message;

	}

	public List<RFQVendors> getAllSuppliers(long rfqHeaderId) {

		try {

			return rFQVendorsRepository.findAllVendors(rfqHeaderId);

		} catch (Exception e) {
			throw new AppException("Unable to get RFQ Vendors");
		}

	}

	public Iterable<RFQVendors> saveOrUpdateVendors(Iterable<RFQVendors> vendors) {

		User user = null;

		for (RFQVendors vendor : vendors) {

			List<RFQVendors> org_vendor_list = rFQVendorsRepository.findAllVendors(vendor.getRfq_header_id());

			List<RFQVendors> sub_vendor_list = org_vendor_list.stream()
					.filter(p -> p.getVendor_id() == vendor.getVendor_id()).collect(Collectors.toList());

			if (sub_vendor_list != null && sub_vendor_list.size() > 0) {

				throw new AppException("Duplicate Vendor");
			}

			setUpdationdatesForVendors(vendor);

			if (vendor.getSequence_num() == 0) {

				Integer maxLineCount = rFQVendorsRepository.findMaxLineCount(vendor.getRfq_header_id());
				maxLineCount = maxLineCount == null ? 1 : maxLineCount + 1;
				vendor.setSequence_num(maxLineCount);

			}

			if (user == null) {

				user = userRepository.findByUsername(vendor.getUser_name())
						.orElseThrow(() -> new ResourceNotFoundException("User", "username", vendor.getUser_name()));
			}

			ApSuppliers supplier = apSuppliersRepository.findByVendorIDId(Long.toString(vendor.getVendor_id()));

			String vendorName = supplier.getVendor_name();

			List<SupplierSites> sites = supplier.getSites().stream()
					.filter(p -> p.getVendor_site_id() == vendor.getVendor_site_id()).collect(Collectors.toList());

			String siteName = new String();

			if (sites != null && sites.size() > 0) {

				siteName = sites.get(0).getVendor_site_code();
			}

			vendor.setSite_name(siteName);
			vendor.setVendor_name(vendorName);

			if (vendor.getCreatedBy() == null) {

				vendor.setCreatedBy(user.getId());
			}

			vendor.setLast_update_login(user.getId());
			vendor.setLast_updated_by(user.getId());
		}

		try {
			return rFQVendorsRepository.saveAll(vendors);

		} catch (Exception e) {
			throw new AppException("Unable to create RFQ vendors");
		}

	}

	public String deleteVendor(long rfqHeaderId, long vendorId) {

		try {

			RFQVendors vendor = rFQVendorsRepository.findVendor(rfqHeaderId, vendorId);

			if (vendor != null) {

				rFQVendorsRepository.delete(vendor);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		return AppConstants.Success_Message;

	}

	public String updateActive(long rfqHeaderId , HttpServletRequest request) {

		try {

			RFQHeader rfqHeader = rFQHeaderRepository.findHeader(rfqHeaderId);

			if (rfqHeader != null && AppConstants.RFQ_IN_PROCESS.equals(rfqHeader.getStatus())) {


				if (rfqHeader.getRfqVendors() != null && rfqHeader.getRfqVendors().size() > 0) {

					
					sendMailToVendors(rfqHeader ,  request);
				}

				rfqHeader.setStatus(AppConstants.rfq_Active_Status);
				
				rFQHeaderRepository.save(rfqHeader);
				
				// after active the RFQ , the same active process in respective supplier side				
				List<QuotationLines> lines = quotationLinesRepository.findAllQuotationLinesToActive(rfqHeaderId);
				
				for(QuotationLines quotLine : lines) {
					
					quotLine.setStatus(AppConstants.rfq_Active_Status);
				}
				
				quotationLinesRepository.saveAll(lines);

			}

		} catch (Exception e) {
			throw new AppException("Unable to send notification");
		}

		return AppConstants.Success_Message;

	}

	public String sendMailToVendors(RFQHeader rfqHeader , HttpServletRequest request) {

		try {

			List<RFQMailObject> rfqMailObjects = new ArrayList<RFQMailObject>();

			if (rfqHeader != null) {

				List<RFQLines> rfqLines = rFQLinesRepository.findAllLines(rfqHeader.getRfq_header_id());

				if (rfqLines != null && rfqLines.size() > 0) {

					for (RFQLines line : rfqLines) {

						List<RFQPriceBreaks> rfqPriceBreaks = rFQPriceBreaksRepository
								.findAllPriceBreaks(rfqHeader.getRfq_header_id(), line.getRfq_line_id());

						if (rfqPriceBreaks != null && rfqPriceBreaks.size() > 0) {

							for (RFQPriceBreaks rfqPriceBreak : rfqPriceBreaks) {

								RFQMailObject rfqMailObj = new RFQMailObject();
								BeanUtils.copyProperties(rfqHeader, rfqMailObj);
								BeanUtils.copyProperties(line, rfqMailObj);
								BeanUtils.copyProperties(rfqPriceBreak, rfqMailObj);

								rfqMailObjects.add(rfqMailObj);
							}

						}
					}

				}

			}

			if (rfqMailObjects != null && rfqMailObjects.size() > 0) {

				try{
				    sendRFQMailByBuyer(rfqMailObjects, rfqHeader.getRfqVendors() ,  request);
				}catch(Exception ex) {
					logger.info("***************** Unable to send mail *********************\n" + ex);
					throw new AppException("Unable to send notification");
				}
			}

		} catch (Exception e) {
			logger.info("***************** Unable to get details to send mail *********************\n" + e);
			throw new AppException("Unable to send notification");
		}

		return AppConstants.Success_Message;

	}

	private void sendRFQMailByBuyer(List<RFQMailObject> list, List<RFQVendors> vendors , HttpServletRequest request) {

		if (list != null && list.size() > 0 && vendors != null && vendors.size() > 0) {

			RFQMailObject rfqObj = list.get(0);

			String userName = rfqObj.getUser_name();

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User buyer = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();

			String subject = new String();

			subject = AppConstants.buyerRFQSubject.replace("??", userName);

			String text = emailHtmlLoader.loadRFQBuyerText(list);

			emailFrom = buyer.getEmail();
			
			for(RFQVendors vendor : vendors) {
				
				
				long vendorID = vendor.getVendor_id();
				
				List<User> agents = userRepository.findByVendorId(vendorID);
				
				// add first one for to mail and others for cc
				emailTo.add(agents.get(0).getEmail());
				
				for (User agent : agents) {
					
					if (agent == agents.get(0))
						continue;
					emailCC.add(agent.getEmail());
				}
				
				emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
				emailSubject.setHTML(true);
				
				SendMail sm = new SendMail();
				
				sm.sendMail(emailSubject);
			}

		}
	}

	public List<QuotationLines> getQuotationByVendor(long vendorId) {

		try {

			List<QuotationLines> allLines = quotationLinesRepository.findAllLines(vendorId , AppConstants.rfq_Active_Status);	
			
			for(QuotationLines quotationLines : allLines) {
				
				List<QuotationLineDetails> allLineDetails = quotationLineDetailsRepository.findAllLinesFilterByQuotationId(vendorId, quotationLines.getId());
				
				if(allLineDetails != null) {
					quotationLines.setQuotationLineDetails(allLineDetails);
				}
				
								
				for(QuotationLineDetails  quotationLineDetails : quotationLines.getQuotationLineDetails()) {
					
					List<QuotationPriceBreaks> newQuotationPriceBreakList = new ArrayList<QuotationPriceBreaks>();					
					
					quotationLines.setFreight_charge_include(quotationLineDetails.getFreight_charge_include());
					quotationLines.setFreight_charge(quotationLineDetails.getFreight_charge());
					quotationLines.setTax(quotationLineDetails.getTax());
					quotationLines.setUpdated_price_by_supplier(quotationLineDetails.getUpdated_price_by_supplier());
					quotationLines.setVendor_id(quotationLineDetails.getVendor_id());
					quotationLines.setVendor_name(quotationLineDetails.getVendor_name());
					quotationLines.setNotification_sent(quotationLineDetails.getNotification_sent());
					
					if(quotationLineDetails.getPrice_end_date() != null) {
						
						quotationLines.setPrice_end_date(quotationLineDetails.getPrice_end_date());
					}
					
					for(QuotationPriceBreaks priceBreak : quotationLines.getRfqPriceBreaksVendor()) {							
						
						if(priceBreak.getVendor_id().equals(quotationLineDetails.getVendor_id())) {
							
							newQuotationPriceBreakList.add(priceBreak);
						}
						
					}
					
					quotationLines.setRfqPriceBreaksVendor(newQuotationPriceBreakList);
				}
				
			}
											
			return allLines;

		} catch (Exception e) {
			throw new AppException("Unable to get Quotation");
		}

	}

	public String updateQuotUnitPrice(long rfqHeaderId, long rfqLineId, long rfq_line_location_id , double updateUnitPrice,
			String freight_charge_include , double freight_charge , double tax, String user_name , Date price_end_date,
			long quotation_line_id) {

		try {
			
			User user =  userRepository.findByUsername(user_name)
						.orElseThrow(() -> new ResourceNotFoundException("User", "username", user_name));
			
			Long vendor_id = (long) 0;
			
			if (user != null) {
				
			  vendor_id = Long.parseLong(user.getVendorID());
			  
			}
			
			QuotationLineDetails quotationLinedetails = null;

			quotationLinedetails = quotationLineDetailsRepository.findLineDetail(rfqHeaderId, rfqLineId, rfq_line_location_id,
					vendor_id);

			if (quotationLinedetails != null) {

				setWhoForQuotLineDetails(quotationLinedetails, user, updateUnitPrice, freight_charge_include, freight_charge, tax,
						user_name, price_end_date , false , 0 , 0 , 0 , 0);

			} else {

				quotationLinedetails = new QuotationLineDetails();

				setWhoForQuotLineDetails(quotationLinedetails, user, updateUnitPrice, freight_charge_include, freight_charge, tax,
						user_name, price_end_date , true , rfqHeaderId, rfqLineId, rfq_line_location_id , quotation_line_id);
				
			}
			
			quotationLineDetailsRepository.save(quotationLinedetails);

		} catch (Exception e) {
			throw new AppException("Unable to update price");
		}

		return AppConstants.Success_Message;

	}

	private void setWhoForQuotLineDetails(QuotationLineDetails quotationLinedetails , User user, double updateUnitPrice,
			String freight_charge_include , double freight_charge , double tax, String user_name , Date price_end_date,
			   boolean isNew , long rfqHeaderId, long rfqLineId, long rfq_line_location_id , long quotation_line_id) {


		ApSuppliers supplier = apSuppliersRepository.findByVendorIDId(user.getVendorID());
		
		setUpdationdatesForQuotationLines(quotationLinedetails , user);

		quotationLinedetails.setLast_update_login(user.getId());
		quotationLinedetails.setLast_updated_by(user.getId());
		quotationLinedetails.setUser_name(user_name);

		quotationLinedetails.setUpdated_price_by_supplier(updateUnitPrice);
		quotationLinedetails.setFreight_charge_include(freight_charge_include);
		quotationLinedetails.setFreight_charge(freight_charge);
		quotationLinedetails.setTax(tax);
		quotationLinedetails.setPrice_end_date(price_end_date);
		
		if(isNew) {
			
			RFQVendors vendor = rFQVendorsRepository.findVendor(rfqHeaderId, supplier.getVendor_id());
			
			SupplierSites site = supplierSitesRepository.findSite(supplier.getVendor_id(), vendor.getVendor_site_id());
			
			quotationLinedetails.setRfq_header_id(rfqHeaderId);
			quotationLinedetails.setRfq_line_id(rfqLineId);
			quotationLinedetails.setRfq_line_location_id(rfq_line_location_id);
			quotationLinedetails.setQuotation_line_id(quotation_line_id);
			quotationLinedetails.setVendor_site_code(site.getVendor_site_code());
		}
		
		if(supplier != null) {
			
			quotationLinedetails.setVendor_id(supplier.getVendor_id());
			quotationLinedetails.setVendor_name(supplier.getVendor_name());
		}
	}

	public List<QuotationPriceBreaks> addQuotPriceBreaks(List<QuotationPriceBreaks> list) {

		List<QuotationPriceBreaks> priceBreaks = new ArrayList<QuotationPriceBreaks>();
		
		String user_name = list != null && list.size() > 0 ? list.get(0).getUser_name() : "";

		User user =  userRepository.findByUsername(user_name).orElseThrow(
					() -> new ResourceNotFoundException("User", "username", user_name));
		
		Long vendor_id = (long) 0;
		
		if (user != null) {
			
		  vendor_id = Long.parseLong(user.getVendorID());
		  
		}
		
		QuotationLineDetails quotLineDetails = null;
		
		for (QuotationPriceBreaks priceBreak : list) {
			
			setUpdationdatesForQuotationPriceBreaks(priceBreak , user);			
			
			if (quotLineDetails == null) {

				quotLineDetails = quotationLineDetailsRepository.findLineDetail(priceBreak.getRfq_header_id(),
						priceBreak.getRfq_line_id(), priceBreak.getRfq_line_location_id(), vendor_id);
			}				
			
			if(quotLineDetails == null) {
				
				throw new AppException("Please first add line details");

			}
			
			if(quotLineDetails.getPrice_end_date() != null) {
				
				priceBreak.setDiscount_end_date(quotLineDetails.getPrice_end_date());
			}
			
			priceBreak.setVendor_id(quotLineDetails.getVendor_id());
			priceBreak.setVendor_name(quotLineDetails.getVendor_name());
			
			priceBreaks.add(priceBreak);

		}
		
		quotationPriceBreaksRepository.saveAll(priceBreaks);

		return priceBreaks;

	}
	
	public String sendQuotationToBuyer(List<QuotationLines> quotationLines , HttpServletRequest request) {

		try {

			List<QuotationMailObject> quotMailObjects = new ArrayList<QuotationMailObject>();

			if (quotationLines != null) {
				
				for(QuotationLines line : quotationLines) {
					
					for(QuotationPriceBreaks priceBreak : line.getRfqPriceBreaksVendor()) {
						
						QuotationMailObject quotMailObj = new QuotationMailObject();
						
						BeanUtils.copyProperties(line, quotMailObj);
						BeanUtils.copyProperties(priceBreak, quotMailObj);
						
						quotMailObjects.add(quotMailObj);
					}
				}					

			}

			if (quotMailObjects != null && quotMailObjects.size() > 0) {
				
				Long agentId = quotMailObjects.get(0).getAgent_id();

				try {
					
					sendQuotationMailByVendor(quotMailObjects, agentId ,  request);
				} catch(Exception ex) {
					logger.info("***************** Unable to send mail *********************\n" + ex);
				}
			}

		} catch (Exception e) {
			throw new AppException("Unable to add price breaks");
		}

		return AppConstants.Success_Message;

	}
	
	private void sendQuotationMailByVendor(List<QuotationMailObject> list, Long agentId , HttpServletRequest request) {

		if (list != null && list.size() > 0 && agentId != null) {

			QuotationMailObject quotObj = list.get(0);

			String userName = quotObj.getUser_name();

			EmailSubject emailSubject = null;
			try {
				emailSubject = EmailSubject.getInstance(emailDetailsRepository);
			} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
					| NoSuchPaddingException | InvalidKeySpecException e) {

				throw new AppException("Unable to get Email details");
			}

			User vendor = userRepository.findUser(getUserIdFromRequest(request))
					.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

			String emailFrom = new String();
			List<String> emailTo = new ArrayList<String>();
			List<String> emailCC = new ArrayList<String>();

			String subject = new String();

			subject = AppConstants.quotationSubject.replace("??", userName);

			String text = emailHtmlLoader.loadQuotationText(list);

			emailFrom = vendor.getEmail();

			List<User> agents = userRepository.findByAgentId(agentId);

			// add first one for to mail and others for cc
			emailTo.add(agents.get(0).getEmail());

			for (User agent : agents) {

				if (agent == agents.get(0))
					continue;
				emailCC.add(agent.getEmail());
			}

			emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
			emailSubject.setHTML(true);

			SendMail sm = new SendMail();

			sm.sendMail(emailSubject);
		}
	}


	public String deleteQuotationPriceBreak(long id) {

		try {

			QuotationPriceBreaks priceBreak = quotationPriceBreaksRepository.findPriceBreak(id);

			if (priceBreak != null) {

				quotationPriceBreaksRepository.delete(priceBreak);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		return AppConstants.Success_Message;

	}
	
	public List<QuotationLines> getQuotationByAgent(long agent_id , String rfq_number) {
			
			List<QuotationLines> allLines = new ArrayList<QuotationLines>();
			
			List<QuotationLines> newAllLines = new ArrayList<QuotationLines>();
			
			try {

			if(rfq_number != null) {
				
				allLines = quotationLinesRepository.findAllQuotationsByByerWithRFQno(rfq_number , agent_id);
				
			} else {
				
				allLines = quotationLinesRepository.findAllQuotationsByByer(agent_id);
			}
				
				for(QuotationLines quotationLines : allLines) {
					
					
					List<QuotationLineDetails> allLineDetails = quotationLineDetailsRepository.findAllQuotationLInesByBuyer(quotationLines.getRfq_header_id(), quotationLines.getId());
					
					if(allLineDetails != null) {
						quotationLines.setQuotationLineDetails(allLineDetails);
					}										
					
					
					for(QuotationLineDetails  quotationLineDetails : quotationLines.getQuotationLineDetails()) {
						
						QuotationLines newLines = new QuotationLines();
						
						List<QuotationPriceBreaks> newQuotationPriceBreakList = new ArrayList<QuotationPriceBreaks>();
						
						BeanUtils.copyProperties(quotationLines, newLines);						
						
						newLines.setFreight_charge_include(quotationLineDetails.getFreight_charge_include());
						newLines.setFreight_charge(quotationLineDetails.getFreight_charge());
						newLines.setTax(quotationLineDetails.getTax());
						newLines.setUpdated_price_by_supplier(quotationLineDetails.getUpdated_price_by_supplier());
						newLines.setVendor_id(quotationLineDetails.getVendor_id());
						newLines.setVendor_name(quotationLineDetails.getVendor_name());
						newLines.setNotification_sent(quotationLineDetails.getNotification_sent());
						newLines.setPrice_end_date(quotationLineDetails.getPrice_end_date());
						
						for(QuotationPriceBreaks priceBreak : newLines.getRfqPriceBreaksVendor()) {							
							
							if(priceBreak.getVendor_id().equals(quotationLineDetails.getVendor_id())) {
								
								newQuotationPriceBreakList.add(priceBreak);
							}
							
						}
						
						newLines.setRfqPriceBreaksVendor(newQuotationPriceBreakList);
						
						newAllLines.add(newLines);
					}
					
				}
												
				return newAllLines;					

		} catch (Exception e) {
			logger.error("***************** Unable to get Quotation *********************\n" + e);
			throw new AppException("Unable to get Quotation");
		}

	}
	
	public String sendQuotNotification(long rfqHeaderId , String user_name , HttpServletRequest request) {

		try {
			
			User user = userRepository.findByUsername(user_name)
						.orElseThrow(() -> new ResourceNotFoundException("User", "username", user_name));
			
            Long vendor_id = (long) 0;
			
			if (user != null) {
				
			  vendor_id = Long.parseLong(user.getVendorID());
			  
			}
			
			List<QuotationLines> quotationLines = quotationLinesRepository.findLinesByHeaderIdAndVenor(rfqHeaderId , vendor_id);
						
			List<QuotationLineDetails> quotationLineDetails = new ArrayList<QuotationLineDetails>();
			
			for(QuotationLines lines : quotationLines) {
							
				for(QuotationLineDetails quotationLineDetail : lines.getQuotationLineDetails()) {					
						
						setUpdationdatesForQuotationLines(quotationLineDetail , user);								
						
						quotationLineDetail.setNotification_sent("Y");
						
						quotationLineDetails.add(quotationLineDetail);
				}
			}
			
			
			try {
				
				sendQuotationToBuyer(quotationLines ,  request);
				
			} catch (Exception e) {
				logger.info("***************** Unable to send mail *********************\n" + e);
			}
			
			quotationLineDetailsRepository.saveAll(quotationLineDetails);


		} catch (Exception e) {
			throw new AppException("Unable to update notification ack");
		}

		return AppConstants.Success_Message;

	}
	
    private Long getUserIdFromRequest(HttpServletRequest request) {
		
		String bearerToken = request.getHeader("Authorization");
		
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			
			String jwt = bearerToken.substring(7, bearerToken.length());
			
			Long userId = tokenProvider.getUserIdFromJWT(jwt);
			
			return userId;
		}
		
		
		return null;
	}
	
}
