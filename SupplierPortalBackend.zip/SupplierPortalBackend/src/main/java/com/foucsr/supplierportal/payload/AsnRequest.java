package com.foucsr.supplierportal.payload;

import java.util.Date;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AsnRequest {

	private String vendor_id;

	private Long unique_id;

	private Long po_line_location_id;

	private Double shipment_qty;

	private String buyer_id;

	private Double shipment_amount;
	
	private String supp_invoice_num;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date supp_shipped_date;
	
    private String do_num;
	
	public AsnRequest() {
		
	}

	public AsnRequest(String vendor_id, Long unique_id, Long po_line_location_id, Double shipment_qty,
			String buyer_id, Double shipment_amount) {
		super();
		this.vendor_id = vendor_id;
		this.unique_id = unique_id;
		this.po_line_location_id = po_line_location_id;
		this.shipment_qty = shipment_qty;
		this.buyer_id = buyer_id;
		this.shipment_amount = shipment_amount;
	}

	public String getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(String vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Long getUnique_id() {
		return unique_id;
	}

	public void setUnique_id(Long unique_id) {
		this.unique_id = unique_id;
	}

	public Long getPo_line_location_id() {
		return po_line_location_id;
	}

	public void setPo_line_location_id(Long po_line_location_id) {
		this.po_line_location_id = po_line_location_id;
	}

	public Double getShipment_qty() {
		return shipment_qty;
	}

	public void setShipment_qty(Double shipment_qty) {
		this.shipment_qty = shipment_qty;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Double getShipment_amount() {
		return shipment_amount;
	}

	public void setShipment_amount(Double shipment_amount) {
		this.shipment_amount = shipment_amount;
	}

	public String getSupp_invoice_num() {
		return supp_invoice_num;
	}

	public void setSupp_invoice_num(String supp_invoice_num) {
		this.supp_invoice_num = supp_invoice_num;
	}

	public Date getSupp_shipped_date() {
		return supp_shipped_date;
	}

	public void setSupp_shipped_date(Date supp_shipped_date) {
		this.supp_shipped_date = supp_shipped_date;
	}

	public String getDo_num() {
		return do_num;
	}

	public void setDo_num(String do_num) {
		this.do_num = do_num;
	}

}