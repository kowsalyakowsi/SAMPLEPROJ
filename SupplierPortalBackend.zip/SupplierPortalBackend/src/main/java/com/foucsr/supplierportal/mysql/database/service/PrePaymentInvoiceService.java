package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.PrePaymentInvoice;
import com.foucsr.supplierportal.mysql.database.repository.PrePaymentInvoiceDetailsRepository;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@Service
public class PrePaymentInvoiceService {

	@Autowired
	private PrePaymentInvoiceDetailsRepository prePaymentInvoiceDetailsRepository;

	public List<PrePaymentInvoice> getClosedPoByDate(GetOpenPoByDateRequest byDateRequest) {

		List<PrePaymentInvoice> list = null;

		try {
			if (!"".equals(byDateRequest.getFromDate()) && !"".equals(byDateRequest.getToDate())
					&& byDateRequest.getVendorId() != null) {
				
				list = prePaymentInvoiceDetailsRepository.getPrepaymentsByAllParm(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
				
			} else if (byDateRequest.getVendorId() != null) {
				
				list = prePaymentInvoiceDetailsRepository.getPrepaymentsByVendorId(byDateRequest.getVendorId());
				
			}

		} catch (Exception e) {
			throw new AppException("Unable to get pre-payment details");
		}
		
       if(list == null || list.size() == 0) {
			
			list = new ArrayList<PrePaymentInvoice>();
			
		}

		return list;

	}

}
