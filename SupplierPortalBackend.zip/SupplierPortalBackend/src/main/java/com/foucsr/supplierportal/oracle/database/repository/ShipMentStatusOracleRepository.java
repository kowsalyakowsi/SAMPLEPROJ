package com.foucsr.supplierportal.oracle.database.repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.oracle.database.model.ShipMentStatusOracle;
import com.foucsr.supplierportal.util.AppConstants;

@Component
public class ShipMentStatusOracleRepository  {	  
	
	Logger log = LoggerFactory.getLogger(ShipMentStatusOracleRepository.class);
    
//    @Query(value = "select * from XX_SHIPMENT_STATUS_TBL where PO_PROCESS_STATUS='I' OR PO_PROCESS_STATUS='U'", nativeQuery = true)
//    List<ShipMentStatusOracle> findByFirstNameAndLastName();
   
	public List<ShipMentStatusOracle> findByFirstNameAndLastName() {

		RestTemplate restTemplate = new RestTemplate();

//		ResponseEntity<POAgentsOracle[]> response = restTemplate.getForEntity(
//				"http://192.168.1.37:8000//sap/bc/zapi_buyer?sap-client=200", POAgentsOracle[].class);
		
		String shipStatusURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_shipasn?sap-client=800";
		
		ResponseEntity<ShipMentStatusOracle[]> response = restTemplate.getForEntity(
				shipStatusURL , ShipMentStatusOracle[].class);


		ShipMentStatusOracle[] shipStasus = response.getBody();

		List<ShipMentStatusOracle> shipStatusList = Arrays.asList(shipStasus);
		
		if(shipStatusList == null) {
			
			shipStatusList = new ArrayList<ShipMentStatusOracle>();
		}
		
		return shipStatusList;
	}
	
	 public void ackAgentbySOAPService(List<ShipMentStatus> shipList) {
			
		    String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zser_shipasn_ack/800/zser_shipasn_ack/zbind1?sap-client=800";
			
			String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zser_shipasn_ack/800/zser_shipasn_ack/zbind1";
			
			
			try {
				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();

				// Send SOAP Message to SOAP Server
				SOAPMessage soapResponse = soapConnection.call(createAckAgentSOAPRequest(soapAction , shipList), soapEndpointUrl);

				// Print the SOAP Response
				System.out.println("Response SOAP Message:");
				soapResponse.writeTo(System.out);
				System.out.println();

				soapConnection.close();
			} catch (Exception e) {
				log.info("***************** Error occurred while sending ACK shipment status SOAP Request to Server!\\nMake sure you have the correct endpoint URL and SOAPAction!  *********************\n" + e);
			}
		}
	    
	    private SOAPMessage createAckAgentSOAPRequest(String soapAction , List<ShipMentStatus> shipList) throws Exception {
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();

			createAckAgentSoapEnvelope(soapMessage ,   shipList);

			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", soapAction);
			
			String loginPassword = "developer:saphana2";
			
			soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


			soapMessage.saveChanges();

			/* Print the request message, just for debugging purposes */
			System.out.println("Request SOAP Message:");
			soapMessage.writeTo(System.out);
			System.out.println("\n");

			return soapMessage;
		}

	    
	    private void createAckAgentSoapEnvelope(SOAPMessage soapMessage , List<ShipMentStatus> shipList) throws SOAPException {

			SOAPPart soapPart = soapMessage.getSOAPPart();
			String serverURI = "urn:sap-com:document:sap:rfc:functions";
			SOAPEnvelope envelope = soapPart.getEnvelope();

			envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

			SOAPBody soapBody = envelope.getBody();
			SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZVEN_SHIPASN_ACK", "urn", ""));
//			 bodyElement.addChildElement("INPUT").addTextNode("ACKOPENPO");
			 SOAPElement it_ven_element = bodyElement.addChildElement("IT_PORTAL");

			 addBuyerItems(it_ven_element , shipList);
			 
			soapMessage.saveChanges();
		}

	    private void addBuyerItems(SOAPElement it_ven_element , List<ShipMentStatus> shipList) throws SOAPException {
	    	    	
	    	
	    	for(ShipMentStatus shipment : shipList) {
	    		
	    		QName itemQ = new QName("item");
	    		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);
	    		
	    		itemQ = new QName("HEADER_ID");
	    		SOAPElement hdrid = itemElement.addChildElement(itemQ);
	    		hdrid.addTextNode(Long.toString(shipment.getHeader_id()));
	    		
	    		itemQ = new QName("ASN");
	    		SOAPElement asn = itemElement.addChildElement(itemQ);
	    		asn.addTextNode(shipment.getAsn());
	    		
	    		if(shipment.getReceipt_number_list() != null) {
	    			
	    			itemQ = new QName("RECEIPT_NO");
	    			SOAPElement receipt_no = itemElement.addChildElement(itemQ);
	    			receipt_no.addTextNode(shipment.getReceipt_number_list());
	    		}
	    		
	    		
	    		itemQ = new QName("PO_NUM");
	    		SOAPElement poNumber = itemElement.addChildElement(itemQ);
	    		poNumber.addTextNode(shipment.getPo_number());
	    		
	    		itemQ = new QName("PO_LINE_NUM");
	    		SOAPElement poLineNumber = itemElement.addChildElement(itemQ);
	    		poLineNumber.addTextNode(Long.toString(shipment.getPo_line_num()));
	    		
	    		itemQ = new QName("PROCESS_STAT");
	    		SOAPElement processStatus = itemElement.addChildElement(itemQ);
	    		processStatus.addTextNode(shipment.getProcessStatus());
	    		
	    	}


		}


}