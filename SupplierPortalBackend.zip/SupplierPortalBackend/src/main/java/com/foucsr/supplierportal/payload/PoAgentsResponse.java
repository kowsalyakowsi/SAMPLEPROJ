package com.foucsr.supplierportal.payload;

public class PoAgentsResponse {
	
	private String agentId;
	private String agent_name;
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getAgent_name() {
		return agent_name;
	}
	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}
	

}
