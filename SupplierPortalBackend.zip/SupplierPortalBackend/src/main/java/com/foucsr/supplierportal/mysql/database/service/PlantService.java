package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.PlantMysql;
import com.foucsr.supplierportal.mysql.database.repository.PlantMysqlRepository;
import com.foucsr.supplierportal.oracle.database.model.OpenVendorOracle;
import com.foucsr.supplierportal.oracle.database.repository.OpenVendorOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.util.SCAUtil;

@Service
public class PlantService {

	Logger logger = LoggerFactory.getLogger(PlantService.class);
	
	
	@Autowired
   	private PlantMysqlRepository plantMysqlRepository;
	

	public ResponseEntity<?> getPlantList() {
		
		List<PlantMysql> list = null;
		SCAUtil scaUtil = new SCAUtil() ;
		
		try {
			
			list = plantMysqlRepository.getAllPlants();

		} catch (Exception e) {
			
			logger.info("***************** Unable to get plants*********************\n" + e);
			
			String msg = scaUtil.getErrorMessage(e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable get Open plants!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<PlantMysql>();
			
		}

		return new ResponseEntity(list, HttpStatus.OK);

	}

}
