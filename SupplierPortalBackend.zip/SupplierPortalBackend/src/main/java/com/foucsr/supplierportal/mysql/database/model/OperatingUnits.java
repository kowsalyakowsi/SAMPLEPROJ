package com.foucsr.supplierportal.mysql.database.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "OPERATING_UNITS")
public class OperatingUnits {
	
	@Id	
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "BUSINESS_GROUP_ID")
	private long business_group_id;

	@Column(name = "ORGANIZATION_ID")
	private long organization_id;

	@Column(name = "NAME")
	private String name;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "DATE_FROM")
	private Date date_from;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "DATE_TO")
	private Date date_to;

	@Column(name = "SHORT_CODE")
	private String short_code;

	@Column(name = "SET_OF_BOOKS_ID")
	private String set_of_books_id;

	@Column(name = "DEFAULT_LEGAL_CONTEXT_ID")
	private String def_legal_context_id;

	@Column(name = "USABLE_FLAG")
	private String usable_flag;

	@Column(name = "PO_PROCESS_STATUS")
	private String poProcessStatus;

	public OperatingUnits() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getBusiness_group_id() {
		return business_group_id;
	}

	public void setBusiness_group_id(long business_group_id) {
		this.business_group_id = business_group_id;
	}

	public long getOrganization_id() {
		return organization_id;
	}

	public void setOrganization_id(long organization_id) {
		this.organization_id = organization_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate_from() {
		return date_from;
	}

	public void setDate_from(Date date_from) {
		this.date_from = date_from;
	}

	public Date getDate_to() {
		return date_to;
	}

	public void setDate_to(Date date_to) {
		this.date_to = date_to;
	}

	public String getShort_code() {
		return short_code;
	}

	public void setShort_code(String short_code) {
		this.short_code = short_code;
	}

	public String getSet_of_books_id() {
		return set_of_books_id;
	}

	public void setSet_of_books_id(String set_of_books_id) {
		this.set_of_books_id = set_of_books_id;
	}

	public String getDef_legal_context_id() {
		return def_legal_context_id;
	}

	public void setDef_legal_context_id(String def_legal_context_id) {
		this.def_legal_context_id = def_legal_context_id;
	}

	public String getUsable_flag() {
		return usable_flag;
	}

	public void setUsable_flag(String usable_flag) {
		this.usable_flag = usable_flag;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	
}