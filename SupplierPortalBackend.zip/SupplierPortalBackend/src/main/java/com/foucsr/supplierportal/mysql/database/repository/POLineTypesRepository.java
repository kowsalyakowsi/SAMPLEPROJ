package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.POLineTypes;


@Repository
public interface POLineTypesRepository extends CrudRepository<POLineTypes, Long> {	  
	
    @Override
    Iterable<POLineTypes> findAll();
    
    @Query(value = "select * from PO_LINE_TYPES ", nativeQuery = true)
    List<POLineTypes> findAllPOLineTypes();

   
}