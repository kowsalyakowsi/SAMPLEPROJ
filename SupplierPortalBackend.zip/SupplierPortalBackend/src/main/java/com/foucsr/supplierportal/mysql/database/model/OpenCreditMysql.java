package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OPEN_CREDIT_TBL")
public class OpenCreditMysql {

	@Id	
	@Column(name = "HEADER_ID")
	private Long header_id;
	
	@Column(name = "COM_CODE")
	private String com_code;
	
	
	@Column(name = "VENDOR_ID")
	private String vendor_id;
	
	@Column(name = "INV_ID")
	private String inv_id;
	
	@Column(name = "FISCAL_YR")
	private Long fiscal_yr;
	
	@Column(name = "PO_NUM")
	private String po_num;
	
	@Column(name = "AMOUNT")
	private Double amount;
	
	@Column(name = "CURRENCY")
	private String currency;
	
	@Column(name = "ITEM")
	private String item;
	
	@Column(name = "QUANTITY")
	private Double quantity;
	
	@Column(name = "PO_UOM")
	private String po_uom;
	
	@Column(name = "PSTAT")
	private String pstat;

	public Long getHeader_id() {
		return header_id;
	}

	public void setHeader_id(Long header_id) {
		this.header_id = header_id;
	}

	public String getCom_code() {
		return com_code;
	}

	public void setCom_code(String com_code) {
		this.com_code = com_code;
	}

	public String getInv_id() {
		return inv_id;
	}

	public void setInv_id(String inv_id) {
		this.inv_id = inv_id;
	}

	public Long getFiscal_yr() {
		return fiscal_yr;
	}

	public void setFiscal_yr(Long fiscal_yr) {
		this.fiscal_yr = fiscal_yr;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public String getPstat() {
		return pstat;
	}

	public void setPstat(String pstat) {
		this.pstat = pstat;
	}

	public String getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(String vendor_id) {
		this.vendor_id = vendor_id;
	}
	
		
}