package com.foucsr.supplierportal.mysql.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ASNDetails;

@Repository
public interface ASNDetailsRepository extends CrudRepository<ASNDetails, Long> {
	   
	
	
    
}