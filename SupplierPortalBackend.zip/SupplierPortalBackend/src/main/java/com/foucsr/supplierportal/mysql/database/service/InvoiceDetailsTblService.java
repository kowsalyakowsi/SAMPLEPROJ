package com.foucsr.supplierportal.mysql.database.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.InvoiceDetailsTbl;
import com.foucsr.supplierportal.mysql.database.repository.InvoiceDetailsTblRepository;

@Service
public class InvoiceDetailsTblService {

	@Autowired
	private InvoiceDetailsTblRepository detailsTblRepository;

	public InvoiceDetailsTbl saveOrUpdateProject(InvoiceDetailsTbl detailsTbl, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return detailsTblRepository.save(detailsTbl);

	}

	public Optional<InvoiceDetailsTbl> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<InvoiceDetailsTbl> detailsTbl = detailsTblRepository.findById(id);

		return detailsTbl;
	}

	public Iterable<InvoiceDetailsTbl> findAllProjects(String username) {
		return detailsTblRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		detailsTblRepository.deleteById(id);
	}

}
