package com.foucsr.supplierportal.mysql.database.controller;

import java.security.Principal;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.model.ShipMentTbl;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.ShipMentStatusRepositoryService;
import com.foucsr.supplierportal.mysql.database.service.ShipMentTblRepositoryService;

@RestController
@RequestMapping("/ShipMentTbl/Service")
@CrossOrigin
public class ShipMentTblController {

	@Autowired
	private ShipMentTblRepositoryService shipmentService;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("")
	public ResponseEntity<?> createNewShipment(@Valid @RequestBody ShipMentTbl project, BindingResult result,
			Principal principal) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		ShipMentTbl project1 = shipmentService.saveOrUpdateShipment(project, principal.getName());
		return new ResponseEntity<ShipMentTbl>(project1, HttpStatus.CREATED);
	}

	@GetMapping("/{shipmentId}")
	public ResponseEntity<?> getProjectById(@PathVariable long shipmentId, Principal principal) {

		Optional<ShipMentTbl> project = shipmentService.findShipmentByIdentifier(shipmentId, principal.getName());

		return new ResponseEntity<Optional<ShipMentTbl>>(project, HttpStatus.OK);
	}

	@GetMapping("/all")
	public Iterable<ShipMentTbl> getAllProjects(Principal principal) {
		return shipmentService.findAllShipments(principal.getName());
	}
	
}
