package com.foucsr.supplierportal.mysql.database.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "PARTIAL_RECEIPTS")
public class PendingInvoice {
	
	@Id	
	@SequenceGenerator(name="PARTIAL_RECEIPTS_SEQ", sequenceName="PARTIAL_RECEIPTS_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTIAL_RECEIPTS_SEQ")	
	@Column(name = "PENDING_ORDER_ID")
	private Long id;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="PO_CREATION_DATE")
	private Date poCreateionDate;
	
	@Column(name="SUPPLIER_NAME")
	private String supplierName;	
		
	@Column(name="SUPPLIER_SITE")
	private String supplierSite;
	
	@Column(name="PO_NUMBER")
	private String po_num;
	
	@Column(name="PO_LINE_NUMBER")
	private long po_line_num;
	
	@Column(name="PO_ITEM_NAME")
	private String item_code;
	
	@Column(name="PO_ITEM_DESCRIPTION")
	private String item_desc;
	
	@Column(name="UOM")
	private String uom;
	
	@Column(name="ORDERED_QUANTITY")
	private Double ordered_qty;
	
	@Column(name="RECEIPTED_QUANTITY")
	private Double receipted_qty;
	
	@Column(name="PENDING_QUANTITY")
	private Double pending_qty;
	
	@Column(name="OU_NAME")
	private String ou_name;
	
	@Column(name="SHIP_TO_ORG")
	private String ship_to_org;
	
	@Column(name="PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@Column(name="VENDOR_ID")
	private long vendorId;

	
	
	public PendingInvoice() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getPoCreateionDate() {
		return poCreateionDate;
	}

	public void setPoCreateionDate(Date poCreateionDate) {
		this.poCreateionDate = poCreateionDate;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierSite() {
		return supplierSite;
	}

	public void setSupplierSite(String supplierSite) {
		this.supplierSite = supplierSite;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_desc() {
		return item_desc;
	}

	public void setItem_desc(String item_desc) {
		this.item_desc = item_desc;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getOrdered_qty() {
		return ordered_qty;
	}

	public void setOrdered_qty(Double ordered_qty) {
		this.ordered_qty = ordered_qty;
	}

	public Double getReceipted_qty() {
		return receipted_qty;
	}

	public void setReceipted_qty(Double receipted_qty) {
		this.receipted_qty = receipted_qty;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public String getShip_to_org() {
		return ship_to_org;
	}

	public void setShip_to_org(String ship_to_org) {
		this.ship_to_org = ship_to_org;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}


}