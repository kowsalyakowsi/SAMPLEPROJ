package com.foucsr.supplierportal.mysql.database.model;

import java.util.List;

public class RFQRelatedObjects {

	private List<MasterItems> masterItems;
	
	private List<MasterOrganizations> organizations;
	
	private List<OperatingUnits> operatingUnits;
	
	private List<Locations> locations;
	
	private List<RFQTypes> rfqTypes;
	
	private List<RFQStatus> rfqStatus;
	
	private List<ApSuppliers> suppliers;
	
	private List<UOM> uoms;
	
	private List<POLineTypes> pOLineTypes;

	public List<MasterItems> getMasterItems() {
		return masterItems;
	}

	public void setMasterItems(List<MasterItems> masterItems) {
		this.masterItems = masterItems;
	}

	public List<MasterOrganizations> getOrganizations() {
		return organizations;
	}

	public void setOrganizations(List<MasterOrganizations> organizations) {
		this.organizations = organizations;
	}

	public List<OperatingUnits> getOperatingUnits() {
		return operatingUnits;
	}

	public void setOperatingUnits(List<OperatingUnits> operatingUnits) {
		this.operatingUnits = operatingUnits;
	}

	public List<Locations> getLocations() {
		return locations;
	}

	public void setLocations(List<Locations> locations) {
		this.locations = locations;
	}

	public List<RFQTypes> getRfqTypes() {
		return rfqTypes;
	}

	public void setRfqTypes(List<RFQTypes> rfqTypes) {
		this.rfqTypes = rfqTypes;
	}

	public List<RFQStatus> getRfqStatus() {
		return rfqStatus;
	}

	public void setRfqStatus(List<RFQStatus> rfqStatus) {
		this.rfqStatus = rfqStatus;
	}

	public List<ApSuppliers> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<ApSuppliers> suppliers) {
		this.suppliers = suppliers;
	}

	public List<UOM> getUoms() {
		return uoms;
	}

	public void setUoms(List<UOM> uoms) {
		this.uoms = uoms;
	}

	public List<POLineTypes> getpOLineTypes() {
		return pOLineTypes;
	}

	public void setpOLineTypes(List<POLineTypes> pOLineTypes) {
		this.pOLineTypes = pOLineTypes;
	}
	
	
}
