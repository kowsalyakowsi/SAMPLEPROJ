package com.foucsr.supplierportal.oracle.database.repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.foucsr.supplierportal.mysql.database.model.OpenCreditMysql;
import com.foucsr.supplierportal.mysql.database.model.PaymentDetailsTbl;
import com.foucsr.supplierportal.oracle.database.model.OpenCreditOracle;
import com.foucsr.supplierportal.oracle.database.model.PlantOracle;
import com.foucsr.supplierportal.util.AppConstants;

@Component
public class PlantOracleRepository  {
	   
	Logger log = LoggerFactory.getLogger(PlantOracleRepository.class);
//	
   
	public List<PlantOracle> findLatestPlant() {

		RestTemplate restTemplate = new RestTemplate();

		String paymentURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_plant_mas?sap-client=800";
		
		ResponseEntity<PlantOracle[]> response = restTemplate.getForEntity(
				paymentURL , PlantOracle[].class);


		PlantOracle[] payments = response.getBody();

		List<PlantOracle> paymentList = Arrays.asList(payments);
		
		if(paymentList == null) {
			
			paymentList = new ArrayList<PlantOracle>();
		}
		
		return paymentList;
	}
	
	public void ackAgentbySOAPService(List<OpenCreditMysql> payList) {
		
	    String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zser_credit_ack/800/zser_credit_ack/zbind1?sap-client=800";
						
		
		String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zser_credit_ack/800/zser_credit_ack/zbind1";
		
		
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			SOAPMessage soapResponse = soapConnection.call(createAckAgentSOAPRequest(soapAction , payList), soapEndpointUrl);

			// Print the SOAP Response
			System.out.println("Response SOAP Message:");
			soapResponse.writeTo(System.out);
			System.out.println();

			soapConnection.close();
		} catch (Exception e) {
			log.info("***************** Error occurred while sending ACK payment SOAP Request to Server!\\nMake sure you have the correct endpoint URL and SOAPAction!  *********************\n" + e);
		}
	}
    
    private SOAPMessage createAckAgentSOAPRequest(String soapAction , List<OpenCreditMysql> payList) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();

		createAckAgentSoapEnvelope(soapMessage ,  payList);

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", soapAction);
		
		String loginPassword = "developer:saphana2";
		
		soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


		soapMessage.saveChanges();

		/* Print the request message, just for debugging purposes */
//		System.out.println("Request SOAP Message:");
//		soapMessage.writeTo(System.out);
//		System.out.println("\n");

		return soapMessage;
	}

    
    private void createAckAgentSoapEnvelope(SOAPMessage soapMessage , List<OpenCreditMysql> payList) throws SOAPException {

		SOAPPart soapPart = soapMessage.getSOAPPart();
		String serverURI = "urn:sap-com:document:sap:rfc:functions";
		SOAPEnvelope envelope = soapPart.getEnvelope();

		envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

		SOAPBody soapBody = envelope.getBody();
		SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZVEN_CREDIT_ACK", "urn", ""));
//		 bodyElement.addChildElement("INPUT").addTextNode("ACKOPENPO");
		 SOAPElement it_ven_element = bodyElement.addChildElement("IT_PORTAL");

		 addBuyerItems(it_ven_element ,   payList);
		 
		soapMessage.saveChanges();
	}

    private void addBuyerItems(SOAPElement it_ven_element , List<OpenCreditMysql> payList) throws SOAPException {
    	    	
    	
    	for(OpenCreditMysql payment :  payList) {
    		
    		QName itemQ = new QName("item");
    		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);	
    		
    		itemQ = new QName("HEADER_ID");
    		SOAPElement poHeaderId = itemElement.addChildElement(itemQ);
    		poHeaderId.addTextNode(Long.toString(payment.getHeader_id()));
    		
    		
    		itemQ = new QName("COM_CODE");
    		SOAPElement poNumber = itemElement.addChildElement(itemQ);
    		poNumber.addTextNode(payment.getCom_code());
    		
    		if(payment.getVendor_id() != null) {
    			
    			itemQ = new QName("VENDOR_ID");
    			SOAPElement venId = itemElement.addChildElement(itemQ);
    			venId.addTextNode(payment.getVendor_id());
    		}
    		
    		if(payment.getInv_id() != null) {
    			
    			itemQ = new QName("INV_ID");
    			SOAPElement invId = itemElement.addChildElement(itemQ);
    			invId.addTextNode(payment.getInv_id());
    		}
    		
    		if(payment.getFiscal_yr() != null) {
    			
    			itemQ = new QName("FISCAL_YR");
    			SOAPElement fisYr = itemElement.addChildElement(itemQ);
    			fisYr.addTextNode(payment.getFiscal_yr().toString());
    		}
    		    		    		        	
    		
    	}


	}



}