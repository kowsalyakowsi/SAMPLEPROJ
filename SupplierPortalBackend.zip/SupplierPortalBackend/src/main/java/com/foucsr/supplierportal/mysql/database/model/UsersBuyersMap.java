package com.foucsr.supplierportal.mysql.database.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "USERS_BUYERS_MAP")
public class UsersBuyersMap {
	@Id
	@SequenceGenerator(name = "USERS_BUYERS_MAP_SEQ", sequenceName = "USERS_BUYERS_MAP_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USERS_BUYERS_MAP_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "USER_ID")
	private String user_id;
	
	@Column(name = "BUYER_ID")
	private String buyer_id;

	public UsersBuyersMap() {
		
	}

	public UsersBuyersMap(Long id, String user_id, String buyer_id) {
		this.id = id;
		this.user_id = user_id;
		this.buyer_id = buyer_id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
}