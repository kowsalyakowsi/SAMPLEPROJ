package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ShipMentTblOracle {

	private Long id;

	private String ou_name;

	private Long po_header_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date PO_DATE;

	private String po_number;

	private String vendor_name;

	private String vendor_site_code;

	private String buyer;

	private Long buyer_id;

	private Long po_line_num;

	private String item;

	private String item_description;

	private String po_uom;

	private Double unit_price;

	private Double qty_ordered;

	private String organization_name;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date need_by_date;

	private String ack;

	private String reschedule;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date reschedule_date;

	private String process_flag;

	private String asn;

	private Long shipment_num;

	private String receipt_created_flag;

	private Long po_line_id;

	private long po_line_location_id;

	private Long receipt_number;

	private Long vendor_id;

	private Double SHIPMENT_QTY;

	private Double receiving_quantity;

	private long header_id;

	private Double pending_qty;

	private String buyer_approval;

	private String processStatus;

	private String secondary_inv_name;
	
	private Long line_type_id;
	
	private String line_type;
	
	private Double amount;
	
	private String currency_code;
	
	private Double partial_shipped_qty;
	
    private String supp_invoice_num;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date supp_shipped_date;
	
	private Long revisionNo;
	
    private String do_num;
	
	
	public ShipMentTblOracle() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public Long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public Date getPO_DATE() {
		return PO_DATE;
	}

	public void setPO_DATE(Date pO_DATE) {
		PO_DATE = pO_DATE;
	}

	public String getPo_number() {
		return po_number;
	}

	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public Long getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(Long buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public Date getNeed_by_date() {
		return need_by_date;
	}

	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}

	public String getReschedule() {
		return reschedule;
	}

	public void setReschedule(String reschedule) {
		this.reschedule = reschedule;
	}

	public Date getReschedule_date() {
		return reschedule_date;
	}

	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}

	public String getProcess_flag() {
		return process_flag;
	}

	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}

	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public Long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public String getReceipt_created_flag() {
		return receipt_created_flag;
	}

	public void setReceipt_created_flag(String receipt_created_flag) {
		this.receipt_created_flag = receipt_created_flag;
	}

	public Long getPo_line_id() {
		return po_line_id;
	}

	public void setPo_line_id(Long po_line_id) {
		this.po_line_id = po_line_id;
	}

	public long getPo_line_location_id() {
		return po_line_location_id;
	}

	public void setPo_line_location_id(long po_line_location_id) {
		this.po_line_location_id = po_line_location_id;
	}

	public Long getReceipt_number() {
		return receipt_number;
	}

	public void setReceipt_number(Long receipt_number) {
		this.receipt_number = receipt_number;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Double getSHIPMENT_QTY() {
		return SHIPMENT_QTY;
	}

	public void setSHIPMENT_QTY(Double sHIPMENT_QTY) {
		SHIPMENT_QTY = sHIPMENT_QTY;
	}

	public Double getReceiving_quantity() {
		return receiving_quantity;
	}

	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}

	public long getHeader_id() {
		return header_id;
	}

	public void setHeader_id(long header_id) {
		this.header_id = header_id;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getBuyer_approval() {
		return buyer_approval;
	}

	public void setBuyer_approval(String buyer_approval) {
		this.buyer_approval = buyer_approval;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getSecondary_inv_name() {
		return secondary_inv_name;
	}

	public void setSecondary_inv_name(String secondary_inv_name) {
		this.secondary_inv_name = secondary_inv_name;
	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

	public Double getPartial_shipped_qty() {
		return partial_shipped_qty;
	}

	public void setPartial_shipped_qty(Double partial_shipped_qty) {
		this.partial_shipped_qty = partial_shipped_qty;
	}

	public String getSupp_invoice_num() {
		return supp_invoice_num;
	}

	public void setSupp_invoice_num(String supp_invoice_num) {
		this.supp_invoice_num = supp_invoice_num;
	}

	public Date getSupp_shipped_date() {
		return supp_shipped_date;
	}

	public void setSupp_shipped_date(Date supp_shipped_date) {
		this.supp_shipped_date = supp_shipped_date;
	}

	public Long getRevisionNo() {
		return revisionNo;
	}

	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}

	public String getDo_num() {
		return do_num;
	}

	public void setDo_num(String do_num) {
		this.do_num = do_num;
	}

}