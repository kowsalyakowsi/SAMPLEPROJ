/*package com.foucsr.supplierportal.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.ClosedPODetails;
import com.foucsr.supplierportal.mysql.database.model.DebitNote;
import com.foucsr.supplierportal.mysql.database.model.InvoiceDetailsTbl;
import com.foucsr.supplierportal.mysql.database.model.Locations;
import com.foucsr.supplierportal.mysql.database.model.MasterItems;
import com.foucsr.supplierportal.mysql.database.model.MasterOrganizations;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.mysql.database.model.OpenPoChangeDetails;
import com.foucsr.supplierportal.mysql.database.model.OperatingUnits;
import com.foucsr.supplierportal.mysql.database.model.PaymentDetailsTbl;
import com.foucsr.supplierportal.mysql.database.model.PendingInvoice;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.PrePaymentInvoice;
import com.foucsr.supplierportal.mysql.database.model.RTVDetails;
import com.foucsr.supplierportal.mysql.database.model.ShipMentStatus;
import com.foucsr.supplierportal.mysql.database.model.SupplierSites;
import com.foucsr.supplierportal.mysql.database.model.UOM;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.ClosedPODetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.DebitNoteRepository;
import com.foucsr.supplierportal.mysql.database.repository.InvoiceDetailsTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.LocationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterItemsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterOrganizationsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPODetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OpenPoChangeDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.OperatingUnitsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PaymentDetailsTblRepository;
import com.foucsr.supplierportal.mysql.database.repository.PendingInvoiceRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PrePaymentInvoiceDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.RTVDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.ShipMentStatusRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierSitesRepository;
import com.foucsr.supplierportal.mysql.database.repository.UOMRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.mysql.database.service.OpenPODetailsService;
import com.foucsr.supplierportal.oracle.database.model.ApSuppliersOracle;
import com.foucsr.supplierportal.oracle.database.model.ClosedPODetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.DebitNoteOracle;
import com.foucsr.supplierportal.oracle.database.model.InvoiceDetailsTblOracle;
import com.foucsr.supplierportal.oracle.database.model.LocationsOracle;
import com.foucsr.supplierportal.oracle.database.model.MasterItemsOracle;
import com.foucsr.supplierportal.oracle.database.model.MasterOrganizationsOracle;
import com.foucsr.supplierportal.oracle.database.model.OpenPODetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.OperatingUnitsOracle;
import com.foucsr.supplierportal.oracle.database.model.POAgentsOracle;
import com.foucsr.supplierportal.oracle.database.model.PaymentDetailsTblOracle;
import com.foucsr.supplierportal.oracle.database.model.PendingInvoiceOracle;
import com.foucsr.supplierportal.oracle.database.model.PrePaymentInvoiceOracle;
import com.foucsr.supplierportal.oracle.database.model.RTVDetailsOracle;
import com.foucsr.supplierportal.oracle.database.model.ShipMentStatusOracle;
import com.foucsr.supplierportal.oracle.database.model.SupplierSitesOracle;
import com.foucsr.supplierportal.oracle.database.model.UOMOracle;
import com.foucsr.supplierportal.oracle.database.repository.ApSuppliersOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ClosedPODetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.DebitNoteOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.InvoiceDetailsTblOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.LocationsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.MasterItemsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.MasterOrganizationsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.OpenPODetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.OperatingUnitsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.POAgentsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PaymentDetailsTblOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PendingInvoiceOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.PrePaymentInvoiceDetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.RTVDetailsOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.ShipMentStatusOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.SupplierSitesOracleRepository;
import com.foucsr.supplierportal.oracle.database.repository.UOMOracleRepository;

@Service
public class JobScheduler {

	@Autowired
	private ClosedPODetailsOracleRepository closedPODetailsRepositoryOracel;

	@Autowired
	private ClosedPODetailsRepository closedPODetailsRepositoryMysql;
	
	
	@Autowired
	private InvoiceDetailsTblOracleRepository invoiceDetailsTblOracleRepositoryOracle;
	
	@Autowired
	private InvoiceDetailsTblRepository invoiceDetailsTblRepositoryMysql;
	
	
	@Autowired
	private OpenPODetailsOracleRepository openPODetailsOracleRepositoryOracle;
	
	@Autowired
	private OpenPODetailsRepository openPODetailsRepositoryMysql;
	
	@Autowired
	private OpenPoChangeDetailsRepository openPOChengeDetailsRepositoryMysql;
	
	@Autowired
	private PaymentDetailsTblOracleRepository paymentDetailsTblOracleRepositoryOracle;
	
	@Autowired
	private PaymentDetailsTblRepository paymentDetailsTblRepositoryyMysql;
	
	
	@Autowired
	private RTVDetailsOracleRepository rTVDetailsOracleRepositoryOracle;
	
	@Autowired
	private RTVDetailsRepository rTVDetailsRepositoryMysql;
	//
	
	@Autowired
	private ShipMentStatusOracleRepository shipMentStatusOracleRepositoryOracle;
	
	@Autowired
	private POAgentsOracleRepository poAgentsOracleRepositoryOracle;
	
	@Autowired
	private ShipMentStatusRepository shipMentStatusRepositoryMysql;
	
	@Autowired
	private PoAgentsRepository poAgentsRepositoryMysql;
	
	@Autowired
	private ApSuppliersOracleRepository apSuppliersOracleRepository;
	
	@Autowired
	private ApSuppliersRepository apSuppliersMysqlRepository;
	
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    OpenPODetailsService openPODetailsService;
    
    @Autowired
	private PrePaymentInvoiceDetailsOracleRepository prePaymentInvoiceDetailsOracleRepository;
    
    @Autowired
	private PrePaymentInvoiceDetailsRepository prePaymentInvoiceDetailsRepository;
    
    @Autowired
	private DebitNoteOracleRepository debitNoteOracleRepository;
    
    @Autowired
	private DebitNoteRepository debitNoteRepository;
    
    @Autowired
   	private PendingInvoiceOracleRepository pendingInvoiceOracleRepository;
       
    @Autowired
   	private PendingInvoiceRepository pendingInvoiceRepository;
    
    @Autowired
   	private MasterItemsOracleRepository masterItemsOracleRepository;
       
    @Autowired
   	private MasterItemsRepository masterItemsRepository;
    
    @Autowired
   	private MasterOrganizationsOracleRepository masterOrganizationsOracleRepository;
       
    @Autowired
   	private MasterOrganizationsRepository masterOrganizationsRepository;
   	
    @Autowired
   	private OperatingUnitsOracleRepository operatingUnitsOracleRepository;
       
    @Autowired
   	private OperatingUnitsRepository operatingUnitsRepository;
    
    @Autowired
   	private LocationsOracleRepository locationsOracleRepository;
       
    @Autowired
   	private LocationsRepository locationsRepository;
    
    @Autowired
   	private SupplierSitesOracleRepository supplierSitesOracleRepository;
       
    @Autowired
   	private SupplierSitesRepository supplierSitesRepository;
    
    @Autowired
   	private UOMOracleRepository uOMOracleRepository;
       
    @Autowired
   	private UOMRepository uOMRepository;
      
    
	
	
	Logger log = LoggerFactory.getLogger(JobScheduler.class);

	@Scheduled(cron = "0 0/1 * * * *")
	public void add2DBJob() {
		
		try {
			dataMoveForOpenPODetails();
			dataMoveForClosedPODetails();
			dataMoveForInvoiceDetailsTbl();
			dataMoveForPaymentDetailsTbl();
			dataMoveForRTVDetails();
			dataMoveForShipMentStatus();
			dataMoveForPOAgents();
			dataMoveForSuppliers();
			dataMoveForPrePaymentInvoiceDetails();
			dataMoveForDebitNoteDetails();
			dataMoveForPendingInvoiceDetails();
			dataMoveForMasterItemsDetails();
			dataMoveForMasterOrganizationsDetails();
			dataMoveForOperatingUnitDetails();
			dataMoveForLocationDetails();
			dataMoveForSupplierSitesDetails();
			dataMoveForUOMDetails();
		} catch (Exception e) {
			System.out.println(e);
			log.info("***************** Error while move data from Oracle to Mysql  *********************\n" + e);
		}
	}

	
	private void dataMoveForShipMentStatus() throws BeansException {
		List<ShipMentStatusOracle> list = null;
		list = shipMentStatusOracleRepositoryOracle.findByFirstNameAndLastName();
		for (ShipMentStatusOracle user : list) {
			
			ShipMentStatus shipMentStatus = new ShipMentStatus();
			
			if ("I".equals(user.getProcessStatus())) {

				BeanUtils.copyProperties(user, shipMentStatus,"id");
			} else if ("U".equals(user.getProcessStatus())) {

				shipMentStatus = shipMentStatusRepositoryMysql.findByHeaderIdAndPoLineLocationId(user.getHeader_id(),
						user.getPo_line_location_id(),user.getAsn());
				
				if(shipMentStatus != null) {
					
					shipMentStatus.setQty_ordered(user.getQty_ordered());
					shipMentStatus.setReceiving_quantity(user.getReceiving_quantity());
					shipMentStatus.setPending_qty(user.getPending_qty());
					shipMentStatus.setQuantity_received(user.getQuantity_received());
					shipMentStatus.setQuantity_accepted(user.getQuantity_accepted());
					shipMentStatus.setQuantity_rejected(user.getQuantity_rejected());
					shipMentStatus.setQuantity_billed(user.getQuantity_billed());
					shipMentStatus.setQuantity_cancelled(user.getQuantity_cancelled());
					shipMentStatus.setReceipt_number(user.getReceipt_number());
				}
				
			}
			
			if(shipMentStatus != null) {
			  shipMentStatus.setProcessStatus("P");
			  shipMentStatusRepositoryMysql.save(shipMentStatus);
			  user.setProcessStatus("C");
			  shipMentStatusOracleRepositoryOracle.save(user);
			}
		}
	}
	
	
	private void dataMoveForRTVDetails() throws BeansException {
		List<RTVDetailsOracle> list = null;
		list = rTVDetailsOracleRepositoryOracle.findByFirstNameAndLastName();
		for (RTVDetailsOracle user : list) {
			RTVDetails rTVDetails = new RTVDetails();
			BeanUtils.copyProperties(user, rTVDetails,"id");
			rTVDetails.setProcessStatus("P");
			rTVDetailsRepositoryMysql.save(rTVDetails);
			user.setProcessStatus("C");
			rTVDetailsOracleRepositoryOracle.save(user);
		}
	}
	
	
	private void dataMoveForPaymentDetailsTbl() throws BeansException {
		List<PaymentDetailsTblOracle> list = null;
		list = paymentDetailsTblOracleRepositoryOracle.findByFirstNameAndLastName();
		for (PaymentDetailsTblOracle user : list) {
			PaymentDetailsTbl paymentDetailsTbl = new PaymentDetailsTbl();
			BeanUtils.copyProperties(user, paymentDetailsTbl,"id");
			paymentDetailsTbl.setProcessStatus("P");
			paymentDetailsTblRepositoryyMysql.save(paymentDetailsTbl);
			user.setProcessStatus("C");
			paymentDetailsTblOracleRepositoryOracle.save(user);
		}
	}
	
	
	private void dataMoveForOpenPODetails() throws BeansException {
		
		List<OpenPODetailsOracle> list = null;
		List<OpenPODetails> newPOsList = new ArrayList<OpenPODetails>();
		list = openPODetailsOracleRepositoryOracle.findByFirstNameAndLastName();
		
		Long po_header_id = null;
		Long rev_no = null;
		
		for (OpenPODetailsOracle user : list) {
			OpenPODetails openPODetails = new OpenPODetails();

			if ("I".equals(user.getProcessStatus())) {

				BeanUtils.copyProperties(user, openPODetails);
				openPODetails.setAsn_reserve_qty((user.getPending_qty()));
				
				// By default set 0 for the change request count
				openPODetails.setChangeRequestCount(0);
				
				newPOsList.add(openPODetails);
				
			} else if ("U".equals(user.getProcessStatus())) {

				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
								
				if(openPODetails != null) {
					
					if(po_header_id == null ) {
						
						po_header_id = openPODetails.getPo_header_id();
						rev_no = user.getRevisionNo();
					}
							
					openPODetails.setQty_ordered(user.getQty_ordered());
					openPODetails.setUnit_price((user.getUnit_price()));
					openPODetails.setNeed_by_date((user.getNeed_by_date()));
					openPODetails.setPending_qty(user.getPending_qty());
					openPODetails.setAsn_reserve_qty(user.getPending_qty());
					openPODetails.setRevisionNo(user.getRevisionNo());
					
					openPODetails.setIsChanged(null);
					
					openPODetails.setReschedule(null);
					
					if(openPODetails.getChangeRequestCount() == 2) {
				   	
					openPODetails.setAck("Y");

				}else if (openPODetails.getChangeRequestCount() == 1) {
					
					openPODetails.setAck(null);
					openPODetails.setBuyer_approval(null);
				}
					
					openPODetails.setBuyer_approval(null);
					
					// need to delete
					OpenPoChangeDetails openPOChengeDetails = openPOChengeDetailsRepositoryMysql.findByHeaderIdAndPoLineLocationId(openPODetails.getHeaderId(),openPODetails.getPoLineLocationId());
					
					if(openPOChengeDetails != null) {
						
						openPOChengeDetailsRepositoryMysql.delete(openPOChengeDetails);
					}
					
				}
			} else if("R".equals(user.getProcessStatus())) {
				
				openPODetails = openPODetailsRepositoryMysql.findPOByHeaderIdAndPoLineLocationId(user.getHeaderId(),
						user.getPoLineLocationId());
				
				if(openPODetails != null) {
					
					openPODetails.setReschedule(user.getReschedule());
					
					if(user.getReschedule() == null) {
						
						openPODetails.setIsChanged(null);
						openPODetails.setBuyer_approval(null);
						
						OpenPoChangeDetails openPOChengeDetails = openPOChengeDetailsRepositoryMysql.findByHeaderIdAndPoLineLocationId(openPODetails.getHeaderId(),openPODetails.getPoLineLocationId());
						
						if(openPOChengeDetails != null) {
							
							openPOChengeDetailsRepositoryMysql.delete(openPOChengeDetails);
						}
						
					}												
				}
				
			}
			
			if(openPODetails != null) {
				
				openPODetails.setProcessStatus("P");
				// openPODetails.setPoLineLocationId(user.getPo_line_location_id());
				openPODetailsRepositoryMysql.save(openPODetails);
				user.setProcessStatus("C");
				
				openPODetailsOracleRepositoryOracle.save(user);
			}
			
		}
		
		// update Rev no to all lines 		
		List<OpenPODetails> allPOLines = openPODetailsRepositoryMysql.findPOBYHeaderId(po_header_id);
		
		if(allPOLines != null && allPOLines.size() > 0) {
			
			for(OpenPODetails  openPO : allPOLines) {
				
				openPO.setRevisionNo(rev_no);
			}
			
			openPODetailsRepositoryMysql.saveAll(allPOLines);
		}
		
		openPODetailsService.sendReminder(newPOsList, 'P');		
		
	}
	
	
	private void dataMoveForInvoiceDetailsTbl() throws BeansException {
		List<InvoiceDetailsTblOracle> list = null;
		list = invoiceDetailsTblOracleRepositoryOracle.findByFirstNameAndLastName();
		for (InvoiceDetailsTblOracle user : list) {
			InvoiceDetailsTbl invoiceDetailsTbl = new InvoiceDetailsTbl();
			BeanUtils.copyProperties(user, invoiceDetailsTbl,"id");
			invoiceDetailsTbl.setProcessStatus("P");
			invoiceDetailsTblRepositoryMysql.save(invoiceDetailsTbl);
			user.setProcessStatus("C");
			invoiceDetailsTblOracleRepositoryOracle.save(user);
		}
	}
	

	private void dataMoveForClosedPODetails() throws BeansException {
		List<ClosedPODetailsOracle> list = null;
		list = closedPODetailsRepositoryOracel.findByFirstNameAndLastName();
		for (ClosedPODetailsOracle user : list) {
			ClosedPODetails ClosedPODetailsMysql = new ClosedPODetails();
			MasterOrganizations masterOrg = masterOrganizationsRepository.findOrganizationByName(user.getOrganization_name());
			BeanUtils.copyProperties(user, ClosedPODetailsMysql,"id");
			
			String asn = user.getShipment_num();
			
			if(masterOrg != null) {
				
				 asn = user.getShipment_num().replaceAll(masterOrg.getOrganization_Id().toString(), "");
			}
			ClosedPODetailsMysql.setShipment_num(asn);
			ClosedPODetailsMysql.setProcessStatus("P");
			closedPODetailsRepositoryMysql.save(ClosedPODetailsMysql);
			user.setProcessStatus("C");
			closedPODetailsRepositoryOracel.save(user);
		}
	}
	
	private void dataMoveForPOAgents() throws BeansException {
		List<POAgentsOracle> list = null;
		list = poAgentsOracleRepositoryOracle.findByFirstNameAndLastName();
		for (POAgentsOracle agent : list) {
			PoAgents agentMysql = new PoAgents();
			
			if ("I".equals(agent.getPoProcessStatus())) {
				
				BeanUtils.copyProperties(agent, agentMysql);
			} else if ("U".equals(agent.getPoProcessStatus())) {
				
				agentMysql = poAgentsRepositoryMysql.findByAgentId(Long.toString(agent.getAgentId()));
				
				if(agentMysql != null) {
					
					agentMysql.setStartDateActive(agent.getStartDateActive());
					agentMysql.setEndDateActive(agent.getEndDateActive());
					
					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					if(agent.getEndDateActive() != null && agent.getEndDateActive().compareTo(date) > 0) {
						
						List<User> users = userRepository.findByAgentId(agent.getAgentId());
						
						for(User user : users) {
							user.setIs_Active('N');
							userRepository.save(user);
						}
						
					}
				}
					
			}
			
			if(agentMysql != null) {
				
				agentMysql.setPoProcessStatus("P");
				poAgentsRepositoryMysql.save(agentMysql);
				agent.setPoProcessStatus("C");
				poAgentsOracleRepositoryOracle.save(agent);
				
			}
		}
	}
	
	private void dataMoveForSuppliers() throws BeansException {
		List<ApSuppliersOracle> list = null;
		list = apSuppliersOracleRepository.findByFirstNameAndLastName();
		for (ApSuppliersOracle supplerPo : list) {
			ApSuppliers supplierMysql = new ApSuppliers();
			
			if ("I".equals(supplerPo.getProcessStatus())) {
				
				BeanUtils.copyProperties(supplerPo, supplierMysql);
			} else if ("U".equals(supplerPo.getProcessStatus())) {
				
				supplierMysql = apSuppliersMysqlRepository.findByVendorIDId(Long.toString(supplerPo.getVendor_id()));
				
				if(supplierMysql != null) {
					
					supplierMysql.setStart_date_active(supplerPo.getStart_date_active());
					supplierMysql.setEnd_date_active(supplerPo.getEnd_date_active());
					
					java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
					
					if(date != null && supplerPo.getEnd_date_active() != null && date.compareTo(supplerPo.getEnd_date_active()) > 0) {
						
						List<User> users = userRepository.findByVendorId(supplerPo.getVendor_id());
						
						for(User user : users) {
							user.setIs_Active('N');
							userRepository.save(user);
						}
						
					}
					
				}
			}
			
			if(supplierMysql != null) {
								
				supplierMysql.setProcessStatus("P");
				apSuppliersMysqlRepository.save(supplierMysql);
				supplerPo.setProcessStatus("C");
				apSuppliersOracleRepository.save(supplerPo);
			}
		}
	}
	
	private void dataMoveForPrePaymentInvoiceDetails() throws BeansException {
		List<PrePaymentInvoiceOracle> list = null;
		list = prePaymentInvoiceDetailsOracleRepository.findAllNewPrePayments();
		for (PrePaymentInvoiceOracle prePaymentOracle : list) {
			PrePaymentInvoice prePayment = new PrePaymentInvoice();
			BeanUtils.copyProperties(prePaymentOracle, prePayment,"id");
			prePayment.setPoProcessStatus("P");
			prePaymentInvoiceDetailsRepository.save(prePayment);
			prePaymentOracle.setPoProcessStatus("C");
			prePaymentInvoiceDetailsOracleRepository.save(prePaymentOracle);
		}
	}
	
	private void dataMoveForDebitNoteDetails() throws BeansException {
		List<DebitNoteOracle> list = null;
		list = debitNoteOracleRepository.findAllDebitNotes();
		for (DebitNoteOracle debitNoteOracle : list) {
			DebitNote debitNote = new DebitNote();
			BeanUtils.copyProperties(debitNoteOracle, debitNote,"id");
			debitNote.setPoProcessStatus("P");
			debitNoteRepository.save(debitNote);
			debitNoteOracle.setPoProcessStatus("C");
			debitNoteOracleRepository.save(debitNoteOracle);
		}
	}
	
	private void dataMoveForPendingInvoiceDetails() throws BeansException {
		List<PendingInvoiceOracle> list = null;
		list = pendingInvoiceOracleRepository.findAllPendingInvoice();
		for (PendingInvoiceOracle pendingInvoiceOracle : list) {
			PendingInvoice pendingInvoice = new PendingInvoice();
			BeanUtils.copyProperties(pendingInvoiceOracle, pendingInvoice,"id");
			pendingInvoice.setPoProcessStatus("P");
			pendingInvoiceRepository.save(pendingInvoice);
			pendingInvoiceOracle.setPoProcessStatus("C");
			pendingInvoiceOracleRepository.save(pendingInvoiceOracle);
		}
	}
	
	
	private void dataMoveForMasterItemsDetails() throws BeansException {
		List<MasterItemsOracle> list = null;
		list = masterItemsOracleRepository.findAllMasterItems();
		for (MasterItemsOracle masterItemOracle : list) {
			MasterItems masterItem = new MasterItems();
			BeanUtils.copyProperties(masterItemOracle, masterItem);
			masterItem.setPoProcessStatus("P");
			masterItemsRepository.save(masterItem);
			masterItemOracle.setPoProcessStatus("C");
			masterItemsOracleRepository.save(masterItemOracle);
		}
	}
	
	private void dataMoveForMasterOrganizationsDetails() throws BeansException {
		List<MasterOrganizationsOracle> list = null;
		list = masterOrganizationsOracleRepository.findAllOrganizations();
		for (MasterOrganizationsOracle masterOrgOracle : list) {
			MasterOrganizations masterOrg = new MasterOrganizations();
			BeanUtils.copyProperties(masterOrgOracle, masterOrg);
			masterOrg.setPoProcessStatus("P");
			masterOrganizationsRepository.save(masterOrg);
			masterOrgOracle.setPoProcessStatus("C");
			masterOrganizationsOracleRepository.save(masterOrgOracle);
		}
	}
	
	private void dataMoveForOperatingUnitDetails() throws BeansException {
		List<OperatingUnitsOracle> list = null;
		list = operatingUnitsOracleRepository.findAllOperatingUnits();
		for (OperatingUnitsOracle ouOracle : list) {
			OperatingUnits ou = new OperatingUnits();
			BeanUtils.copyProperties(ouOracle, ou);
			ou.setPoProcessStatus("P");
			operatingUnitsRepository.save(ou);
			ouOracle.setPoProcessStatus("C");
			operatingUnitsOracleRepository.save(ouOracle);
		}
	}
	
	private void dataMoveForLocationDetails() throws BeansException {
		List<LocationsOracle> list = null;
		list = locationsOracleRepository.findAllLocations();
		for (LocationsOracle locationsOracle : list) {
			Locations locations = new Locations();
			BeanUtils.copyProperties(locationsOracle, locations);
			locations.setPoProcessStatus("P");
			locationsRepository.save(locations);
			locationsOracle.setPoProcessStatus("C");
			locationsOracleRepository.save(locationsOracle);
		}
	}
	
	private void dataMoveForSupplierSitesDetails() throws BeansException {
		List<SupplierSitesOracle> list = null;
		list = supplierSitesOracleRepository.findAllSupplierSites();
		for (SupplierSitesOracle supplierSitesOracle : list) {
			SupplierSites supplierSites = new SupplierSites();
			BeanUtils.copyProperties(supplierSitesOracle, supplierSites);
			supplierSites.setPoProcessStatus("P");
			supplierSitesRepository.save(supplierSites);
			supplierSitesOracle.setPoProcessStatus("C");
			supplierSitesOracleRepository.save(supplierSitesOracle);
		}
	}
	
	private void dataMoveForUOMDetails() throws BeansException {
		List<UOMOracle> list = null;
		list = uOMOracleRepository.findAllUOM();
		for (UOMOracle uomOracle : list) {
			UOM uom = new UOM();
			BeanUtils.copyProperties(uomOracle, uom);
			uom.setPoProcessStatus("P");
			uOMRepository.save(uom);
			uomOracle.setPoProcessStatus("C");
			uOMOracleRepository.save(uomOracle);
		}
	}
	

}*/