package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ASN_DETAILS")
public class ASNDetails{
	
	@Id
	@SequenceGenerator(name = "ASN_DETAILS_SEQ", sequenceName = "ASN_DETAILS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ASN_DETAILS_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "OPEN_PO_ID")
	private Long open_po_id;
	
	@Column(name="PO_HEADER_ID")
	private Long po_header_id;	
	
	@Column(name="PO_LINE_LOCATION_ID")
	private long poLineLocationId;
	
	@Column(name="ASN_QTY")
	private Double asn_qty;
	
	// act as ASN / SCN
	@Column(name="ASN")
	private String asn;
	
	@Column(name="ASN_AMOUNT")
	private Double asn_amount;
	
	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(Long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public long getPoLineLocationId() {
		return poLineLocationId;
	}

	public void setPoLineLocationId(long poLineLocationId) {
		this.poLineLocationId = poLineLocationId;
	}
	
	public ASNDetails() {
		
	}
	
	public Double getAsn_qty() {
		return asn_qty;
	}

	public void setAsn_qty(Double asn_qty) {
		this.asn_qty = asn_qty;
	}

	public Double getAsn_amount() {
		return asn_amount;
	}

	public void setAsn_amount(Double asn_amount) {
		this.asn_amount = asn_amount;
	}

	public Long getOpen_po_id() {
		return open_po_id;
	}

	public void setOpen_po_id(Long open_po_id) {
		this.open_po_id = open_po_id;
	}

}