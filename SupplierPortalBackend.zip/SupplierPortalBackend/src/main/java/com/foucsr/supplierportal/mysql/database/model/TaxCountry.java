package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAX_COUNTRY")
public class TaxCountry {

	@Id
	@SequenceGenerator(name = "TAX_COUNTRY_SEQ", sequenceName = "TAX_COUNTRY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TAX_COUNTRY_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "TERRITORY_CODE")
	private String territory_code;

	@Column(name = "TERRITORY_SHORT_NAME")
	private String territory_short_name;

	@Column(name = "PO_PROCESS_STATUS")
	private String po_process_status;

	public String getTerritory_code() {
		return territory_code;
	}

	public void setTerritory_code(String territory_code) {
		this.territory_code = territory_code;
	}

	public String getTerritory_short_name() {
		return territory_short_name;
	}

	public void setTerritory_short_name(String territory_short_name) {
		this.territory_short_name = territory_short_name;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}