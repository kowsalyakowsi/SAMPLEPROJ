package com.foucsr.supplierportal.oracle.database.model;

public class TaxCountryOracle {

	private Long id;
	
	private String territory_code;

	private String territory_short_name;

	private String po_process_status;

	public String getTerritory_code() {
		return territory_code;
	}

	public void setTerritory_code(String territory_code) {
		this.territory_code = territory_code;
	}

	public String getTerritory_short_name() {
		return territory_short_name;
	}

	public void setTerritory_short_name(String territory_short_name) {
		this.territory_short_name = territory_short_name;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}