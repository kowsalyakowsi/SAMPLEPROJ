package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.PaymentDetailsTbl;

@Repository
public interface PaymentDetailsTblRepository extends CrudRepository<PaymentDetailsTbl, Long> {
	   
	
    @Override
    Iterable<PaymentDetailsTbl> findAll();
    
    @Query(value = "select * from PAYMENTS_DETAILS_TBL where vendor_id = :vendorId order by PAYMENT_NUMBER DESC", nativeQuery = true)
    List<PaymentDetailsTbl> getPaymentDetailsByVendorId(@Param("vendorId") String vendorId );
    
    @Query(value = "select * from PAYMENTS_DETAILS_TBL where  VENDOR_ID =:vendorId and PAYMENT_DATE between STR_TO_DATE(:fromDate,'%Y-%m-%d') and STR_TO_DATE(:toDate,'%Y-%m-%d') order by PAYMENT_NUMBER DESC", nativeQuery = true)
    List<PaymentDetailsTbl> getPaymentDetailsByAllParm(@Param("fromDate") String fromDates,@Param("toDate") String toDates ,@Param("vendorId") String vendorId);
    
   
    @Query(value = "select * from PAYMENTS_DETAILS_TBL where  VENDOR_ID =:vendorId and AP_INV_NUMER =:value order by PAYMENT_NUMBER DESC", nativeQuery = true)
    List<PaymentDetailsTbl> getPaymentDetailsByInvNum(@Param("value") String value,@Param("vendorId") String vendorId);
    
    
    @Query(value = "select * from PAYMENTS_DETAILS_TBL where  VENDOR_ID =:vendorId and PAYMENT_NUMBER =:value order by PAYMENT_NUMBER DESC", nativeQuery = true)
    List<PaymentDetailsTbl> getPaymentDetailsByPayNum(@Param("value") String value,@Param("vendorId") String vendorId);
    
    
    @Query(value = "select * from PAYMENTS_DETAILS_TBL where  VENDOR_ID =:vendorId and PO_NUMBER =:value order by PAYMENT_NUMBER DESC", nativeQuery = true)
    List<PaymentDetailsTbl> getPaymentDetailsByPONum(@Param("value") String value,@Param("vendorId") String vendorId);

    @Query(value = "select * from PAYMENTS_DETAILS_TBL where ID =:id ", nativeQuery = true)
    PaymentDetailsTbl getPaymentDetailsById(@Param("id") Long id);


}