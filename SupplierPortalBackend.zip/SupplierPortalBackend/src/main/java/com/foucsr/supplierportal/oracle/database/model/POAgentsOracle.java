package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class POAgentsOracle {

	@JsonProperty("EKGRP")
	private long agentId;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date lastUpdateDate;

	private long lastUpdatedBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date creationDate;

	private long createdBy;

	private long lastUpdateLogin;

	private Long locationId;

	private Long categoryId;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date startDateActive;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date endDateActive;

	private String isContractOfficer;
	
	@JsonProperty("PROCESSSTATUS")
	private String poProcessStatus;
	
	@JsonProperty("EKNAM")
	private String agentName;
	
	private Long business_group_id;
	
	public POAgentsOracle() {

	}

	public long getAgentId() {
		return agentId;
	}

	public void setAgentId(long agentId) {
		this.agentId = agentId;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public long getLastUpdateLogin() {
		return lastUpdateLogin;
	}

	public void setLastUpdateLogin(long lastUpdateLogin) {
		this.lastUpdateLogin = lastUpdateLogin;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Date getStartDateActive() {
		return startDateActive;
	}

	public void setStartDateActive(Date startDateActive) {
		this.startDateActive = startDateActive;
	}

	public Date getEndDateActive() {
		return endDateActive;
	}

	public void setEndDateActive(Date endDateActive) {
		this.endDateActive = endDateActive;
	}

	public String getIsContractOfficer() {
		return isContractOfficer;
	}

	public void setIsContractOfficer(String isContractOfficer) {
		this.isContractOfficer = isContractOfficer;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Long getBusiness_group_id() {
		return business_group_id;
	}

	public void setBusiness_group_id(Long business_group_id) {
		this.business_group_id = business_group_id;
	}

}