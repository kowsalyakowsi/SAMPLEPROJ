package com.foucsr.supplierportal.mysql.database.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ASN_NUMBER")
public class ASNNumber {
	
	@Id	
	@SequenceGenerator(name = "ASN_NUMBER_SEQ", sequenceName = "ASN_NUMBER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ASN_NUMBER_SEQ")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "NEXT_NUM")
	private Long next_num;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getNext_num() {
		return next_num;
	}

	public void setNext_num(Long next_num) {
		this.next_num = next_num;
	}
	
			
}