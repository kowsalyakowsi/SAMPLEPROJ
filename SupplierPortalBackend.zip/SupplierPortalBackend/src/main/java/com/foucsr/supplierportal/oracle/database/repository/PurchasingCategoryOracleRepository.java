package com.foucsr.supplierportal.oracle.database.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.oracle.database.model.PurchasingCategoryOracle;

@Repository
public interface PurchasingCategoryOracleRepository extends CrudRepository<PurchasingCategoryOracle, Long> {

//	@Query(value = "select * from XX_PURCHASING_CATEGORIES where PO_PROCESS_STATUS='I'", nativeQuery = true)
//	List<PurchasingCategoryOracle> findByFirstNameAndLastName();

}