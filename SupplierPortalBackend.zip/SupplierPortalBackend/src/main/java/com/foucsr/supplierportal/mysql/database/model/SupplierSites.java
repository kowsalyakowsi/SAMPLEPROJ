package com.foucsr.supplierportal.mysql.database.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "SUPPLIER_SITES")
public class SupplierSites {
	
	@Id
	@Column(name = "VENDOR_SITE_ID")
	private Long vendor_site_id;

	@Column(name = "VENDOR_ID")
	private long vendorId;

	@Column(name = "VENDOR_SITE_CODE")
	private String vendor_site_code;

	@Column(name = "VENDOR_SITE_CODE_ALT")
	private String vendor_site_code_alt;

	@Column(name = "ADDRESS_LINE1")
	private String address_line1;

	@Column(name = "ADDRESS_LINES_ALT")
	private String address_lines_alt;

	@Column(name = "ADDRESS_LINE2")
	private String address_line2;

	@Column(name = "ADDRESS_LINE3")
	private String address_line3;

	@Column(name = "CITY")
	private String city;

	@Column(name = "STATE")
	private String state;

	@Column(name = "ZIP")
	private String zip;

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "AREA_CODE")
	private String area_code;

	@Column(name = "PHONE")
	private String phone;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "INACTIVE_DATE")
	private Date inactive_date;
	
	@Column(name = "OU_ID")
	private Long ou_id;

	@Column(name = "PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "VENDOR_ID" , insertable = false, updatable = false)
	private ApSuppliers supplier;
	
	public SupplierSites() {

	}

	public Long getVendor_site_id() {
		return vendor_site_id;
	}

	public void setVendor_site_id(Long vendor_site_id) {
		this.vendor_site_id = vendor_site_id;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getVendor_site_code_alt() {
		return vendor_site_code_alt;
	}

	public void setVendor_site_code_alt(String vendor_site_code_alt) {
		this.vendor_site_code_alt = vendor_site_code_alt;
	}

	public String getAddress_line1() {
		return address_line1;
	}

	public void setAddress_line1(String address_line1) {
		this.address_line1 = address_line1;
	}

	public String getAddress_lines_alt() {
		return address_lines_alt;
	}

	public void setAddress_lines_alt(String address_lines_alt) {
		this.address_lines_alt = address_lines_alt;
	}

	public String getAddress_line2() {
		return address_line2;
	}

	public void setAddress_line2(String address_line2) {
		this.address_line2 = address_line2;
	}

	public String getAddress_line3() {
		return address_line3;
	}

	public void setAddress_line3(String address_line3) {
		this.address_line3 = address_line3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getArea_code() {
		return area_code;
	}

	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getInactive_date() {
		return inactive_date;
	}

	public void setInactive_date(Date inactive_date) {
		this.inactive_date = inactive_date;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	@JsonIgnore
	public ApSuppliers getSuppliers() {
		return supplier;
	}

	public void setSuppliers(ApSuppliers supplier) {
		this.supplier = supplier;
	}

	public Long getOu_id() {
		return ou_id;
	}

	public void setOu_id(Long ou_id) {
		this.ou_id = ou_id;
	}
	
}