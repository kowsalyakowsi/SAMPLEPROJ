package com.foucsr.supplierportal.mysql.database.model;

public interface  ClosedPOStatusListProjection {

	
     String getPo_status();
	

}