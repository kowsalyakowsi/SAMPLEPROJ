package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.SuppliersRegister;

@Repository
public interface SupplierRegisterRepository extends CrudRepository<SuppliersRegister, Long> {
	  
    
   @Query(value = "select * from SUPPLIERS_REGISTER where id = :id", nativeQuery = true)
   SuppliersRegister getSupplierById(@Param("id") Long id );
   
   
   @Query(value = "select * from SUPPLIERS_REGISTER where BUYER_ID = :buyerId ORDER BY CREATEDAT ASC", nativeQuery = true)
   List<SuppliersRegister> getAllRegisteredSupplierList(@Param("buyerId") Long buyerId );
   
   
   @Query(value = "select * from SUPPLIERS_REGISTER where IS_SEND_TO_SUPPLIER_CREATION = 'Y' AND PO_PROCESS_STATUS = 'I' ORDER BY CREATEDAT ASC", nativeQuery = true)
   List<SuppliersRegister> findAllRegisterdSuppliersToMoveOracle();
    
  
}