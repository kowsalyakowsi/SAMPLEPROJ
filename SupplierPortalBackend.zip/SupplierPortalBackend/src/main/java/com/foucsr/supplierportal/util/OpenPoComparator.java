package com.foucsr.supplierportal.util;

import java.util.Comparator;

import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;

public class OpenPoComparator implements Comparator<OpenPODetails> {
	
	
    public int compare(OpenPODetails o1, OpenPODetails o2) {
        int value1 = o1.getPo_num().compareTo(o2.getPo_num());
        if (value1 == 0) {
            int value2 = o1.getPo_line_num().compareTo(o2.getPo_line_num());
            if (value2 == 0) {
                return o1.getShipment_num().compareTo(o2.getShipment_num());
            } else {
                return value2;
            }
        }
        return value1;
    }
}