package com.foucsr.supplierportal.oracle.database.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class LocationsOracle {

	private Long location_id;

	private String location_code;

	private String description;

	private long ship_to_location_id;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date inactive_date;

	private String address_line_1;

	private String address_line_2;

	private String address_line_3;

	private String town_or_city;

	private String country;

	private String postal_code;

	private String region_1;

	private String region_2;

	private String region_3;

	private String telephone_number_1;

	private String telephone_number_2;

	private String telephone_number_3;

	private String derived_locale;

	private String timezone_code;

	private Long inventory_organization_id;

	private String poProcessStatus;

	public LocationsOracle() {

	}

	public Long getLocation_Id() {
		return location_id;
	}

	public void setLocation_Id(Long location_id) {
		this.location_id = location_id;
	}

	public String getLocation_code() {
		return location_code;
	}

	public void setLocation_code(String location_code) {
		this.location_code = location_code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getShip_to_location_id() {
		return ship_to_location_id;
	}

	public void setShip_to_location_id(long ship_to_location_id) {
		this.ship_to_location_id = ship_to_location_id;
	}

	public Date getInactive_date() {
		return inactive_date;
	}

	public void setInactive_date(Date inactive_date) {
		this.inactive_date = inactive_date;
	}

	public String getAddress_line_1() {
		return address_line_1;
	}

	public void setAddress_line_1(String address_line_1) {
		this.address_line_1 = address_line_1;
	}

	public String getAddress_line_2() {
		return address_line_2;
	}

	public void setAddress_line_2(String address_line_2) {
		this.address_line_2 = address_line_2;
	}

	public String getAddress_line_3() {
		return address_line_3;
	}

	public void setAddress_line_3(String address_line_3) {
		this.address_line_3 = address_line_3;
	}

	public String getTown_or_city() {
		return town_or_city;
	}

	public void setTown_or_city(String town_or_city) {
		this.town_or_city = town_or_city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostal_code() {
		return postal_code;
	}

	public void setPostal_code(String postal_code) {
		this.postal_code = postal_code;
	}

	public String getRegion_1() {
		return region_1;
	}

	public void setRegion_1(String region_1) {
		this.region_1 = region_1;
	}

	public String getRegion_2() {
		return region_2;
	}

	public void setRegion_2(String region_2) {
		this.region_2 = region_2;
	}

	public String getRegion_3() {
		return region_3;
	}

	public void setRegion_3(String region_3) {
		this.region_3 = region_3;
	}

	public String getTelephone_number_1() {
		return telephone_number_1;
	}

	public void setTelephone_number_1(String telephone_number_1) {
		this.telephone_number_1 = telephone_number_1;
	}

	public String getTelephone_number_2() {
		return telephone_number_2;
	}

	public void setTelephone_number_2(String telephone_number_2) {
		this.telephone_number_2 = telephone_number_2;
	}

	public String getTelephone_number_3() {
		return telephone_number_3;
	}

	public void setTelephone_number_3(String telephone_number_3) {
		this.telephone_number_3 = telephone_number_3;
	}

	public String getDerived_locale() {
		return derived_locale;
	}

	public void setDerived_locale(String derived_locale) {
		this.derived_locale = derived_locale;
	}

	public String getTimezone_code() {
		return timezone_code;
	}

	public void setTimezone_code(String timezone_code) {
		this.timezone_code = timezone_code;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public Long getInventory_organization_id() {
		return inventory_organization_id;
	}

	public void setInventory_organization_id(Long inventory_organization_id) {
		this.inventory_organization_id = inventory_organization_id;
	}

}