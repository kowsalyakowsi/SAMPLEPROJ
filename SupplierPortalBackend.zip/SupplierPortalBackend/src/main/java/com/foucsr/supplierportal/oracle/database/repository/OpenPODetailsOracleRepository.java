package com.foucsr.supplierportal.oracle.database.repository;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.foucsr.supplierportal.mysql.database.model.OpenPODetails;
import com.foucsr.supplierportal.oracle.database.model.OpenPODetailsOracle;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.JobSchedulerSAP;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class OpenPODetailsOracleRepository {
	
	Logger log = LoggerFactory.getLogger(OpenPODetailsOracleRepository.class);

//    @Query(value = "select * from XX_OPEN_PO_TBL where PO_PROCESS_STATUS='I' OR PO_PROCESS_STATUS='U' OR PO_PROCESS_STATUS='R'", nativeQuery = true)
//    List<OpenPODetailsOracle> findByFirstNameAndLastName();

	public List<OpenPODetailsOracle> findByFirstNameAndLastName() {

		RestTemplate restTemplate = new RestTemplate();
		
		String openPOURL = AppConstants.SAP_GENERIC_URL_PREFIX + "zser_open_po?sap-client=800";

		ResponseEntity<OpenPODetailsOracle[]> response = restTemplate.getForEntity(
				openPOURL , OpenPODetailsOracle[].class);

		OpenPODetailsOracle[] openPODetails = response.getBody();

		List<OpenPODetailsOracle> openPOlist = Arrays.asList(openPODetails);

		if (openPOlist == null) {

			openPOlist = new ArrayList<OpenPODetailsOracle>();
		}

		return openPOlist;
	}

	public void updatePOProcess(OpenPODetailsOracle openPO) throws URISyntaxException, JsonProcessingException {

		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "https://einv-apisandbox.nic.in/gstvital/v1.01/auth/{HEADERID}";

		/*
		 * URI uri = new URI(baseUrl);
		 * 
		 * Map<String, List<OpenPODetailsOracle> > bodyParamMap = new HashMap<String,
		 * List<OpenPODetailsOracle> >(); bodyParamMap.put("", openPOs);
		 * 
		 * 
		 * String reqBodyData = new ObjectMapper().writeValueAsString(bodyParamMap);
		 * 
		 * HttpEntity<String> requestEnty = new HttpEntity<>(reqBodyData);
		 * 
		 * ResponseEntity<String> result = restTemplate.put(uri, requestEnty);
		 */

		Map<String, String> params = new HashMap<String, String>();
		params.put("HEADERID", "110");

		restTemplate.put(baseUrl, openPO, params);

	}

	/*
	 * private static SOAPMessage createSOAPRequest(String documentId, String
	 * fileToUpdate) throws Exception {
	 * 
	 * MessageFactory messageFactory = MessageFactory.newInstance(); SOAPMessage
	 * soapMessage = messageFactory.createMessage(); SOAPPart soapPart =
	 * soapMessage.getSOAPPart(); String serverURI =
	 * "urn:sap-com:document:sap:rfc:functions"; SOAPEnvelope envelope =
	 * soapPart.getEnvelope();
	 * 
	 * envelope.addNamespaceDeclaration("urn", serverURI); // this line will add
	 * namespece in your envelope
	 * 
	 * SOAPBody soapBody = envelope.getBody(); SOAPBodyElement element =
	 * soapBody.addBodyElement(envelope.createName("ZAPI_SUPPLIER_LIST_FM", "urn",
	 * "")); element.addChildElement("docID").addTextNode(documentId);
	 * element.addChildElement("input").addTextNode(fileToUpdate);
	 * element.addChildElement("input").add soapMessage.saveChanges(); return
	 * soapMessage; }
	 */

	private void createSoapEnvelope(SOAPMessage soapMessage) throws SOAPException {

		SOAPPart soapPart = soapMessage.getSOAPPart();
		String serverURI = "urn:sap-com:document:sap:rfc:functions";
		SOAPEnvelope envelope = soapPart.getEnvelope();

		envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

		SOAPBody soapBody = envelope.getBody();
		SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZAPI_SUPPLIER_LIST_FM", "urn", ""));
		 bodyElement.addChildElement("GET").addTextNode("X");
		 SOAPElement it_ven_element = bodyElement.addChildElement("IT_VEN");

		 addItems(it_ven_element);
		 
		soapMessage.saveChanges();
	}

	public void callSoapWebService() {
		
		String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zapi_testuser/200/zapi_testuser/zapi_testuser?sap-client=200";
		
		String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zapi_testuser/200/zapi_testuser/zapi_testuser";
		
		
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(soapAction), soapEndpointUrl);

			// Print the SOAP Response
//			System.out.println("Response SOAP Message:");
//			soapResponse.writeTo(System.out);
//			System.out.println();

			soapConnection.close();
		} catch (Exception e) {
			System.err.println(
					"\nError occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
			e.printStackTrace();
		}
	}

	private SOAPMessage createSOAPRequest(String soapAction) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();

		createSoapEnvelope(soapMessage);

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", soapAction);
//		headers.addHeader("UserName", "DEVELOPER");
//		headers.addHeader("Pswrd", "WELCOME");
		
		String loginPassword = "developer:saphana2";
		
		soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


		soapMessage.saveChanges();

		/* Print the request message, just for debugging purposes */
//		System.out.println("Request SOAP Message:");
//		soapMessage.writeTo(System.out);
//		System.out.println("\n");

		return soapMessage;
	}

	private void addItems(SOAPElement it_ven_element) throws SOAPException {

		QName itemQ = new QName("item");
		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);

		itemQ = new QName("MANDT");
		SOAPElement mandtElement = itemElement.addChildElement(itemQ);
		mandtElement.addTextNode("200");

		itemQ = new QName("EMAIL");
		SOAPElement emailElement = itemElement.addChildElement(itemQ);
		emailElement.addTextNode("mg@focusrtech.com");
		
		itemQ = new QName("FIRSTNAME");
		SOAPElement firstNameElement = itemElement.addChildElement(itemQ);
		firstNameElement.addTextNode("M");

		
		itemQ = new QName("LASTNAME");
		SOAPElement lastNameElement = itemElement.addChildElement(itemQ);
		lastNameElement.addTextNode("G");

	}
	
    public void ackOpenPObySOAPService(List<OpenPODetails> savedPOsList) {
		
		String soapAction = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/wsdl/flv_10002A111AD1/srvc_url/sap/bc/srt/rfc/sap/zser_open_po_ack/800/zser_open_po_ack/bind1?sap-client=800";
		
		String soapEndpointUrl = AppConstants.SAP_GENERIC_URL_PREFIX + "srt/rfc/sap/zser_open_po_ack/800/zser_open_po_ack/bind1";
		
		
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			SOAPMessage soapResponse = soapConnection.call(createAckOpenPOSOAPRequest(soapAction , savedPOsList), soapEndpointUrl);

			// Print the SOAP Response
			System.out.println("Response SOAP Message:");
			soapResponse.writeTo(System.out);
			System.out.println();

			soapConnection.close();
		} catch (Exception e) {
			log.info("***************** Error occurred while sending ACK PO SOAP Request to Server!\\nMake sure you have the correct endpoint URL and SOAPAction!  *********************\n" + e);
		}
	}
    
    private SOAPMessage createAckOpenPOSOAPRequest(String soapAction , List<OpenPODetails> savedPOsList) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();

		createAckOpenPOSoapEnvelope(soapMessage ,  savedPOsList);

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", soapAction);
		
		String loginPassword = "developer:saphana2";
		
		soapMessage.getMimeHeaders().addHeader("Authorization", "Basic " + new  String(org.apache.commons.codec.binary.Base64.encodeBase64String(loginPassword.getBytes())));


		soapMessage.saveChanges();

		/* Print the request message, just for debugging purposes */
//		System.out.println("Request SOAP Message:");
//		soapMessage.writeTo(System.out);
//		System.out.println("\n");

		return soapMessage;
	}

    
    private void createAckOpenPOSoapEnvelope(SOAPMessage soapMessage , List<OpenPODetails> savedPOsList) throws SOAPException {

		SOAPPart soapPart = soapMessage.getSOAPPart();
		String serverURI = "urn:sap-com:document:sap:rfc:functions";
		SOAPEnvelope envelope = soapPart.getEnvelope();

		envelope.addNamespaceDeclaration("urn", serverURI); // this line will add namespece in your envelope

		SOAPBody soapBody = envelope.getBody();
		SOAPBodyElement bodyElement = soapBody.addBodyElement(envelope.createName("ZVEN_OPEN_PO_REC", "urn", ""));
		 bodyElement.addChildElement("INPUT").addTextNode("ACKOPENPO");
		 SOAPElement it_ven_element = bodyElement.addChildElement("IT_DATA");

		 addOpenPOItems(it_ven_element ,  savedPOsList);
		 
		soapMessage.saveChanges();
	}

    private void addOpenPOItems(SOAPElement it_ven_element , List<OpenPODetails> savedPOsList) throws SOAPException {
    	    	
    	
    	for(OpenPODetails openPo : savedPOsList) {
    		
    		QName itemQ = new QName("item");
    		SOAPElement itemElement = it_ven_element.addChildElement(itemQ);
    		
    		itemQ = new QName("HEADERID");
    		SOAPElement mandtElement = itemElement.addChildElement(itemQ);
    		mandtElement.addTextNode(Long.toString(openPo.getHeaderId()));    	
    		
    		
    		itemQ = new QName("PO_HEADER_ID");
    		SOAPElement poHeaderId = itemElement.addChildElement(itemQ);
    		poHeaderId.addTextNode(Long.toString(openPo.getPo_header_id()));
    		
    		itemQ = new QName("PO_LINE_LOCATION_ID");
    		SOAPElement poLineLocationId = itemElement.addChildElement(itemQ);
    		poLineLocationId.addTextNode(Long.toString(openPo.getPoLineLocationId()));
    		
    		itemQ = new QName("PO_NUM");
    		SOAPElement poNumber = itemElement.addChildElement(itemQ);
    		poNumber.addTextNode(openPo.getPo_num());
    		
    		itemQ = new QName("PO_LINE_NO");
    		SOAPElement poLineNumber = itemElement.addChildElement(itemQ);
    		poLineNumber.addTextNode(Long.toString(openPo.getPo_line_num()));
    		
    		itemQ = new QName("PROCESSSTATUS");
    		SOAPElement processStatus = itemElement.addChildElement(itemQ);
    		processStatus.addTextNode(openPo.getProcessStatus());
    		
    	}


	}

}