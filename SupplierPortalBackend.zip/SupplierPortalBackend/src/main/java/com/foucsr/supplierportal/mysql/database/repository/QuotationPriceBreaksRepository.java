package com.foucsr.supplierportal.mysql.database.repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.QuotationPriceBreaks;

@Repository
public interface QuotationPriceBreaksRepository extends CrudRepository<QuotationPriceBreaks, Long> {

	
    @Override
    Iterable<QuotationPriceBreaks> findAll();
    
    @Query(value = "SELECT * FROM QUOTATION_PRICE_BREAKS  WHERE ID = :id", nativeQuery = true)
    QuotationPriceBreaks findPriceBreak(@Param("id") Long id );


}