package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.RFQTypes;

@Repository
public interface RFQTypeRepository extends CrudRepository<RFQTypes, Long> {

	
    @Override
    Iterable<RFQTypes> findAll();
    
    @Query(value = "select * from RFQ_TYPES order by NAME", nativeQuery = true)
    List<RFQTypes> findAllValid();

}