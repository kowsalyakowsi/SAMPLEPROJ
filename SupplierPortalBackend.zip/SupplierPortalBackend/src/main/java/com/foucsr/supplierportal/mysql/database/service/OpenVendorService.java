package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.oracle.database.model.OpenVendorOracle;
import com.foucsr.supplierportal.oracle.database.repository.OpenVendorOracleRepository;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.ReportFilterRequest;
import com.foucsr.supplierportal.util.SCAUtil;

@Service
public class OpenVendorService {

	Logger logger = LoggerFactory.getLogger(OpenVendorService.class);
	
	
	@Autowired
   	private OpenVendorOracleRepository openVendorOracleRepository;
	

	public ResponseEntity<?> getOpenVendorList(ReportFilterRequest byDateRequest) {
		
		if(byDateRequest.getPlant() == null) {
			
			return new ResponseEntity(new ApiResponse(false, "Plant is mandatory! Please choose" ),
					HttpStatus.BAD_REQUEST);
		}

		List<OpenVendorOracle> list = null;
		SCAUtil scaUtil = new SCAUtil() ;

//		String vendor_id = byDateRequest.getVendorId().toString();
		
		try {
			
		String fromDate = byDateRequest.getFromDate() != null ? byDateRequest.getFromDate().replaceAll("-", "") : "";
		String toDate = byDateRequest.getToDate() != null ? byDateRequest.getToDate().replaceAll("-", "") : "";
		String plant = byDateRequest.getPlant();
			
			list = openVendorOracleRepository.findLatestOpenVendor(fromDate, toDate, plant);

		} catch (Exception e) {
			
			logger.info("***************** Unable to get Open Vendor details *********************\n" + e);
			
			String msg = scaUtil.getErrorMessage(e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable get Open Vendor details!" + msg),
					HttpStatus.BAD_REQUEST);
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<OpenVendorOracle>();
			
		}

		return new ResponseEntity(list, HttpStatus.OK);

	}

}
