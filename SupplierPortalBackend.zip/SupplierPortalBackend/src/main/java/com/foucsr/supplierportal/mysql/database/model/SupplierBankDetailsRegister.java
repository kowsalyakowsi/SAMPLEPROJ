package com.foucsr.supplierportal.mysql.database.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SUPPLIER_BANK_DETAILS_REGISTER")

public class SupplierBankDetailsRegister {

	@Id
	@SequenceGenerator(name = "SUPPLIER_BANK_DETAILS_REGISTER_SEQ", sequenceName = "SUPPLIER_BANK_DETAILS_REGISTER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SUPPLIER_BANK_DETAILS_REGISTER_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "BANK_NAME")
	private String bank_name;

	@Column(name = "BANK_NUM")
	private String bank_num;

	@Column(name = "BRANCH_TYPE")
	private String branch_type;

	@Column(name = "IFSC")
	private String ifsc;

	@Column(name = "SWIFT_CODE")
	private String swift_code;

	@Column(name = "BIC")
	private String bic;

	@Column(name = "ACCOUNT_NUM")
	private String account_num;

	@Column(name = "ACCOUNT_NAME")
	private String account_name;

	@Column(name = "CHECK_DIGITS")
	private String check_digits;

	@Column(name = "CURRENCY")
	private String currency_code;

	@Column(name = "IBAN")
	private String iban;

	@Column(name = "NOTES")
	private String notes;
	
	@Column(name="PO_PROCESS_STATUS")
	private String poProcessStatus;
	
	@Column(name = "SUPPLIER_REGISTER_ID")
	private Long supplier_register_id;
	
	@Column(name = "IS_SEND_TO_SUPPLIER_CREATION")
	private String is_send_to_supplier_creation;
	
	@Column(name = "BRANCH_NAME")
	private String branch_name;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "SUPPLIER_REGISTER_ID" , insertable = false, updatable = false)
	private SuppliersRegister supplierRegistration;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getBank_num() {
		return bank_num;
	}

	public void setBank_num(String bank_num) {
		this.bank_num = bank_num;
	}

	public String getBranch_type() {
		return branch_type;
	}

	public void setBranch_type(String branch_type) {
		this.branch_type = branch_type;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getSwift_code() {
		return swift_code;
	}

	public void setSwift_code(String swift_code) {
		this.swift_code = swift_code;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getAccount_num() {
		return account_num;
	}

	public void setAccount_num(String account_num) {
		this.account_num = account_num;
	}

	public String getAccount_name() {
		return account_name;
	}

	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}

	public String getCheck_digits() {
		return check_digits;
	}

	public void setCheck_digits(String check_digits) {
		this.check_digits = check_digits;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getPoProcessStatus() {
		return poProcessStatus;
	}

	public void setPoProcessStatus(String poProcessStatus) {
		this.poProcessStatus = poProcessStatus;
	}

	public Long getSupplier_register_id() {
		return supplier_register_id;
	}

	public void setSupplier_register_id(Long supplier_register_id) {
		this.supplier_register_id = supplier_register_id;
	}

	@JsonIgnore
	public SuppliersRegister getSupplierRegistration() {
		return supplierRegistration;
	}

	public void setSupplierRegistration(SuppliersRegister supplierRegistration) {
		this.supplierRegistration = supplierRegistration;
	}

	public String getIs_send_to_supplier_creation() {
		return is_send_to_supplier_creation;
	}

	public void setIs_send_to_supplier_creation(String is_send_to_supplier_creation) {
		this.is_send_to_supplier_creation = is_send_to_supplier_creation;
	}

	public String getBranch_name() {
		return branch_name;
	}

	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}
}