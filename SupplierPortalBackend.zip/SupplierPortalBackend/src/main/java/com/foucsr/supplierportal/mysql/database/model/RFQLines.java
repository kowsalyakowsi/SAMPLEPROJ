package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "RFQ_LINES_ALL")
public class RFQLines {

	@Id
	@SequenceGenerator(name = "RFQ_LINES_ALL_SEQ", sequenceName = "RFQ_LINES_ALL_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RFQ_LINES_ALL_SEQ")
	@Column(name = "RFQ_LINE_ID")
	private Long rfq_line_id;

	@Column(name = "RFQ_HEADER_ID")
	private Long rfq_header_id;

	@Column(name = "LINE_NUM")
	private long line_num;

	@Column(name = "ITEM_ID")
	private long item_id;
	
	@Column(name = "ITEM_NAME")
	private String item_name;

	@Column(name = "ITEM_DESCRIPTION")
	private String item_description;

	@Column(name = "UOM")
	private String uom;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "LAST_UPDATE_DATE")
	private Date last_update_date;

	@Column(name = "LAST_UPDATED_BY")
	private Long last_updated_by;

	@Column(name = "LAST_UPDATE_LOGIN")
	private Long last_update_login;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATION_DATE")
	private Date creation_date;
	
	@Column(name = "USER_NAME")
	private String user_name;
	
	@Column(name = "LINE_TYPE_ID")
	private Long line_type_id;
	
	@Column(name = "LINE_TYPE")
	private String line_type;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "RFQ_HEADER_ID" , insertable = false, updatable = false)
	private RFQHeader rfqHeader;
	
	@OneToMany(cascade = CascadeType.REMOVE , mappedBy = "rfqLine" )
	private List<RFQPriceBreaks> rfqPriceBreaks;

	public RFQLines() {

	}

	public Long getRfq_line_id() {
		return rfq_line_id;
	}

	public void setRfq_line_id(Long rfq_line_id) {
		this.rfq_line_id = rfq_line_id;
	}

	public Long getRfq_header_id() {
		return rfq_header_id;
	}

	public void setRfq_header_id(Long rfq_header_id) {
		this.rfq_header_id = rfq_header_id;
	}

	public long getLine_num() {
		return line_num;
	}

	public void setLine_num(long line_num) {
		this.line_num = line_num;
	}

	public long getItem_id() {
		return item_id;
	}

	public void setItem_id(long item_id) {
		this.item_id = item_id;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Long getLast_update_login() {
		return last_update_login;
	}

	public void setLast_update_login(Long last_update_login) {
		this.last_update_login = last_update_login;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	@JsonIgnore
	public RFQHeader getRfqHeader() {
		return rfqHeader;
	}

	public void setRfqHeader(RFQHeader rfqHeader) {
		this.rfqHeader = rfqHeader;
	}

	@JsonIgnore
	public List<RFQPriceBreaks> getRfqPriceBreaks() {
		return rfqPriceBreaks;
	}

	public void setRfqPriceBreaks(List<RFQPriceBreaks> rfqPriceBreaks) {
		this.rfqPriceBreaks = rfqPriceBreaks;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

}