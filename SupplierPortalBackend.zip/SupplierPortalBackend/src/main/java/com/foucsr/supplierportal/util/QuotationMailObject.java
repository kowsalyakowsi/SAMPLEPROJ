package com.foucsr.supplierportal.util;

public class QuotationMailObject {

	private String rfq_number;

	private String item_name;

	private String item_description;

	private Double updated_price_by_supplier;

	private double from_quantity;

	private double to_quantity;

	private double price_discount;
	
	private Long agent_id;
	
	private String user_name;
	
	private double freight_charge;

	public String getRfq_number() {
		return rfq_number;
	}

	public void setRfq_number(String rfq_number) {
		this.rfq_number = rfq_number;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public Double getUpdated_price_by_supplier() {
		return updated_price_by_supplier;
	}

	public void setUpdated_price_by_supplier(Double updated_price_by_supplier) {
		this.updated_price_by_supplier = updated_price_by_supplier;
	}

	public double getFrom_quantity() {
		return from_quantity;
	}

	public void setFrom_quantity(double from_quantity) {
		this.from_quantity = from_quantity;
	}

	public double getTo_quantity() {
		return to_quantity;
	}

	public void setTo_quantity(double to_quantity) {
		this.to_quantity = to_quantity;
	}

	public double getPrice_discount() {
		return price_discount;
	}

	public void setPrice_discount(double price_discount) {
		this.price_discount = price_discount;
	}

	public Long getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(Long agent_id) {
		this.agent_id = agent_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public double getFreight_charge() {
		return freight_charge;
	}

	public void setFreight_charge(double freight_charge) {
		this.freight_charge = freight_charge;
	}

}
