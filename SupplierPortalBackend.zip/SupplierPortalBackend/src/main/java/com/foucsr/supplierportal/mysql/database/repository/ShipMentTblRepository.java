package com.foucsr.supplierportal.mysql.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.mysql.database.model.ShipMentTbl;

@Repository
public interface ShipMentTblRepository extends CrudRepository<ShipMentTbl, Long> {
	
    @Override
    Iterable<ShipMentTbl> findAll();

    @Query(value = "select * from SHIPMENT_TBL where PO_PROCESS_STATUS='I'", nativeQuery = true)
    List<ShipMentTbl> findShipments();
    
    
    @Query(value = "select * from shipment_tbl where asn = :asn and id = (select max(id) from shipment_tbl where asn = :asn )", nativeQuery = true)
    ShipMentTbl getShipMentStatusByASNOfMaxId(@Param("asn") String asn );
    
    
    @Query(value = "select * from SHIPMENT_TBL where  ASN =:asn order by ASN DESC, PO_NUMBER DESC, PO_LINE_NUM ASC", nativeQuery = true)
    List<ShipMentTbl> getShipMentByOnlyASN(@Param("asn") String asn );
    
}