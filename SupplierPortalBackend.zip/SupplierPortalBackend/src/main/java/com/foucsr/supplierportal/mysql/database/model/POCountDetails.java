package com.foucsr.supplierportal.mysql.database.model;

public class POCountDetails {

	long openPO;
	
	long rejectedBySupplier;
	
	long acknowledgedBySupplier;
	
	long changeRequestPO;
	
	public POCountDetails() {
	}

	public POCountDetails(long openPO, long rejectedBySupplier, long acknowledgedBySupplier , long changeRequestPO) {
		super();
		this.openPO = openPO;
		this.rejectedBySupplier = rejectedBySupplier;
		this.acknowledgedBySupplier = acknowledgedBySupplier;
		this.changeRequestPO =  changeRequestPO;
	}

	public long getOpenPO() {
		return openPO;
	}

	public void setOpenPO(long openPO) {
		this.openPO = openPO;
	}

	public long getRejectedBySupplier() {
		return rejectedBySupplier;
	}

	public void setRejectedBySupplier(long rejectedBySupplier) {
		this.rejectedBySupplier = rejectedBySupplier;
	}

	public long getAcknowledgedBySupplier() {
		return acknowledgedBySupplier;
	}

	public void setAcknowledgedBySupplier(long acknowledgedBySupplier) {
		this.acknowledgedBySupplier = acknowledgedBySupplier;
	}

	public long getChangeRequestPO() {
		return changeRequestPO;
	}

	public void setChangeRequestPO(long changeRequestPO) {
		this.changeRequestPO = changeRequestPO;
	}

	
}
