package com.foucsr.supplierportal.oracle.database.repository;
import org.springframework.stereotype.Component;

@Component
public class PrePaymentInvoiceDetailsOracleRepository  {	   
    
//    @Query(value = "select * from XX_PREPAYMENT_INVOICE where PO_PROCESS_STATUS='I'", nativeQuery = true)
//    List<PrePaymentInvoiceOracle> findAllNewPrePayments();
   
}