package com.foucsr.supplierportal.mysql.database.controller;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.crypto.NoSuchPaddingException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.exception.ResourceNotFoundException;
import com.foucsr.supplierportal.mysql.database.model.AgentListProjection;
import com.foucsr.supplierportal.mysql.database.model.ApSuppliers;
import com.foucsr.supplierportal.mysql.database.model.Currencies;
import com.foucsr.supplierportal.mysql.database.model.PoAgents;
import com.foucsr.supplierportal.mysql.database.model.Role;
import com.foucsr.supplierportal.mysql.database.model.SupplierBankDetailsRegister;
import com.foucsr.supplierportal.mysql.database.model.SupplierBankObject;
import com.foucsr.supplierportal.mysql.database.model.SupplierCompanyObject;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;
import com.foucsr.supplierportal.mysql.database.model.SupplierProductsRegister;
import com.foucsr.supplierportal.mysql.database.model.SuppliersRegister;
import com.foucsr.supplierportal.mysql.database.model.TaxCountry;
import com.foucsr.supplierportal.mysql.database.model.User;
import com.foucsr.supplierportal.mysql.database.repository.ApSuppliersRepository;
import com.foucsr.supplierportal.mysql.database.repository.CurrenciesRepository;
import com.foucsr.supplierportal.mysql.database.repository.EmailDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.MasterItemsRepository;
import com.foucsr.supplierportal.mysql.database.repository.PoAgentsRepository;
import com.foucsr.supplierportal.mysql.database.repository.RoleRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierBankDetailsRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierProductsRepository;
import com.foucsr.supplierportal.mysql.database.repository.SupplierRegisterRepository;
import com.foucsr.supplierportal.mysql.database.repository.TaxCountryRepository;
import com.foucsr.supplierportal.mysql.database.repository.UserRepository;
import com.foucsr.supplierportal.mysql.database.service.ApSuppliersService;
import com.foucsr.supplierportal.mysql.database.service.MapValidationErrorService;
import com.foucsr.supplierportal.mysql.database.service.PoAgentsService;
import com.foucsr.supplierportal.payload.ApiResponse;
import com.foucsr.supplierportal.payload.JwtAuthenticationResponse;
import com.foucsr.supplierportal.payload.LoginRequest;
import com.foucsr.supplierportal.payload.SignUpRequest;
import com.foucsr.supplierportal.payload.SupplierRegistrationRequest;
import com.foucsr.supplierportal.payload.UpdateUserRequest;
import com.foucsr.supplierportal.security.JwtTokenProvider;
import com.foucsr.supplierportal.util.AppConstants;
import com.foucsr.supplierportal.util.EmailHtmlLoader;
import com.foucsr.supplierportal.util.EmailSubject;
import com.foucsr.supplierportal.util.SCAUtil;
import com.foucsr.supplierportal.util.SendMail;

/**
 * Created by FocusR.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
	Logger logger = LoggerFactory.getLogger(AuthController.class);

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;
	
//	@Autowired
//	private POAgentsOracleRepository poAgentsOracleRepositoryOracle;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@Autowired
	ApSuppliersService apSuppliersService;
	
	@Autowired
	PoAgentsService poAgentsService;
	
	@Autowired
	EmailDetailsRepository emailDetailsRepository;
	
	@Autowired
	EmailHtmlLoader emailHtmlLoader;
	
	@Autowired
	SupplierRegisterRepository supplierRegistrationRepository;
	
	@Autowired
	SupplierProductsRepository supplierProductsRepository;
	
	@Autowired
	SupplierBankDetailsRepository supplierBankDetailsRepository;
	
	@Autowired
	MasterItemsRepository masterItemsRepository;
	
	@Autowired
	TaxCountryRepository taxCountryRepository;
	
	@Autowired
	CurrenciesRepository currenciesRepository;
	
	@Autowired
	ApSuppliersRepository apSuppliersRepository;
	
	@Autowired
	PoAgentsRepository poAgentsRepository;
	
	
	

/*	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest, BindingResult result) {
		
		String jwt = "";
		
		try {
			
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		
		createAdmin();
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		jwt = tokenProvider.generateToken(authentication);
		
		} catch(Exception e) {
			
			logger.info("***************** Unable to signin! *********************\n" + e);
			
			return new ResponseEntity(new ApiResponse(false, "Unable to signin!"),
					HttpStatus.BAD_REQUEST);
		}

		return ResponseEntity.ok(new JwtAuthenticationResponse(jwt));
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest, BindingResult result) {
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		String getAgentOrBuyerName= signUpRequest.getName()!= null ? signUpRequest.getName() : "";
		
		URI location = null;
		
		try {

		if(! "ROLE_ADMIN".equals(signUpRequest.getUserRoles())) 
		{
			
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity(new ApiResponse(false, "Username is already taken!"), HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
		}
		
		if (signUpRequest.getAgentId() == null && signUpRequest.getVendorID() == null) {
			return new ResponseEntity(new ApiResponse(false, "User must be a supplier or a buyer!"), HttpStatus.BAD_REQUEST);
		}
		
		if (  !( ("ROLE_BUYER".equals(signUpRequest.getUserRoles()) && signUpRequest.getAgentId() != null)
				|| ("ROLE_SUPPLIER".equals(signUpRequest.getUserRoles()) && signUpRequest.getVendorID() != null) ) ) {
			return new ResponseEntity(new ApiResponse(false, "Role must have a proper supplier or a buyer id!"), HttpStatus.BAD_REQUEST);
		}
		

//		java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();
		
		if (signUpRequest.getVendorID() != null) {
			ApSuppliers vendorID = apSuppliersService.findByVendorID(signUpRequest.getVendorID());

			if (vendorID == null) {
				return new ResponseEntity(new ApiResponse(false, "Vendor Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}
			
//			if(vendorID.getEnd_date_active() != null && vendorID.getEnd_date_active().compareTo(date) > 0) {
			if(false) {
				
				return new ResponseEntity(new ApiResponse(false, "Vendor is not in Active!"),
						HttpStatus.BAD_REQUEST);
			}

			getAgentOrBuyerName = vendorID.getVendor_name();
		}

		if (signUpRequest.getAgentId() != null) {
			PoAgents agentId = poAgentsService.findByAgentId(signUpRequest.getAgentId());
			
			if (agentId == null) {
				return new ResponseEntity(new ApiResponse(false, "Agent Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}
			
//            if(agentId.getEndDateActive() != null && agentId.getEndDateActive().compareTo(date) > 0) {
			if(false) {
				
				return new ResponseEntity(new ApiResponse(false, "Agent is not in Active!"),
						HttpStatus.BAD_REQUEST);
			}

            getAgentOrBuyerName = agentId.getAgentName();
		}
		
	}

		// Creating user's account
		User user = new User(getAgentOrBuyerName, signUpRequest.getUsername(), signUpRequest.getEmail(),
				signUpRequest.getPassword(), signUpRequest.getOrgname(), signUpRequest.getVendorID(), signUpRequest.getAgentId(), 'Y');

		user.setPassword(passwordEncoder.encode(user.getPassword()));

		if (signUpRequest.getVendorID() != null) {
			user.setSupplier_flag('Y');
			user.setBuyer_flag('N');
		}

		if (signUpRequest.getAgentId() != null) {
			user.setSupplier_flag('N');
			user.setBuyer_flag('Y');
		}
		Role userRole = roleRepository.findByName(signUpRequest.getUserRoles())
				.orElseThrow(() -> new AppException("User Role not set."));

		user.setRoles(Collections.singleton(userRole));

		User results = userRepository.save(user);

		location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
				.buildAndExpand(results.getUsername()).toUri();
		
		} catch (Exception ex) {
	    	
			 logger.error("***************** Unable to register user!  *********************\n" + ex);

				String msg = ex.getMessage() != null ? ex.getMessage() : "";
				
				String cause = "";
				 
				if(ex.getCause() != null) {
					
					cause = ex.getCause().getMessage() != null ? ex.getCause().getMessage() : "";
					
					msg = msg + "!!!" + cause;
				}
				
				return new ResponseEntity(new ApiResponse(false, " Unable to register user!" + msg), HttpStatus.BAD_REQUEST);
		}

		return ResponseEntity.created(location).body(new ApiResponse(true, "User registered successfully"));
	}
*/
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/forgetPassword")
	public ResponseEntity<?>  processForgotPasswordForm(@Valid @RequestBody UpdateUserRequest forgetPassRequest,
			BindingResult result) {
		
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		
		if (errorMap != null)
			return errorMap;
		
		User user = userRepository.findByUsernameOrEmail(forgetPassRequest.getEmail() , forgetPassRequest.getEmail()).orElseThrow(
				() -> new ResourceNotFoundException("User  does not exist!", "username or email", forgetPassRequest.getEmail()));


		String jwt = tokenProvider.generateTokenForgetPassword(user);
		
		
		user.setResetToken(jwt);

		// Save token to database
		User results = userRepository.save(user);

		sendMail(forgetPassRequest ,  jwt , user);

	    
		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
				.buildAndExpand(results.getUsername()).toUri();

		return ResponseEntity.created(location).body(new ApiResponse(true, "User Updated successfully"));
	}
	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/updateNewPassword")
	public ResponseEntity<?> updateNewPassword(@Valid @RequestBody UpdateUserRequest signUpRequest,
			BindingResult result ) {
		
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		User user = userRepository.findByResetToken(signUpRequest.getToken()).orElseThrow(
				() -> new ResourceNotFoundException("User token does not exist!", "token", signUpRequest.getToken()));

		if (signUpRequest.getPassword() != null) {
			
			 String jwt = signUpRequest.getToken();

	            if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
	            	
	               /* Long userId = tokenProvider.getUserIdFromJWT(jwt);

	                UserDetails userDetails = customUserDetailsService.loadUserById(userId);
	                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
	                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

	                SecurityContextHolder.getContext().setAuthentication(authentication);*/
	            	
	            	user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
	            	user.setResetToken(null);
	            	
	            	User results = userRepository.save(user);

	        		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
	        				.buildAndExpand(results.getUsername()).toUri();

	        		return ResponseEntity.created(location).body(new ApiResponse(true, "User password updated successfully"));
	            } 

		}

		return new ResponseEntity(new ApiResponse(false, "unable to update password"),
				HttpStatus.BAD_REQUEST);
		
	}
	
	private void sendMail(UpdateUserRequest forgetPassRequest, String jwt, User user) {

//		User admin = userRepository.findAdmin()
//				.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));

		String appUrl = forgetPassRequest.getForgetPasswordUrl();

		String emailFrom = new String();
		List<String> emailTo = new ArrayList<String>();
		List<String> emailCC = new ArrayList<String>();
		String subject = AppConstants.forgetPasswordSubject;
		String text =  emailHtmlLoader.getText(AppConstants.forgetPasswordTemplate, appUrl + "/resetPwd/"+jwt);


		emailTo.add(user.getEmail());

		EmailSubject emailSubject = null;
		try {
			emailSubject = EmailSubject.getInstance(emailDetailsRepository);
		} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
				| InvalidKeySpecException e) {

			throw new AppException("Unable to get Email details");
		}
		
		String fromEmail = emailSubject.getUsername();
		emailFrom = fromEmail;

		emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
		emailSubject.setHTML(true);

		SendMail sm = new SendMail();

		sm.sendMail(emailSubject);
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/saveSupplierCompany")
	public ResponseEntity<?> saveSupplierCompany(@Valid @RequestBody SuppliersRegister request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;			

				try {				
					
					SuppliersRegister existingSupplier =   supplierRegistrationRepository.getSupplierById(request.getId());
						
						if(existingSupplier != null) {														
							
							setSupplierCompanyDetails(existingSupplier , request);
														
							existingSupplier = supplierRegistrationRepository.save(existingSupplier);
							return new ResponseEntity<SuppliersRegister>(existingSupplier, HttpStatus.CREATED);
						}
						

				} catch (Exception ex) {
					logger.info("***************** Unable to save company details *********************\n" + ex);
					throw new AppException("Unable to save company details");
				}

		return new ResponseEntity<String>("Unable to save company details",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}
	
	
	private void setSupplierCompanyDetails(SuppliersRegister existingSupplier , SuppliersRegister request ) {
		
		TaxCountry country = taxCountryRepository.findTaxCountryByName(request.getTerritory_short_name());
		
		if(country != null) {
			
			existingSupplier.setTerritory_code(country.getTerritory_code());
		}
		
		existingSupplier.setAddress(request.getAddress());
		existingSupplier.setAddress_line1(request.getAddress_line1());
		existingSupplier.setAddress_line2(request.getAddress_line2());
		existingSupplier.setCity(request.getCity());
		existingSupplier.setCompany_registration_number(request.getCompany_registration_number());
		existingSupplier.setContact_title(request.getContact_title());
		existingSupplier.setDuns(request.getDuns());
		existingSupplier.setEnd_date_active(request.getEnd_date_active());
		existingSupplier.setExtension(request.getExtension());
		existingSupplier.setFax_no(request.getFax_no());
		existingSupplier.setFirst_name(request.getFirst_name());
		existingSupplier.setInvoice_currency_code(request.getInvoice_currency_code());
		existingSupplier.setLast_name(request.getLast_name());
		existingSupplier.setMiddle_name(request.getMiddle_name());
		existingSupplier.setNum_1099(request.getNum_1099());
		existingSupplier.setOrg_url(request.getOrg_url());
		existingSupplier.setPhone_code(request.getPhone_code());
		existingSupplier.setPhone_no(request.getPhone_no());
		existingSupplier.setProcessStatus("I");
		existingSupplier.setTerritory_code(request.getTerritory_code());
		existingSupplier.setTerritory_short_name(request.getTerritory_short_name());
		existingSupplier.setVat_registration_num(request.getVat_registration_num());
		existingSupplier.setVendor_name(request.getVendor_name());
		existingSupplier.setVendor_name_alt(request.getVendor_name_alt());
		existingSupplier.setVendor_site_code(request.getVendor_site_code());
		existingSupplier.setState(request.getState());
				
	}

	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/saveSupplierProducts")
	public ResponseEntity<?> saveSupplierProducts(@Valid @RequestBody List<SupplierProductsRegister> request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		
		List<Long> register_id_list = new ArrayList<Long>();
		
		for(SupplierProductsRegister prod : request) {
			
			register_id_list.add(prod.getSupplier_register_id());
		}

		if (request != null) {

				try {
					
					supplierProductsRepository.deleteAllProducts(register_id_list);
					
					Iterable<SupplierProductsRegister>  products = supplierProductsRepository.saveAll(request);
					
					return new ResponseEntity<Iterable<SupplierProductsRegister>>(products, HttpStatus.CREATED);				

				} catch (Exception ex) {
					logger.info("***************** Unable to save product details *********************\n" + ex);
					throw new AppException("Unable to save product details");
				}


		}

		return new ResponseEntity<String>("Unable to save product details",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}
*/	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/saveSupplierProducts")
	public ResponseEntity<?> saveSupplierProducts(@Valid @RequestBody SupplierProductsRegister request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;		

		if (request != null) {

				try {					
					
					request = supplierProductsRepository.save(request);
					
					return new ResponseEntity<SupplierProductsRegister>(request, HttpStatus.CREATED);				

				} catch (Exception ex) {
					logger.info("***************** Unable to save product details *********************\n" + ex);
					throw new AppException("Unable to save product details");
				}

		}

		return new ResponseEntity<String>("Unable to save product details",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}

	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/saveSupplierBankDetails")
	public ResponseEntity<?> saveSupplierBankDetails(@Valid @RequestBody SupplierBankDetailsRegister request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		if (request != null) {
			
			Long supplier_register_id = request.getSupplier_register_id();

			if (supplier_register_id != null) {

				try {				
					
					    request.setPoProcessStatus("I");
					    request.setBranch_type("OTHER");
																
						request = supplierBankDetailsRepository.save(request);
						
						return new ResponseEntity<SupplierBankDetailsRegister>(request, HttpStatus.CREATED);


				} catch (Exception ex) {
					logger.info("***************** Unable to save bank details *********************\n" + ex);
					throw new AppException("Unable to save bank details");
				}

			}

		}

		return new ResponseEntity<String>("Unable to bank company details",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/getSupplierCompany")
	public ResponseEntity<?> getSupplierCompany(@Valid @RequestBody SupplierRegistrationRequest request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;

		if (request != null) {

			String jwt = request.getToken();
			
			Long supplier_register_id = tokenProvider.getUserIdFromJWT(jwt); 

			if (StringUtils.hasText(jwt) &&  supplier_register_id != null) {

				try {
					
					SuppliersRegister existingSupplier = supplierRegistrationRepository.getSupplierById(supplier_register_id);
					
					if(existingSupplier != null) {
						
						List<TaxCountry> countries = taxCountryRepository.findAllTaxCountries();												
						
						SupplierCompanyObject obj = new SupplierCompanyObject();
						obj.setSupplierRegister(existingSupplier);
						obj.setCountries(countries);
						
						return new ResponseEntity<SupplierCompanyObject>(obj, HttpStatus.OK);
					}


				} catch (Exception ex) {
					logger.info("***************** Unable to get company details *********************\n" + ex);
					throw new AppException("Unable to get company details");
				}

			}

		}

		return new ResponseEntity<String>("Unable to get company details",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getSupplierProducts")
	public ResponseEntity<?> getSupplierProducts(@RequestParam Map<String, String> requestParams, Principal principal) {

		Long supplier_register_id = Long.parseLong(requestParams.get("supplier_register_id"));

		try {

//			List<MasterItems> allItems = masterItemsRepository.findAllValid();

			List<SupplierProductsRegister> registeredItems = supplierProductsRepository
					.getSupplierProducts(supplier_register_id);

//			for (MasterItems item : allItems) {
//
//				for (SupplierProductsRegister regItem : registeredItems) {
//
//					if (item.getInv_item_id() == regItem.getInv_item_id()
//							&& item.getOrganization_id() == regItem.getOrganization_id()) {
//
//						item.setIs_selected("Y");
//					}
//				}
//
//			}
//			
			if(registeredItems == null) {
				
				registeredItems = new ArrayList<SupplierProductsRegister>();
			}

			return new ResponseEntity<List<SupplierProductsRegister>>(registeredItems, HttpStatus.OK);

		} catch (Exception ex) {
			logger.info("***************** Unable to get product details *********************\n" + ex);
			throw new AppException("Unable to get product details");
		}

	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getSupplierBankDetails")
	public ResponseEntity<?> getSupplierBankDetails(@RequestParam Map<String, String> requestParams, Principal principal) {

		Long supplier_register_id = Long.parseLong(requestParams.get("supplier_register_id"));

		try {

			List<SupplierBankDetailsRegister> banks = supplierBankDetailsRepository.getSupplierBankDetails(supplier_register_id);
			
			List<Currencies> currencies = currenciesRepository.findAllCurrencies();
			
			SupplierBankObject obj = new SupplierBankObject();

			if(banks == null) {
				
				banks = new ArrayList<SupplierBankDetailsRegister>();
			}
			
			obj.setCurrencies(currencies);
			obj.setBanks(banks);
			
			return new ResponseEntity<SupplierBankObject>(obj, HttpStatus.OK);

		} catch (Exception ex) {
			logger.info("***************** Unable to get bank details *********************\n" + ex);
			throw new AppException("Unable to get bank details");
		}

	}



	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/submitRegistration")
	public ResponseEntity<?> submitRegistration(@RequestParam Map<String, String> requestParams, Principal principal) {

		Long supplier_register_id = Long.parseLong(requestParams.get("supplier_register_id"));

		try {

			SuppliersRegister existingSupplier = supplierRegistrationRepository
					.getSupplierById(supplier_register_id);

			if (existingSupplier != null) {
				

				existingSupplier.setIs_submit("Y");

				supplierRegistrationRepository.save(existingSupplier);
				
				try {
				   sendMailToBuyerForSubmit(existingSupplier, supplier_register_id.toString());
				} catch (Exception ex) {
					logger.info("***************** Unable to send mail sumbit registration from supplier *********************\n" + ex);
					throw new AppException("Unable to send mail sumbit registration from supplier");
				}

				return new ResponseEntity<String>("Submitted", HttpStatus.OK);
			}

		} catch (Exception ex) {
			logger.info("***************** Unable to update sumbit registration from supplier *********************\n" + ex);
			throw new AppException("Unable to send mail sumbit registration from supplier");
		}

		return new ResponseEntity<String>("Unable to submit", HttpStatus.INTERNAL_SERVER_ERROR);

	}

	private void sendMailToBuyerForSubmit(SuppliersRegister supplier , String id) {
		
		/*User admin = userRepository.findAdmin()
				.orElseThrow(() -> new ResourceNotFoundException("User  does not exist!", "", ""));*/
		
		String emailFrom = new String();
		List<String> emailTo = new ArrayList<String>();
		List<String> emailCC = new ArrayList<String>();
		String subject = AppConstants.supplierRegistrationSubbmitSubject;
		String text = emailHtmlLoader.getSupplierRegistrationSubmittedText(supplier.getVendor_name() , id);

		emailFrom = supplier.getEmail();


		EmailSubject emailSubject = null;
		try {
			emailSubject = EmailSubject.getInstance(emailDetailsRepository);
		} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
				| InvalidKeySpecException e) {

			throw new AppException("Unable to get Email details");
		}
		
		String fromEmail = emailSubject.getUsername();
		emailFrom = fromEmail;

		emailSubject.init(emailFrom, emailTo, emailCC, null, subject, text);
		emailSubject.setHTML(true);

		SendMail sm = new SendMail();

		sm.sendMail(emailSubject);
	}
	
	@DeleteMapping("/deleteSupplierBankDetails")
	public ResponseEntity<?> deleteSupplierBankDetails(@RequestParam Map<String, String> requestParams, Principal principal) {

		Long supplier_register_id = Long.parseLong(requestParams.get("supplier_register_id"));

		Long id = Long.parseLong(requestParams.get("id"));

		try {

			SupplierBankDetailsRegister bank = supplierBankDetailsRepository.findBankById(supplier_register_id, id);

			if (bank != null) {

				supplierBankDetailsRepository.delete(bank);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		String message = AppConstants.Success_Message;

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/deleteSupplierProducts")
	public ResponseEntity<?> deleteSupplierProducts(@RequestParam Map<String, String> requestParams, Principal principal) {

		Long supplier_register_id = Long.parseLong(requestParams.get("supplier_register_id"));

		Long id = Long.parseLong(requestParams.get("id"));

		try {

			SupplierProductsRegister supplierProd = supplierProductsRepository.findSupplierProduct(supplier_register_id , id);

			if (supplierProd != null) {

				supplierProductsRepository.delete(supplierProd);
			}

		} catch (Exception e) {
			throw new AppException("Unable to delete");
		}

		String message = AppConstants.Success_Message;

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	
	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/saveSiteOperatingUnit")
	public ResponseEntity<?> saveSiteOperatingUnit(@Valid @RequestBody SuppliersRegister request,
			BindingResult result) {

		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;			

				try {				
					
					SuppliersRegister existingSupplier =   supplierRegistrationRepository.getSupplierById(request.getId());
						
						if(existingSupplier != null) {														
							
							if(request.getOrg_name() != null && request.getOrg_id() != null) {
								
								existingSupplier.setOrg_id(request.getOrg_id());
								existingSupplier.setOrg_name(request.getOrg_name());
							}
														
							existingSupplier = supplierRegistrationRepository.save(existingSupplier);
							return new ResponseEntity<SuppliersRegister>(existingSupplier, HttpStatus.CREATED);
						}
						

				} catch (Exception ex) {
					logger.info("***************** Unable to site OU *********************\n" + ex);
					throw new AppException("Unable to save site OU");
				}

		return new ResponseEntity<String>("Unable to save site OU",
				HttpStatus.INTERNAL_SERVER_ERROR);

	}
*/
	
	public void createAdmin() {

		Optional<User> admin = null;
		
		try {
			admin = userRepository.findFirstAdmin();
		} catch (Exception ex) {
			logger.error("***************** Unable to find admin ********************* " + ex);
		}

		if (admin != null && !admin.isPresent()) {

			User user = new User("admin", "sysadmin", "sysadmin@gmail.com", "welcome", "", "", "", 'Y');
			
			user.setSupplier_flag('N');
			user.setBuyer_flag('N');

			user.setPassword(passwordEncoder.encode(user.getPassword()));

			Role userRole = roleRepository.findByName("ROLE_ADMIN")
					.orElseThrow(() -> new AppException("User Role not set."));

			user.setRoles(Collections.singleton(userRole));

			try {
				 userRepository.save(user);
			} catch (Exception ex) {
				logger.error("***************** Unable to create admin ********************* " + ex);
			}

		}

	}
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest, BindingResult result) {
		
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		
		logger.info("***************** User signin *********************\n" + loginRequest.getUsernameOrEmail());
		
//		testConnection();
//		
		createAdmin();
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
     
		String jwt = "";
		
		jwt = tokenProvider.generateToken(authentication);
		
		User user = null;
		
		
		Long userId = getUserIdFromJWT(jwt);


		Optional<User> opt = userRepository.findUser(userId);

		if (!opt.isPresent()) {

			return new ResponseEntity(new ApiResponse(false, "User is not found !"), HttpStatus.BAD_REQUEST);
		}

		user = opt.get();
		
		String name = user.getName() == null ? "" : user.getName();
		String full_name = user.getFull_name() == null ? "" : user.getFull_name();
		
		
		SCAUtil scaUtil = new SCAUtil();
			
		if ("Y".equals(loginRequest.getIsSuperUser())) {
			
			if(!"Y".equals(user.getIs_super_user())) {
				
				return new ResponseEntity(new ApiResponse(false, "User is not a Super User!"), HttpStatus.BAD_REQUEST);
			}

			try {
			// set the temporary vendor id to the user table which is chosen by the current
			// signin coordinator
				if(loginRequest.getVendorID() != null) {
					
					user.setVendorID(loginRequest.getVendorID());
					
					userRepository.save(user);
					
					ApSuppliers findVendor = apSuppliersRepository.findByVendorIDId(loginRequest.getVendorID());
					name = findVendor.getVendor_name();
					
				} else if(loginRequest.getBuyerID() != null) {
					
                    user.setAgentId(loginRequest.getBuyerID());
					
					userRepository.save(user);
					
					PoAgents agent = poAgentsRepository.findByAgentId(loginRequest.getBuyerID());
					name = agent.getAgentName();
				}
			
			} catch (Exception e) {
				
				logger.error("***************** Unable save vendor/buyer id while super user signin!  *********************\n" + e);

				String msg = scaUtil.getErrorMessage(e);

				return new ResponseEntity(new ApiResponse(false, "Unable save vendor/buyer id while super user signin!" + msg), HttpStatus.BAD_REQUEST);			
			}

			jwt = tokenProvider.generateCoOrdinatorToken(authentication , loginRequest.getVendorID());
		} 
		/*else {
			
            if(!"N".equals(user.getIs_super_user())) {
				
				return new ResponseEntity(new ApiResponse(false, "This is a Super User. Please select the vendor!"), HttpStatus.BAD_REQUEST);
			}
		}*/
		
		JwtAuthenticationResponse resp = new JwtAuthenticationResponse(jwt);
		resp.setName(name);
		resp.setFull_name(full_name);

		return ResponseEntity.ok(resp);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest, BindingResult result) {
		
		URI location = null;
		
		try {
			
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		String getAgentOrBuyerName= signUpRequest.getName()!= null ? signUpRequest.getName() : "";
		
		
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity(new ApiResponse(false, "Username is already taken!"), HttpStatus.BAD_REQUEST);
		}
		
		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
		}
		
//		java.util.Date date = poAgentsOracleRepositoryOracle.findDateFromServer();

		if(! "ROLE_ADMIN".equals(signUpRequest.getUserRoles()) && !"ROLE_SUPERUSER".equals(signUpRequest.getUserRoles())
				&& ! "ROLE_FINANCE".equals(signUpRequest.getUserRoles())) 
		{
			
		
		if (signUpRequest.getAgentId() == null && signUpRequest.getVendorID() == null) {
			return new ResponseEntity(new ApiResponse(false, "User must be a supplier or a buyer!"), HttpStatus.BAD_REQUEST);
		}
		
		if (  !( ("ROLE_BUYER".equals(signUpRequest.getUserRoles()) && signUpRequest.getAgentId() != null)
				|| ("ROLE_REQUESTOR".equals(signUpRequest.getUserRoles()) && signUpRequest.getAgentId() != null)
				|| ("ROLE_SUPPLIER".equals(signUpRequest.getUserRoles()) && signUpRequest.getVendorID() != null) ) ) {
			return new ResponseEntity(new ApiResponse(false, "Role must have a proper supplier or a buyer id!"), HttpStatus.BAD_REQUEST);
		}
		

		if (signUpRequest.getVendorID() != null) {
			
			ResponseEntity<?> vendorResp = checkVendorId(signUpRequest.getVendorID());
			
			HttpStatus vendorStatusCode = vendorResp.getStatusCode();
			
			if (vendorStatusCode != HttpStatus.OK) {
				
				return vendorResp;
				
			}
			
			ApSuppliers vendorID = (ApSuppliers) vendorResp.getBody();
			
			getAgentOrBuyerName = vendorID.getVendor_name() + " - " + vendorID.getVendor_code();
		}
		
		
		if (signUpRequest.getAgentId() != null) {
			PoAgents agentId = poAgentsService.findByAgentId(signUpRequest.getAgentId());
			
			if (agentId == null) {
				return new ResponseEntity(new ApiResponse(false, "Agent Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}
			
            /*if(agentId.getEndDateActive() != null && agentId.getEndDateActive().compareTo(date) > 0) {
				
				return new ResponseEntity(new ApiResponse(false, "Agent is not in Active!"),
						HttpStatus.BAD_REQUEST);
			}*/

            getAgentOrBuyerName = agentId.getAgentName();
		}
		
	}
		
		
		// Creating user's account
		User user = new User(getAgentOrBuyerName, signUpRequest.getUsername(), signUpRequest.getEmail(),
				signUpRequest.getPassword(), signUpRequest.getOrgname(), signUpRequest.getVendorID(), signUpRequest.getAgentId(), 'Y');

		user.setPassword(passwordEncoder.encode(user.getPassword()));
		
		user.setFull_name(signUpRequest.getFull_name());

		if (signUpRequest.getVendorID() != null) {
			user.setSupplier_flag('Y');
			user.setBuyer_flag('N');
		}

		if (signUpRequest.getAgentId() != null) {
			user.setSupplier_flag('N');
			user.setBuyer_flag('Y');
		}
		Role userRole = roleRepository.findByName(signUpRequest.getUserRoles())
				.orElseThrow(() -> new AppException("User Role not set."));

		user.setRoles(Collections.singleton(userRole));
		
		user.setIs_super_user("N");
		
	       if("ROLE_SUPERUSER".equals(signUpRequest.getUserRoles())) {
				
	           user.setIs_super_user("Y");
				
			}

		User results = userRepository.save(user);	
		


		location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
				.buildAndExpand(results.getUsername()).toUri();
		
	 } catch (Exception ex) {
	    	
		 logger.error("***************** Unable to register user!  *********************\n" + ex);

			String msg = ex.getMessage() != null ? ex.getMessage() : "";
			
			String cause = "";
			 
			if(ex.getCause() != null) {
				
				cause = ex.getCause().getMessage() != null ? ex.getCause().getMessage() : "";
				
				msg = msg + "!!!" + cause;
			}
			
			return new ResponseEntity(new ApiResponse(false, " Unable to register user!" + msg), HttpStatus.BAD_REQUEST);
	}

		return ResponseEntity.created(location).body(new ApiResponse(true, "User registered successfully"));
	}

	private Long getUserIdFromJWT(String jwt) {

		Long userId = tokenProvider.getUserIdFromJWT(jwt);

		return userId;
	}
	
   private ResponseEntity<?> checkVendorId(String  VendorID) {
		
		ApSuppliers vendorID = null;
		
		if (VendorID != null) {
			
			 vendorID = apSuppliersService.findByVendorID(VendorID);

			if (vendorID == null) {
				return new ResponseEntity(new ApiResponse(false, "Vendor Id is does not exist!"),
						HttpStatus.BAD_REQUEST);
			}
			
			/*if(vendorID.getEnd_date_active() != null && vendorID.getEnd_date_active().compareTo(date) > 0) {
				
				return new ResponseEntity(new ApiResponse(false, "Vendor is not in Active!"),
						HttpStatus.BAD_REQUEST);
			}*/

		}
		
		return new ResponseEntity(vendorID, HttpStatus.OK);

	}
   
   @PostMapping("/getVendorListForSuperUSer")
	public ResponseEntity<?> getVendorListForSuperUSer(@Valid @RequestBody LoginRequest loginRequest, BindingResult result) {
		
		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		if (errorMap != null)
			return errorMap;
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		
		// after authentication get vendor list to show for the super user
		List<SupplierListProjection> vendors = null;
		
		try {

			vendors = apSuppliersRepository.findDistinctByVendorID();
		
		} catch (Exception e) {

			logger.error("***************** Unable to get vendor list!  *********************\n" + e);

			String msg = e.getMessage() != null ? e.getMessage() : "";

			return new ResponseEntity(new ApiResponse(false, "Unable to get vendor list!" + msg),
					HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity(vendors, HttpStatus.OK);

	}

   
   @PostMapping("/getBuyerListForSuperUSer")
  	public ResponseEntity<?> getBuyerListForSuperUSer(@Valid @RequestBody LoginRequest loginRequest, BindingResult result) {
  		
  		ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
  		if (errorMap != null)
  			return errorMap;
  		Authentication authentication = authenticationManager.authenticate(
  				new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

  		SecurityContextHolder.getContext().setAuthentication(authentication);
  		
  		
  		// after authentication get buyer list to show for the super user
  		List<AgentListProjection> agents = null;
  		
  		try {

  			agents = poAgentsRepository.findDistinctByAgents();
  		
  		} catch (Exception e) {

  			logger.error("***************** Unable to get buyer list!  *********************\n" + e);

  			String msg = e.getMessage() != null ? e.getMessage() : "";

  			return new ResponseEntity(new ApiResponse(false, "Unable to get buyer list!" + msg),
  					HttpStatus.BAD_REQUEST);
  		}

  		return new ResponseEntity(agents, HttpStatus.OK);

  	}

}
