package com.foucsr.supplierportal.mysql.database.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PO_LINE_TYPES")
public class POLineTypes {
	@Id
	@Column(name = "LINE_TYPE_ID")
	private Long line_type_id;

	@Column(name = "ORDER_TYPE_LOOKUP_CODE")
	private String order_type_lookup_code;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "INACTIVE_DATE")
	private Date inactive_date;

	@Column(name = "LINE_TYPE")
	private String line_type;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "PURCHASE_BASIS")
	private String purchase_basis;

	@Column(name = "MATCHING_BASIS")
	private String matching_basis;

	@Column(name = "PO_PROCESS_STATUS")
	private String po_process_status;

	public POLineTypes() {

	}

	public Long getLine_type_id() {
		return line_type_id;
	}

	public void setLine_type_id(Long line_type_id) {
		this.line_type_id = line_type_id;
	}

	public String getOrder_type_lookup_code() {
		return order_type_lookup_code;
	}

	public void setOrder_type_lookup_code(String order_type_lookup_code) {
		this.order_type_lookup_code = order_type_lookup_code;
	}

	public Date getInactive_date() {
		return inactive_date;
	}

	public void setInactive_date(Date inactive_date) {
		this.inactive_date = inactive_date;
	}

	public String getLine_type() {
		return line_type;
	}

	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPurchase_basis() {
		return purchase_basis;
	}

	public void setPurchase_basis(String purchase_basis) {
		this.purchase_basis = purchase_basis;
	}

	public String getMatching_basis() {
		return matching_basis;
	}

	public void setMatching_basis(String matching_basis) {
		this.matching_basis = matching_basis;
	}

	public String getPo_process_status() {
		return po_process_status;
	}

	public void setPo_process_status(String po_process_status) {
		this.po_process_status = po_process_status;
	}

}