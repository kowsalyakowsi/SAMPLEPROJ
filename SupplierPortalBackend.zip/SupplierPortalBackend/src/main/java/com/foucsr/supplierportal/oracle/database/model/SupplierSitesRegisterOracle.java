package com.foucsr.supplierportal.oracle.database.model;

public class SupplierSitesRegisterOracle {

	private Long stg_header_id;

	private String vendor_name;

	private String vendor_site_code;

	private String address_line1;

	private String city;

	private String country;

	private Long org_id;

	private String state;

	private Long created_by;

	private Long last_updated_by;

	private String status;
	
	private String pay_site_flag;
	
	private String rfq_only_site_flag;
	
	private String purchasing_site_flag;

	public Long getStg_header_id() {
		return stg_header_id;
	}

	public void setStg_header_id(Long stg_header_id) {
		this.stg_header_id = stg_header_id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getAddress_line1() {
		return address_line1;
	}

	public void setAddress_line1(String address_line1) {
		this.address_line1 = address_line1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Long getOrg_id() {
		return org_id;
	}

	public void setOrg_id(Long org_id) {
		this.org_id = org_id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getCreated_by() {
		return created_by;
	}

	public void setCreated_by(Long created_by) {
		this.created_by = created_by;
	}

	public Long getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(Long last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPay_site_flag() {
		return pay_site_flag;
	}

	public void setPay_site_flag(String pay_site_flag) {
		this.pay_site_flag = pay_site_flag;
	}

	public String getRfq_only_site_flag() {
		return rfq_only_site_flag;
	}

	public void setRfq_only_site_flag(String rfq_only_site_flag) {
		this.rfq_only_site_flag = rfq_only_site_flag;
	}

	public String getPurchasing_site_flag() {
		return purchasing_site_flag;
	}

	public void setPurchasing_site_flag(String purchasing_site_flag) {
		this.purchasing_site_flag = purchasing_site_flag;
	}

}
