package com.foucsr.supplierportal.oracle.database.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.foucsr.supplierportal.oracle.database.model.PartialReceiptOracle;


@Repository
public interface PartialReceiptOracleRepository extends CrudRepository<PartialReceiptOracle, Long> {

//    @Query(value = "select * from XX_SHIPMENT_PARTIAL_TBL where XX_SHIPMENT_ID = :id ORDER BY RECEIPT_NUMBER", nativeQuery = true)
//    List<PartialReceiptOracle> findPartialReceiptsById(@Param("id") Long id);
   
}