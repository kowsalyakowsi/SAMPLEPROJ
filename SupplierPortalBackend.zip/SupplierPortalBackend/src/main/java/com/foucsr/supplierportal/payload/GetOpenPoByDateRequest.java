package com.foucsr.supplierportal.payload;

import java.util.Date;

public class GetOpenPoByDateRequest {
   
    private String fromDate;
	private String toDate;
	private String vendorId;
	private Long unique_id;
	
	private Long poLineLocation_id;
	
	private String org_name;
	private Double changed_qty;
	private Double revised_price;
	private Date reschedule_date;
	private String po_num;
	private char ack;
	private String unAcknowledgeReason;
	private String buyerId;
	
	private String closedPOStatus;
	
	private String ASN_ShipmentStatus;
	
	private String do_num;
	
	private String filter_for_payment_details;
	
	private String payment_num;
	
	private String invoice_num;
	
	private String item_code;
	
	private String line_type;
	
	private String is_asn;
	
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}
	public String getInvoice_num() {
		return invoice_num;
	}
	public void setInvoice_num(String invoice_num) {
		this.invoice_num = invoice_num;
	}
	public String getPayment_num() {
		return payment_num;
	}
	public void setPayment_num(String payment_num) {
		this.payment_num = payment_num;
	}
	public String getFilter_for_payment_details() {
		return filter_for_payment_details;
	}
	public void setFilter_for_payment_details(String selected_for_payment_details) {
		this.filter_for_payment_details = selected_for_payment_details;
	}
	public String getASN_ShipmentStatus() {
		return ASN_ShipmentStatus;
	}
	public void setASN_ShipmentStatus(String aSN_ShipmentStatus) {
		ASN_ShipmentStatus = aSN_ShipmentStatus;
	}
	public String getClosedPOStatus() {
		return closedPOStatus;
	}
	public void setClosedPOStatus(String closedPOStatus) {
		this.closedPOStatus = closedPOStatus;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getPo_num() {
		return po_num;
	}
	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}
	private String reason;
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Double getChanged_qty() {
		return changed_qty;
	}
	public void setChanged_qty(Double changed_qty) {
		this.changed_qty = changed_qty;
	}
	public Double getRevised_price() {
		return revised_price;
	}
	public void setRevised_price(Double revised_price) {
		this.revised_price = revised_price;
	}
	public Date getReschedule_date() {
		return reschedule_date;
	}
	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}
	public String getOrg_name() {
		return org_name;
	}
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	
	
	public GetOpenPoByDateRequest(String fromDate, String toDate, String vendorId, Long unique_id,
			Long poLineLocation_id, String org_name, char ack, String unAcknowledgeReason, String buyerId,
			String closedPOStatus, String ASN_ShipmentStatus, String selected_for_payment_details ,
			String payment_num , String invoice_num, String item_code) {
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.vendorId = vendorId;
		this.unique_id = unique_id;
		this.poLineLocation_id = poLineLocation_id;
		this.org_name = org_name;
		this.ack = ack;
		this.unAcknowledgeReason = unAcknowledgeReason;
		this.buyerId = buyerId;
		this.closedPOStatus = closedPOStatus;
		this.ASN_ShipmentStatus = ASN_ShipmentStatus;
		this.filter_for_payment_details = selected_for_payment_details;
		this.payment_num = payment_num; 
		this.invoice_num = invoice_num;
		this.item_code = item_code;
	}
	public Long getUnique_id() {
		return unique_id;
	}
	public void setUnique_id(Long unique_id) {
		this.unique_id = unique_id;
	}
	
	public Long getPoLineLocation_id() {
		return poLineLocation_id;
	}
	public void setPoLineLocation_id(Long poLineLocation_id) {
		this.poLineLocation_id = poLineLocation_id;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	
	public char getAck() {
		return ack;
	}
	public void setAck(char ack) {
		this.ack = ack;
	}

	public String getUnAcknowledgeReason() {
		return unAcknowledgeReason;
	}
	public void setUnAcknowledgeReason(String unAcknowledgeReason) {
		this.unAcknowledgeReason = unAcknowledgeReason;
	}
	public String getLine_type() {
		return line_type;
	}
	public void setLine_type(String line_type) {
		this.line_type = line_type;
	}
	public String getIs_asn() {
		return is_asn;
	}
	public void setIs_asn(String is_asn) {
		this.is_asn = is_asn;
	}
	public String getDo_num() {
		return do_num;
	}
	public void setDo_num(String do_num) {
		this.do_num = do_num;
	}
	
}

