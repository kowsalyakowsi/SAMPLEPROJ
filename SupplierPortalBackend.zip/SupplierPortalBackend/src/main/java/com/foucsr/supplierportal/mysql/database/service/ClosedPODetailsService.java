package com.foucsr.supplierportal.mysql.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.ClosedPODetails;
import com.foucsr.supplierportal.mysql.database.model.ClosedPOStatusListProjection;
import com.foucsr.supplierportal.mysql.database.model.SupplierListProjection;
import com.foucsr.supplierportal.mysql.database.repository.ClosedPODetailsRepository;
import com.foucsr.supplierportal.payload.GetOpenPoByDateRequest;

@Service
public class ClosedPODetailsService {

	@Autowired
	private ClosedPODetailsRepository closedPODetailsRepository;

	public ClosedPODetails saveOrUpdateProject(ClosedPODetails closedPODetails, String username) {

		try {

		} catch (Exception e) {
			// throw new ProjectIdException("Project ID
			// '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
		}
		return closedPODetailsRepository.save(closedPODetails);

	}

	public Optional<ClosedPODetails> findProjectByIdentifier(Long id, String username) {

		// Only want to return the project if the user looking for it is the owner

		Optional<ClosedPODetails> closedPODetails = closedPODetailsRepository.findById(id);

		return closedPODetails;
	}

	public Iterable<ClosedPODetails> findAllProjects(String username) {
		return closedPODetailsRepository.findAll();
	}

	public void deleteProjectByIdentifier(long id, String username) {

		closedPODetailsRepository.deleteById(id);
	}
	
    public List<ClosedPODetails> getClosedPoByDate(GetOpenPoByDateRequest byDateRequest) {
		
		List<ClosedPODetails> list = null;
		
		try {
			if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
					&& byDateRequest.getVendorId() != null && byDateRequest.getClosedPOStatus() != null) {
				list = closedPODetailsRepository.getClosedPoDetailsByStatusAndDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId(), byDateRequest.getClosedPOStatus());
			} 
			else if (byDateRequest.getFromDate() != null && byDateRequest.getToDate() != null
					&& byDateRequest.getVendorId() != null) {
				list = closedPODetailsRepository.getClosedPoDetailsByAllParm(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
			}
			else if (byDateRequest.getClosedPOStatus() != null
					&& byDateRequest.getVendorId() != null) {
				list = closedPODetailsRepository.getClosedPoDetailsByStatus(byDateRequest.getVendorId(), byDateRequest.getClosedPOStatus());
			}
			else if (byDateRequest.getVendorId() != null) {
				list = closedPODetailsRepository.getClosedPoDetailsByVendorId(byDateRequest.getVendorId());
			}

		} catch (Exception e) {
			throw new AppException("Unable to get Closed PO details");
		}

		return list;

	}

	public List<ClosedPOStatusListProjection> findDistinctClosedPOStatus() {

		return closedPODetailsRepository.findDistinctClosedPOStatus();
	}

}
