package com.foucsr.supplierportal.mysql.database.model;

public interface  SupplierListProjection {

	 Long getVendor_id();

	
     String getVendor_name();
     
     
     String getVendor_code();
	

}