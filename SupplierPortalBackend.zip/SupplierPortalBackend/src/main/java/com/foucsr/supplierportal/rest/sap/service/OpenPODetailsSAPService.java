package com.foucsr.supplierportal.rest.sap.service;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenPODetailsSAPService {
	
	
	@JsonProperty( "ID")
	private Long id;
	
	@JsonProperty("OU_NAME")
	private String ou_name;
	
	@JsonProperty("PO_HEADER_ID")
	private long po_header_id;
	
	@JsonProperty("PO_DATE")
	private Date po_date;
	
	@JsonProperty("PO_NUM")
	private String po_num;
	
	@JsonProperty("VENDOR_NAME")
	private String vendor_name;
	
	@JsonProperty("VEN_SITE_CODE")
	private String vendor_site_code;
	
	@JsonProperty("BUYER")
	private String buyer;
	
	@JsonProperty("BUYER_ID")
	private String buyer_id;
	
	@JsonProperty("PO_LINE_NO")
	private Long po_line_num;
	
	@JsonProperty("ITEM_CODE")
	private String item;
	
	@JsonProperty("ITEM_DESC")
	private String item_description;
	
	@JsonProperty("PO_UOM")
	private String po_uom;
	
	@JsonProperty("UNIT_PRICE")
	private Double unit_price;
	
	@JsonProperty("QTY_ORDERED")
	private Double qty_ordered;
	
	@JsonProperty("ORG")
	private String organization_name;
	
//	@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("NEED_BY_DATE")
	private Date need_by_date;
	
	@JsonProperty("ACK")
	private String ack;
	
	@JsonProperty("RESCHEDULE")
	private String reschedule;

	//@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("RESCHEDULE_DATE")
	private Date reschedule_date;
	
	@JsonProperty("PROCESS_FLAG")
	private String process_flag;
	
	@JsonProperty("ASN")
	private String asn;
	
	@JsonProperty("SHIPMENT_NUM")
	private Long shipment_num;
	
	@JsonProperty("RECEIPT_CREATED_FLAG")
	private String receipt_created_flag;
	
	@JsonProperty("PO_LINE_ID")
	private long po_line_id;
	
	@JsonProperty("PO_LINE_LOCATION_ID")
	private long poLineLocationId;
	
	@JsonProperty("RECEIPT_NUMBER")
	private Long receipt_number;
	
	@JsonProperty("VENDOR_ID")
	private Long vendor_id;
	
	@JsonProperty("SHIPMENT_QTY")
	private Double shipment_qty;
	
	@JsonProperty("RECEIVING_QUANTITY")
	private Double receiving_quantity;
	
	@JsonProperty("HEADER_ID")
	private long headerId;

	@JsonProperty("PENDING_QTY")
	private Double pending_qty;
	
	@JsonProperty("BUYER_APPROVAL")
	private String buyer_approval;
	
	@JsonProperty("CHANGED_QTY")
	private Double changed_qty;
	
	@JsonProperty("NEW_QTY")
	private Double new_qty;
	
	@JsonProperty("RELEASE_ID")
	private Long release_id;
	
	@JsonProperty("RELEASE_NUMBER")
	private Long release_number;
	
	//@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("RELEASE_DATE")
	private Date release_date;
	
	//@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("CREATION_DATE")
	private Date creation_date;
	
	@JsonProperty( "PROCESSSTATUS")
	private String processStatus;
	
	@JsonProperty( "IS_CHANGED")
	private String isChanged;
	 
	@JsonProperty( "IS_REJECTED")
	private String isRejected;
	
	@JsonProperty( "REASON_FOR_REJECTED")
	private String reaasonForRejected;
	
	private Double asn_reserve_qty;
	
	private Integer changeRequestCount;
	
	private Long revisionNo;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date reminder_date;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOu_name() {
		return ou_name;
	}

	public void setOu_name(String ou_name) {
		this.ou_name = ou_name;
	}

	public long getPo_header_id() {
		return po_header_id;
	}

	public void setPo_header_id(long po_header_id) {
		this.po_header_id = po_header_id;
	}

	public Date getPo_date() {
		return po_date;
	}

	public void setPo_date(Date po_date) {
		this.po_date = po_date;
	}

	public String getPo_num() {
		return po_num;
	}

	public void setPo_num(String po_num) {
		this.po_num = po_num;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public String getVendor_site_code() {
		return vendor_site_code;
	}

	public void setVendor_site_code(String vendor_site_code) {
		this.vendor_site_code = vendor_site_code;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Long getPo_line_num() {
		return po_line_num;
	}

	public void setPo_line_num(Long po_line_num) {
		this.po_line_num = po_line_num;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String getPo_uom() {
		return po_uom;
	}

	public void setPo_uom(String po_uom) {
		this.po_uom = po_uom;
	}

	public Double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(Double unit_price) {
		this.unit_price = unit_price;
	}

	public Double getQty_ordered() {
		return qty_ordered;
	}

	public void setQty_ordered(Double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public Date getNeed_by_date() {
		return need_by_date;
	}

	public void setNeed_by_date(Date need_by_date) {
		this.need_by_date = need_by_date;
	}

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}

	public String getReschedule() {
		return reschedule;
	}

	public void setReschedule(String reschedule) {
		this.reschedule = reschedule;
	}

	public Date getReschedule_date() {
		return reschedule_date;
	}

	public void setReschedule_date(Date reschedule_date) {
		this.reschedule_date = reschedule_date;
	}

	public String getProcess_flag() {
		return process_flag;
	}

	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}

	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public Long getShipment_num() {
		return shipment_num;
	}

	public void setShipment_num(Long shipment_num) {
		this.shipment_num = shipment_num;
	}

	public String getReceipt_created_flag() {
		return receipt_created_flag;
	}

	public void setReceipt_created_flag(String receipt_created_flag) {
		this.receipt_created_flag = receipt_created_flag;
	}

	public long getPo_line_id() {
		return po_line_id;
	}

	public void setPo_line_id(long po_line_id) {
		this.po_line_id = po_line_id;
	}

	public long getPoLineLocationId() {
		return poLineLocationId;
	}

	public void setPoLineLocationId(long poLineLocationId) {
		this.poLineLocationId = poLineLocationId;
	}

	public Long getReceipt_number() {
		return receipt_number;
	}

	public void setReceipt_number(Long receipt_number) {
		this.receipt_number = receipt_number;
	}

	public Long getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(Long vendor_id) {
		this.vendor_id = vendor_id;
	}

	public Double getShipment_qty() {
		return shipment_qty;
	}

	public void setShipment_qty(Double shipment_qty) {
		this.shipment_qty = shipment_qty;
	}

	public Double getReceiving_quantity() {
		return receiving_quantity;
	}

	public void setReceiving_quantity(Double receiving_quantity) {
		this.receiving_quantity = receiving_quantity;
	}

	public long getHeaderId() {
		return headerId;
	}

	public void setHeaderId(long headerId) {
		this.headerId = headerId;
	}

	public Double getPending_qty() {
		return pending_qty;
	}

	public void setPending_qty(Double pending_qty) {
		this.pending_qty = pending_qty;
	}

	public String getBuyer_approval() {
		return buyer_approval;
	}

	public void setBuyer_approval(String buyer_approval) {
		this.buyer_approval = buyer_approval;
	}

	public Double getChanged_qty() {
		return changed_qty;
	}

	public void setChanged_qty(Double changed_qty) {
		this.changed_qty = changed_qty;
	}

	public Double getNew_qty() {
		return new_qty;
	}

	public void setNew_qty(Double new_qty) {
		this.new_qty = new_qty;
	}

	public Long getRelease_id() {
		return release_id;
	}

	public void setRelease_id(Long release_id) {
		this.release_id = release_id;
	}

	public Long getRelease_number() {
		return release_number;
	}

	public void setRelease_number(Long release_number) {
		this.release_number = release_number;
	}

	public Date getRelease_date() {
		return release_date;
	}

	public void setRelease_date(Date release_date) {
		this.release_date = release_date;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getIsChanged() {
		return isChanged;
	}

	public void setIsChanged(String isChanged) {
		this.isChanged = isChanged;
	}

	public String getIsRejected() {
		return isRejected;
	}

	public void setIsRejected(String isRejected) {
		this.isRejected = isRejected;
	}

	public String getReaasonForRejected() {
		return reaasonForRejected;
	}

	public void setReaasonForRejected(String reaasonForRejected) {
		this.reaasonForRejected = reaasonForRejected;
	}

	public Double getAsn_reserve_qty() {
		return asn_reserve_qty;
	}

	public void setAsn_reserve_qty(Double asn_reserve_qty) {
		this.asn_reserve_qty = asn_reserve_qty;
	}

	public Integer getChangeRequestCount() {
		return changeRequestCount;
	}

	public void setChangeRequestCount(Integer changeRequestCount) {
		this.changeRequestCount = changeRequestCount;
	}

	public Long getRevisionNo() {
		return revisionNo;
	}

	public void setRevisionNo(Long revisionNo) {
		this.revisionNo = revisionNo;
	}

	public Date getReminder_date() {
		return reminder_date;
	}

	public void setReminder_date(Date reminder_date) {
		this.reminder_date = reminder_date;
	}
	
		

}