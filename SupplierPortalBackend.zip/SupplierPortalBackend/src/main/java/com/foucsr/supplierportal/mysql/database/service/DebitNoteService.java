package com.foucsr.supplierportal.mysql.database.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foucsr.supplierportal.exception.AppException;
import com.foucsr.supplierportal.mysql.database.model.DebitNote;
import com.foucsr.supplierportal.mysql.database.repository.DebitNoteRepository;
import com.foucsr.supplierportal.payload.ReportFilterRequest;

@Service
public class DebitNoteService {

	@Autowired
	private DebitNoteRepository debitNoteRepository;

	public List<DebitNote> getDebitNoteByDate(ReportFilterRequest byDateRequest) {

		List<DebitNote> list = null;

		try {
			if ( !"".equals(byDateRequest.getPo_num()) && !"".equals(byDateRequest.getFromDate())
					&& !"".equals(byDateRequest.getToDate()) && byDateRequest.getVendorId() != null) {
				
				list = debitNoteRepository.getDebitInvoicesByAllParm(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId() , byDateRequest.getPo_num());
				
			} else  if ( !"".equals(byDateRequest.getPo_num()) && byDateRequest.getVendorId() != null) {
				
				list = debitNoteRepository.getDebitInvoicesByPO(byDateRequest.getVendorId() , byDateRequest.getPo_num());
				
			} else if (!"".equals(byDateRequest.getFromDate()) && !"".equals(byDateRequest.getToDate())
					&& byDateRequest.getVendorId() != null) {
				 
				list = debitNoteRepository.getDebitInvoicesByDate(byDateRequest.getFromDate(),
						byDateRequest.getToDate(), byDateRequest.getVendorId());
				
			} else if (byDateRequest.getVendorId() != null) {
				
				list = debitNoteRepository.getDebitInvoicesByVendorId(byDateRequest.getVendorId());
				
			}

		} catch (Exception e) {
			throw new AppException("Unable to get Debit Note details");
		}
		
		if(list == null || list.size() == 0) {
			
			list = new ArrayList<DebitNote>();
			
		}

		return list;

	}

}
