package com.foucsr.supplierportal.mysql.database.model;

public interface  AgentListProjection {

	 Long getAGENT_ID();

	
     String getAGENT_NAME();
	

}